#!/usr/bin/env bash
# Usage: deploy-update.sh <zip-url-or-path> [target-dir]      (target defaults to ~/wg-vpn-gateway)
#
# Installs wg-vpn-gateway on a fresh VM, or upgrades an existing install, from a release zip.
# Same rules as the other stacks' deploy-update.sh:
#   * .env and your WireGuard config are never overwritten
#   * any other file you hand-edited since the last update is left alone and reported
#     (detected against a baseline snapshot of what was last applied)
#   * new .env keys from the template are appended with their defaults; your values stay
#   * nothing is deleted automatically — removed files are only reported
# Then, once a real WireGuard config is in place, it (re)starts the stack and waits for the
# tunnel to pass its health check. If it doesn't, the gateway is stopped again so the VM goes
# back to its normal direct routing instead of being left pointed at a dead tunnel.
set -euo pipefail

# Run from a private copy so this script can safely replace its own installed file.
if [[ -z ${WGVG_DEPLOY_COPY:-} ]]; then
  self_copy=$(mktemp)
  cp "$0" "$self_copy"
  WGVG_DEPLOY_COPY=$self_copy exec bash "$self_copy" "$@"
fi
trap 'rm -f "$WGVG_DEPLOY_COPY"' EXIT

PROJECT=wg-vpn-gateway
SERVICE=wg-vpn-gateway
HEALTH_TIMEOUT=${HEALTH_TIMEOUT:-120}

for cmd in curl python3 docker; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "Missing dependency: $cmd" >&2
    [[ $cmd == docker ]] && echo "Install Docker Engine + the compose plugin first." >&2 \
                         || echo "Install it first: sudo apt update && sudo apt install -y $cmd" >&2
    exit 1
  fi
done
docker compose version >/dev/null 2>&1 || { echo "The docker compose plugin is missing." >&2; exit 1; }

SOURCE="${1:?Usage: $0 <zip-url-or-path> [target-dir]}"
TARGET_DIR="${2:-$HOME/$PROJECT}"

if [[ $(basename "$PWD") == "$TARGET_DIR" ]] && { [[ -f docker-compose.yml ]] || [[ -f .env ]]; }; then
  echo "You're already inside '$TARGET_DIR' with an existing deployment — using '.' instead of nesting." >&2
  TARGET_DIR="."
fi

HARD_PROTECTED_PATHS="
.env
.deploy-baseline
config/wg.conf
config/wg-split.conf
state
logs
"
BASELINE_DIR="$TARGET_DIR/.deploy-baseline"

is_hard_protected() {
  local path=$1 p
  for p in $HARD_PROTECTED_PATHS ${EXTRA_PROTECTED:-}; do
    case "$path" in "$p"|"$p"/*) return 0 ;; esac
  done
  return 1
}

WORK=$(mktemp -d)
trap 'rm -f "$WGVG_DEPLOY_COPY"; rm -rf "$WORK"' EXIT
TMP_ZIP="$WORK/release.zip"
TMP_EXTRACT="$WORK/extract"
mkdir -p "$TMP_EXTRACT"

if [[ $SOURCE =~ ^(https?|file):// ]]; then
  echo "==> Downloading $SOURCE"
  curl -fsSL -o "$TMP_ZIP" "$SOURCE"
else
  [[ -f $SOURCE ]] || { echo "Zip not found: $SOURCE" >&2; exit 1; }
  cp "$SOURCE" "$TMP_ZIP"
fi

echo "==> Extracting (stripping the top-level folder)"
python3 -I - "$TMP_ZIP" "$TMP_EXTRACT" << 'PYEOF'
import zipfile, os, sys
zip_path, extract_to = sys.argv[1], os.path.realpath(sys.argv[2])
with zipfile.ZipFile(zip_path) as z:
    for info in z.infolist():
        parts = info.filename.split("/", 1)
        if len(parts) < 2 or not parts[1] or info.filename.endswith("/"):
            continue
        target = os.path.realpath(os.path.join(extract_to, parts[1]))
        if not target.startswith(extract_to + os.sep):
            sys.exit(f"refusing unsafe path in zip: {info.filename}")
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target, "wb") as f:
            f.write(z.read(info))
        mode = (info.external_attr >> 16) & 0o777
        if mode:
            os.chmod(target, mode)
PYEOF
[[ -f $TMP_EXTRACT/docker-compose.yml ]] || { echo "This zip doesn't look like a $PROJECT release." >&2; exit 1; }

mkdir -p "$TARGET_DIR" "$BASELINE_DIR"
FIRST_INSTALL=0
[[ -f $TARGET_DIR/docker-compose.yml ]] || FIRST_INSTALL=1

# Protect a custom WireGuard config path too, if it points inside the project.
env_value() { # key file
  [[ -f $2 ]] || return 0
  # a key that isn't there yet (older .env) is just empty — never an error
  { grep -E "^$1=" "$2" || true; } | tail -n1 | cut -d= -f2- | sed -e 's/^["'\'']//' -e 's/["'\'']$//'
}
WG_CONFIG_FILE=$(env_value WG_CONFIG_FILE "$TARGET_DIR/.env")
WG_CONFIG_FILE=${WG_CONFIG_FILE:-./config/wg.conf}
SPLIT_CONFIG_FILE=$(env_value SPLIT_TUNNEL_CONFIG_FILE "$TARGET_DIR/.env")
SPLIT_CONFIG_FILE=${SPLIT_CONFIG_FILE:-./config/wg-split.conf}
EXTRA_PROTECTED="${WG_CONFIG_FILE#./} ${SPLIT_CONFIG_FILE#./}"

echo "==> Applying updates"
NEW_LIST="$WORK/new" EDITED_LIST="$WORK/edited" UNTRACKED_LIST="$WORK/untracked" UPDATED_LIST="$WORK/updated"
: > "$NEW_LIST"; : > "$EDITED_LIST"; : > "$UNTRACKED_LIST"; : > "$UPDATED_LIST"
while IFS= read -r relpath; do
  is_hard_protected "$relpath" && continue
  target_file="$TARGET_DIR/$relpath"
  baseline_file="$BASELINE_DIR/$relpath"
  new_file="$TMP_EXTRACT/$relpath"

  if [[ ! -e $target_file ]]; then
    mkdir -p "$(dirname "$target_file")"
    cp -p "$new_file" "$target_file"
    echo "$relpath" >> "$NEW_LIST"
  elif [[ -f $baseline_file ]] && cmp -s "$target_file" "$baseline_file"; then
    # untouched since the last update — safe to replace
    if ! cmp -s "$new_file" "$target_file"; then
      cp -p "$new_file" "$target_file"
      echo "$relpath" >> "$UPDATED_LIST"
    fi
  elif [[ -f $baseline_file ]]; then
    # you edited it since the last update — leave it
    cmp -s "$new_file" "$target_file" || echo "$relpath" >> "$EDITED_LIST"
  else
    # pre-existing file with no baseline yet — leave it this once
    cmp -s "$new_file" "$target_file" || echo "$relpath" >> "$UNTRACKED_LIST"
  fi
  mkdir -p "$(dirname "$baseline_file")"
  cp -p "$new_file" "$baseline_file"
done < <(cd "$TMP_EXTRACT" && find . -type f | sed 's#^\./##' | sort)

if [[ -s $NEW_LIST ]]; then echo "    New files added:"; sed 's/^/      /' "$NEW_LIST"; fi
if [[ -s $UPDATED_LIST ]]; then echo "    Updated:"; sed 's/^/      /' "$UPDATED_LIST"; fi
if [[ -s $EDITED_LIST ]]; then
  echo "    Hand-edited by you since the last update — left untouched. To see the new version:"
  while IFS= read -r f; do echo "      diff $TARGET_DIR/$f $BASELINE_DIR/$f"; done < "$EDITED_LIST"
fi
if [[ -s $UNTRACKED_LIST ]]; then
  echo "    First time comparing these against a template — left alone this once; tracked from now on:"
  sed 's/^/      /' "$UNTRACKED_LIST"
fi
[[ -s $NEW_LIST || -s $UPDATED_LIST || -s $EDITED_LIST || -s $UNTRACKED_LIST ]] || echo "    Already up to date."

echo "==> Checking for files this update removed (reported only, nothing deleted)"
ORPHANS=$(cd "$TARGET_DIR" && find . -path ./.deploy-baseline -prune -o -type f -print | sed 's#^\./##' | sort | while IFS= read -r f; do
  is_hard_protected "$f" && continue
  [[ -e $BASELINE_DIR/$f && ! -e $TMP_EXTRACT/$f ]] && echo "$f"
done || true)
if [[ -n $ORPHANS ]]; then
  echo "    No longer part of the project — safe to remove:"
  sed "s#^#      rm $TARGET_DIR/#" <<<"$ORPHANS"
  while IFS= read -r f; do rm -f "$BASELINE_DIR/$f"; done <<<"$ORPHANS"
else
  echo "    Nothing orphaned."
fi

echo "==> Merging .env"
if [[ -f $TARGET_DIR/.env && -f $TMP_EXTRACT/.env ]]; then
  NEW_KEYS=""
  while IFS= read -r line || [[ -n $line ]]; do
    case "$line" in \#*|"") continue ;; esac
    key=${line%%=*}
    grep -q "^${key}=" "$TARGET_DIR/.env" || NEW_KEYS+="$line"$'\n'
  done < "$TMP_EXTRACT/.env"
  if [[ -n $NEW_KEYS ]]; then
    { echo ""; echo "# --- New in this update ($(date -u +'%Y-%m-%dT%H:%M:%SZ')) — review these ---"
      printf '%s' "$NEW_KEYS"; } >> "$TARGET_DIR/.env"
    echo "    New .env keys added with their defaults (bottom of $TARGET_DIR/.env):"
    printf '%s' "$NEW_KEYS" | sed 's/^/      /'
  else
    echo "    No new .env keys."
  fi
  echo "    All your existing values were left exactly as they were."
  # ALPINE_VERSION is a supported-base floor, not a preference: older Alpine
  # branches stop getting community-package security fixes (Suricata etc.).
  cur_alp=$(env_value ALPINE_VERSION "$TARGET_DIR/.env"); new_alp=$(env_value ALPINE_VERSION "$TMP_EXTRACT/.env")
  if [[ -n $cur_alp && -n $new_alp && $cur_alp != "$new_alp" && $(env_value ALPINE_AUTO_UPGRADE "$TARGET_DIR/.env") != false ]] && \
     [[ $(printf '%s\n%s\n' "$cur_alp" "$new_alp" | sort -V | tail -n1) == "$new_alp" ]]; then
    sed -i "s/^ALPINE_VERSION=.*/ALPINE_VERSION=$new_alp/" "$TARGET_DIR/.env"
    echo "    ALPINE_VERSION raised $cur_alp -> $new_alp (older base no longer gets security fixes for"
    echo "    Suricata/WireGuard tools; set ALPINE_AUTO_UPGRADE=false to keep your own value)."
  fi
  OBSOLETE=""
  while IFS= read -r line || [[ -n $line ]]; do
    case "$line" in \#*|"") continue ;; esac
    key=${line%%=*}
    grep -q "^${key}=" "$TMP_EXTRACT/.env" || OBSOLETE+="$key"$'\n'
  done < "$TARGET_DIR/.env"
  if [[ -n $OBSOLETE ]]; then
    echo "    No longer used by the template (left in place):"
    printf '%s' "$OBSOLETE" | sed 's/^/      /'
  fi
elif [[ -f $TMP_EXTRACT/.env ]]; then
  cp "$TMP_EXTRACT/.env" "$TARGET_DIR/.env"
  chmod 600 "$TARGET_DIR/.env"
  echo "    No existing .env — copied the template (defaults work as-is)."
fi

# ---------------------------------------------------------------- start / restart ---
WG_CONFIG_FILE=$(env_value WG_CONFIG_FILE "$TARGET_DIR/.env"); WG_CONFIG_FILE=${WG_CONFIG_FILE:-./config/wg.conf}
case "$WG_CONFIG_FILE" in /*) WG_CONF_PATH=$WG_CONFIG_FILE ;; *) WG_CONF_PATH="$TARGET_DIR/${WG_CONFIG_FILE#./}" ;; esac

MODE_VALUE=$(env_value MODE "$TARGET_DIR/.env"); MODE_VALUE=${MODE_VALUE:-standalone}
config_ready() {
  if [[ $MODE_VALUE == client ]]; then
    [[ -n $(env_value GATEWAY_IP "$TARGET_DIR/.env") ]]
    return
  fi
  [[ -f $WG_CONF_PATH ]] || return 1
  grep -qiE '^[[:space:]]*\[peer\]' "$WG_CONF_PATH" || return 1
  grep -iE '^[[:space:]]*privatekey[[:space:]]*=' "$WG_CONF_PATH" | grep -qv '<' || return 1
}

echo ""
if [[ $MODE_VALUE == client ]] && ! config_ready; then
  echo "==> Files are in place. This VM is set to MODE=client, but GATEWAY_IP isn't set yet,"
  echo "    so nothing was started. Set GATEWAY_IP in $TARGET_DIR/.env (the LAN IP of the"
  echo "    VM running MODE=gateway; add this VM's IP to GATEWAY_CLIENTS there), then run"
  echo "    the same install/update command again."
  exit 0
fi
if ! config_ready; then
  mkdir -p "$(dirname "$WG_CONF_PATH")"
  echo "==> Files are in place, but there's no WireGuard config yet, so nothing was started."
  echo "    Put your WireGuard client config at:"
  echo "      $WG_CONF_PATH"
  echo "    (example: $TARGET_DIR/config/wg.conf.example; optional settings: $TARGET_DIR/.env)"
  echo "    then run the same install/update command again to start it."
  exit 0
fi
chmod 600 "$WG_CONF_PATH" 2>/dev/null || true
# client mode has no WireGuard config, but the compose file mounts that path:
# a placeholder file keeps Docker from creating a directory there.
[[ $MODE_VALUE == client && ! -e $WG_CONF_PATH ]] && { mkdir -p "$(dirname "$WG_CONF_PATH")"; : > "$WG_CONF_PATH"; }
# Same for the split-tunnel config, which is only used when
# SPLIT_TUNNEL_DESTINATIONS is set.
SPLIT_CONFIG_FILE=$(env_value SPLIT_TUNNEL_CONFIG_FILE "$TARGET_DIR/.env"); SPLIT_CONFIG_FILE=${SPLIT_CONFIG_FILE:-./config/wg-split.conf}
case "$SPLIT_CONFIG_FILE" in /*) SPLIT_CONF_PATH=$SPLIT_CONFIG_FILE ;; *) SPLIT_CONF_PATH="$TARGET_DIR/${SPLIT_CONFIG_FILE#./}" ;; esac
[[ -e $SPLIT_CONF_PATH ]] || { mkdir -p "$(dirname "$SPLIT_CONF_PATH")"; : > "$SPLIT_CONF_PATH"; }
chmod 600 "$SPLIT_CONF_PATH" 2>/dev/null || true
SPLIT_DESTS_VALUE=$(env_value SPLIT_TUNNEL_DESTINATIONS "$TARGET_DIR/.env")
if [[ $MODE_VALUE != client && -n ${SPLIT_DESTS_VALUE//[ ,]/} ]] && ! grep -qiE '^[[:space:]]*\[peer\]' "$SPLIT_CONF_PATH"; then
  echo "==> SPLIT_TUNNEL_DESTINATIONS is set, but the split-tunnel WireGuard config is missing or empty:"
  echo "      $SPLIT_CONF_PATH"
  echo "    Put the second WireGuard config there (or empty SPLIT_TUNNEL_DESTINATIONS in .env),"
  echo "    then run the same install/update command again. Nothing was restarted."
  exit 1
fi

cd "$TARGET_DIR"
mkdir -p state logs; chmod 700 state
# Dashboard: the guard (root) writes inbox/; the collector and web UI run as
# an unprivileged user (65534) and own the rest.
mkdir -p state/dashboard/inbox state/dashboard/db state/dashboard/geo state/dashboard/public
chmod 755 state/dashboard state/dashboard/inbox
chown 65534:65534 state/dashboard/db state/dashboard/geo state/dashboard/public 2>/dev/null || true
export PWD   # the updater service mounts the project at the same path

# The containers keep themselves updated; the host OS (kernel, Docker, OpenSSH)
# doesn't belong to them, so point that out once if it isn't automatic.
if [[ -f /etc/debian_version ]] && ! grep -qs 'Unattended-Upgrade "1"' /etc/apt/apt.conf.d/20auto-upgrades 2>/dev/null; then
  echo "    Note: this VM's own OS security updates aren't automatic. Consider:"
  echo "      apt install unattended-upgrades && dpkg-reconfigure -plow unattended-upgrades"
fi
echo "==> Starting / updating the stack (your SSH session stays connected)"
docker compose up -d --build --remove-orphans

echo "==> Waiting up to ${HEALTH_TIMEOUT}s for the tunnel to pass traffic"
deadline=$(( $(date +%s) + HEALTH_TIMEOUT ))
status="not checked"
while (( $(date +%s) < deadline )); do
  cid=$(docker compose ps -q "$SERVICE" 2>/dev/null || true)
  if [[ -n $cid ]] && [[ $(docker inspect -f '{{.State.Running}}' "$cid" 2>/dev/null) == true ]]; then
    if status=$(docker exec "$cid" /usr/local/bin/wg-vpn-healthcheck 2>&1); then
      echo "    $status"
      echo ""
      if [[ $MODE_VALUE == client ]]; then
        echo "==> Done. This VM's internet traffic is going through the gateway VM."
      else
        echo "==> Done. This VM's traffic is going through the WireGuard tunnel."
      fi
      echo "    Logs:  cd $(pwd) && docker compose logs -f"
      exit 0
    fi
  else
    status="container is not running"
  fi
  sleep 3
done

echo "    Tunnel never became healthy: $status" >&2
echo "---- last log lines ----" >&2
docker compose logs --tail 40 "$SERVICE" >&2 || true
echo "------------------------" >&2
KS_VALUE=$(env_value KILLSWITCH .env)
case "${KS_VALUE:-false}" in
  [Tt]rue|1|[Yy]es|[Oo]n)
    echo "==> Stopping the gateway. Kill switch is ON, so outbound traffic stays BLOCKED" >&2
    echo "    (it will not fall back to this VM's real IP). Your SSH session, inbound" >&2
    echo "    connections, local networks and bypass ports/destinations still work." >&2
    docker compose down >&2 || true
    echo "    Fix the config/.env and run the install/update command again." >&2
    echo "    To lift the block instead: cd $(pwd) && docker compose run --rm $SERVICE release" >&2
    ;;
  *)
    echo "==> Stopping the gateway so this VM goes back to direct routing." >&2
    docker compose down >&2 || true
    echo "    Fix the config/.env and run the install/update command again." >&2
    ;;
esac
exit 1
