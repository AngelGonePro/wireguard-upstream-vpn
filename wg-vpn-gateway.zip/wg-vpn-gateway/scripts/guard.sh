#!/usr/bin/env bash
# Runs alongside the gateway: once a minute it checks health, refreshes
# blocklists when due, reports hits / Suricata alerts, sends alerts and keeps
# logs small. One short Python process per minute, nothing else resident.
set -u
G=(python3 /usr/local/lib/wg-vpn-gateway/guardlib.py)
INTERVAL="${GUARD_INTERVAL:-60}"

"${G[@]}" start || echo "[guard] initial blocklist setup failed (will retry)" >&2
while :; do
    msg=$(/usr/local/bin/wg-vpn-healthcheck 2>&1); rc=$?
    "${G[@]}" tick "$rc" "$msg" || echo "[guard] tick failed" >&2
    sleep "$INTERVAL" & wait $!
done
