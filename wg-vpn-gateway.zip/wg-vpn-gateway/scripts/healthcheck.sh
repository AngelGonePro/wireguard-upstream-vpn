#!/usr/bin/env bash
# Healthy when this run finished setup, the policy rules are in place and the
# tunnel actually carries traffic BOTH ways:
#   standalone / gateway — a recent WireGuard handshake AND an answer from
#                          HEALTH_PING_TARGET through the tunnel (ping, or an
#                          HTTP request if the VPN drops ping). A handshake
#                          alone only proves the VPN server is alive, not that
#                          it forwards anything.
#   client               — a ping that leaves through the gateway VM
set -uo pipefail
MODE="${MODE:-standalone}"
IF="${WG_INTERFACE:-wgvpn}"
MAX="${HEALTH_MAX_HANDSHAKE_AGE:-180}"
TARGET="${HEALTH_PING_TARGET:-1.1.1.1}"

[[ -f ${RUN_DIR:-/run/wg-vpn-gateway}/ready ]] || { echo "gateway still starting"; exit 1; }
ip -4 rule show priority "$(( ${RULE_PRIORITY:-32000} + 3 ))" | grep -q . || { echo "policy rules missing"; exit 1; }

if [[ $MODE == client ]]; then
    if ping -q -c 2 -W 4 "$TARGET" >/dev/null 2>&1; then
        echo "ok — $TARGET reachable through gateway VM ${GATEWAY_IP:-?}"; exit 0
    fi
    if ping -q -c 1 -W 2 "${GATEWAY_IP:-0.0.0.0}" >/dev/null 2>&1; then
        echo "gateway VM ${GATEWAY_IP:-?} is up but not passing traffic (its tunnel may be down — kill switch blocking)"
    else
        echo "gateway VM ${GATEWAY_IP:-?} unreachable (kill switch blocking)"
    fi
    exit 1
fi

ip link show dev "$IF" >/dev/null 2>&1 || { echo "interface $IF missing"; exit 1; }
newest=$(wg show "$IF" latest-handshakes | awk '{ if ($2 > m) m = $2 } END { print m + 0 }')
age=$(( $(date +%s) - newest ))
if (( newest == 0 )) || (( age > MAX )); then
    echo "VPN server not answering (no WireGuard handshake$( (( newest )) && echo " for ${age}s"))"; exit 1
fi
[[ -n $TARGET ]] || { echo "ok — last handshake ${age}s ago (HEALTH_PING_TARGET empty: traffic not checked)"; exit 0; }
# Split tunnel (if used): reported, but it doesn't fail the check — only
# its own destinations depend on it, all other traffic keeps working.
split_note() {
    local d="${SPLIT_TUNNEL_DESTINATIONS:-}"; [[ -n ${d//[ ,]/} ]] || return 0
    local sif="${SPLIT_TUNNEL_INTERFACE:-wgsplit}" hs
    if ! ip link show dev "$sif" >/dev/null 2>&1; then echo "; split tunnel $sif DOWN (missing)"; return 0; fi
    hs=$(wg show "$sif" latest-handshakes 2>/dev/null | awk '{ if ($2 > m) m = $2 } END { print m + 0 }')
    if (( hs == 0 )) || (( $(date +%s) - hs > MAX )); then echo "; split tunnel $sif: no recent handshake (down, or idle without PersistentKeepalive)"
    else echo "; split tunnel $sif ok"; fi
}
for _ in 1 2; do
    if ping -q -c 1 -W 3 -I "$IF" "$TARGET" >/dev/null 2>&1; then
        echo "ok — $TARGET answers through $IF (last handshake ${age}s ago)$(split_note)"; exit 0
    fi
done
# Some VPNs drop ping: any HTTP answer counts too (status code irrelevant).
if curl -s -o /dev/null --max-time 5 --interface "$IF" "http://$TARGET/" 2>/dev/null; then
    echo "ok — $TARGET answers through $IF over HTTP (last handshake ${age}s ago)$(split_note)"; exit 0
fi
echo "VPN server is up (handshake ${age}s ago) but nothing comes back through the tunnel — $TARGET unreachable; the VPN server isn't forwarding traffic"
exit 1
