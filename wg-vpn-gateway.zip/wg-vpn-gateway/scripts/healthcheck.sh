#!/usr/bin/env bash
# Healthy when this run finished setup, the policy rules are in place and the
# tunnel actually passes traffic:
#   standalone / gateway — recent WireGuard handshake, or a ping through it
#   client               — a ping that leaves through the gateway VM
set -uo pipefail
MODE="${MODE:-standalone}"
IF="${WG_INTERFACE:-wgvpn}"
MAX="${HEALTH_MAX_HANDSHAKE_AGE:-180}"
TARGET="${HEALTH_PING_TARGET:-1.1.1.1}"

[[ -f ${RUN_DIR:-/run/wg-vpn-gateway}/ready ]] || { echo "gateway still starting"; exit 1; }
ip -4 rule show priority "$(( ${RULE_PRIORITY:-32000} + 3 ))" | grep -q . || { echo "policy rules missing"; exit 1; }

if [[ $MODE == client ]]; then
    if ping -q -c 2 -W 4 "$TARGET" >/dev/null 2>&1; then
        echo "ok — $TARGET reachable through gateway VM ${GATEWAY_IP:-?}"; exit 0
    fi
    if ping -q -c 1 -W 2 "${GATEWAY_IP:-0.0.0.0}" >/dev/null 2>&1; then
        echo "gateway VM ${GATEWAY_IP:-?} is up but not passing traffic (its tunnel may be down — kill switch blocking)"
    else
        echo "gateway VM ${GATEWAY_IP:-?} unreachable (kill switch blocking)"
    fi
    exit 1
fi

ip link show dev "$IF" >/dev/null 2>&1 || { echo "interface $IF missing"; exit 1; }
newest=$(wg show "$IF" latest-handshakes | awk '{ if ($2 > m) m = $2 } END { print m + 0 }')
if (( newest > 0 )) && (( $(date +%s) - newest <= MAX )); then
    echo "ok — last handshake $(( $(date +%s) - newest ))s ago"; exit 0
fi
if [[ -n $TARGET ]] && ping -q -c 2 -W 4 -I "$IF" "$TARGET" >/dev/null 2>&1; then
    echo "ok — $TARGET reachable through $IF"; exit 0
fi
echo "tunnel not passing traffic (no recent handshake, $TARGET unreachable through $IF)"
exit 1
