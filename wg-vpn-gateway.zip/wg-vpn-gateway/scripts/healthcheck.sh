#!/usr/bin/env bash
# Healthy when the tunnel interface exists, the policy rules are in place and
# the peer has handshaken recently — if it hasn't (idle host), a ping through
# the tunnel is used to prove it still passes traffic.
set -uo pipefail
IF="${WG_INTERFACE:-wgvpn}"
MAX="${HEALTH_MAX_HANDSHAKE_AGE:-180}"
TARGET="${HEALTH_PING_TARGET:-1.1.1.1}"

[[ -f /run/wg-vpn-gateway/ready ]] || { echo "gateway still starting"; exit 1; }
ip link show dev "$IF" >/dev/null 2>&1 || { echo "interface $IF missing"; exit 1; }
ip -4 rule show priority "$(( ${RULE_PRIORITY:-32000} + 3 ))" | grep -q . || { echo "policy rules missing"; exit 1; }

newest=$(wg show "$IF" latest-handshakes | awk '{ if ($2 > m) m = $2 } END { print m + 0 }')
if (( newest > 0 )) && (( $(date +%s) - newest <= MAX )); then
    echo "ok — last handshake $(( $(date +%s) - newest ))s ago"; exit 0
fi
if [[ -n $TARGET ]] && ping -q -c 2 -W 4 -I "$IF" "$TARGET" >/dev/null 2>&1; then
    echo "ok — $TARGET reachable through $IF"; exit 0
fi
echo "tunnel not passing traffic (no recent handshake, $TARGET unreachable through $IF)"
exit 1
