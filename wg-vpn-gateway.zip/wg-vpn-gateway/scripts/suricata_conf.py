#!/usr/bin/env python3
"""Write a low-memory, fail-open Suricata config for inline (NFQUEUE) use.

Starts from the packaged default suricata.yaml so it keeps working across
Suricata versions, and only changes what matters here:
  * fail open everywhere: if Suricata hits a memory cap or an internal error,
    traffic is passed, never dropped (blocking only ever comes from rules)
  * small memory caps, one worker, only the protocol parsers the selected
    rule categories need (HTTP, TLS, DNS, QUIC)
  * alerts only, to logs/eve.json (size-capped by the guard)
"""
import os
import sys
import yaml

SRC_CANDIDATES = ["/etc/suricata/suricata.yaml", "/etc/suricata/suricata.yaml.default"]
KEEP_PROTOCOLS = {"http", "tls", "dns", "quic"}


def env(k, d):
    v = os.environ.get(k)
    return d if not v else v


def main(out_path):
    src = next((p for p in SRC_CANDIDATES if os.path.exists(p)), None)
    if not src:
        sys.exit("no default suricata.yaml found")
    with open(src) as f:
        text = f.read()
    cfg = yaml.safe_load(text.replace("%YAML 1.1", "").replace("---", "", 1))

    home = env("SURICATA_HOME_NET", "[10.0.0.0/8,172.16.0.0/12,192.168.0.0/16,100.64.0.0/10,fc00::/7]")
    cfg.setdefault("vars", {}).setdefault("address-groups", {})
    cfg["vars"]["address-groups"]["HOME_NET"] = home
    cfg["vars"]["address-groups"]["EXTERNAL_NET"] = "any"

    cfg["default-rule-path"] = "/state/suricata"
    cfg["rule-files"] = []
    cfg["classification-file"] = cfg.get("classification-file", "/etc/suricata/classification.config")

    log_dir = env("LOG_DIR", "/logs")
    cfg["default-log-dir"] = log_dir
    outputs = []
    for o in cfg.get("outputs", []) or []:
        for name, body in o.items():
            if isinstance(body, dict):
                body["enabled"] = "no"
            outputs.append({name: body})
    outputs.insert(0, {"eve-log": {
        "enabled": "yes", "filetype": "regular", "filename": "eve.json",
        "types": [{"alert": {"payload": "no", "packet": "no", "metadata": "yes",
                             "tagged-packets": "no"}}],
    }})
    cfg["outputs"] = outputs
    cfg["stats"] = {"enabled": "no"}
    cfg["logging"] = {"default-log-level": "notice",
                      "outputs": [{"console": {"enabled": "yes"}},
                                  {"file": {"enabled": "no", "filename": "suricata.log"}},
                                  {"syslog": {"enabled": "no"}}]}

    # Fail open: memcaps / errors must never turn into dropped valid traffic.
    cfg["exception-policy"] = "ignore"
    cfg["nfq"] = {"mode": "accept", "fail-open": "yes"}
    cfg["max-pending-packets"] = int(env("SURICATA_MAX_PENDING", "256"))
    cfg["runmode"] = "workers"
    cfg["threading"] = {"set-cpu-affinity": "no", "detect-thread-ratio": 1.0}
    cfg["unix-command"] = {"enabled": "no"}

    mb = lambda k, d: env(k, d)
    cfg["flow"] = {"memcap": mb("SURICATA_FLOW_MEMCAP", "16mb"), "hash-size": 4096,
                   "prealloc": 1000, "emergency-recovery": 30}
    stream = cfg.get("stream") or {}
    stream["memcap"] = mb("SURICATA_STREAM_MEMCAP", "24mb")
    stream["checksum-validation"] = "no"
    # Inline stream mode so a matching request is stopped before it leaves —
    # but never drop packets just because the stream engine finds them odd
    # (offloaded/coalesced segments etc.): with the default drop-invalid=yes,
    # perfectly valid connections stalled in testing.
    stream["inline"] = "auto"
    stream["drop-invalid"] = "no"
    re = stream.get("reassembly") or {}
    re.update({"memcap": mb("SURICATA_REASSEMBLY_MEMCAP", "32mb"), "depth": "512kb"})
    stream["reassembly"] = re
    cfg["stream"] = stream
    cfg["defrag"] = {"memcap": "8mb", "hash-size": 4096, "trackers": 1000, "max-frags": 2000,
                     "prealloc": "yes", "timeout": 30}
    cfg["host"] = {"hash-size": 1024, "prealloc": 100, "memcap": "4mb"}
    cfg["ippair"] = {"hash-size": 1024, "prealloc": 100, "memcap": "4mb"}

    det = cfg.get("detect") or {}
    det["profile"] = env("SURICATA_DETECT_PROFILE", "low")
    det["sgh-mpm-context"] = "auto"
    cfg["detect"] = det
    cfg["mpm-algo"] = env("SURICATA_MPM", "auto")
    cfg["spm-algo"] = "auto"

    protos = (cfg.get("app-layer") or {}).get("protocols") or {}
    for name, body in protos.items():
        if isinstance(body, dict):
            body["enabled"] = "yes" if name in KEEP_PROTOCOLS else "no"
            if name in ("http", "tls", "dns", "quic"):
                body.pop("detection-ports", None) if name != "dns" else None
    if "http" in protos and isinstance(protos["http"], dict):
        lib = protos["http"].setdefault("libhtp", {}).setdefault("default-config", {})
        lib.update({"request-body-limit": "16kb", "response-body-limit": "16kb",
                    "request-body-inspect-window": "4kb", "response-body-inspect-window": "4kb"})
    # Not needed for these categories; each costs memory.
    for k in ("pcap-file", "af-packet", "pcap", "pfring", "ipfw", "napatech", "dpdk"):
        cfg.pop(k, None)
    cfg.setdefault("app-layer", {})["protocols"] = protos

    with open(out_path, "w") as f:
        f.write("%YAML 1.1\n---\n")
        yaml.safe_dump(cfg, f, default_flow_style=False, sort_keys=False)


if __name__ == "__main__":
    main(sys.argv[1])
