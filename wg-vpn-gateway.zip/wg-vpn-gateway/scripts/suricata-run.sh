#!/usr/bin/env bash
# Suricata container: inline inspection of traffic entering/leaving the tunnel
# (the gateway queues it here with --queue-bypass, so if this container is down
# traffic still flows). Rules refresh daily and follow the guard's mode.
set -u
log() { echo "[suricata] $*"; }
STATE_DIR="${STATE_DIR:-/state}"; export STATE_DIR
SDIR="$STATE_DIR/suricata"; mkdir -p "$SDIR"
R=(python3 /usr/local/lib/wg-vpn-gateway/suricata_rules.py)
if [[ ${MODE:-standalone} == client ]]; then
    log "client mode: traffic is inspected on the gateway VM — nothing to do here"
    exec sleep infinity
fi

python3 /usr/local/lib/wg-vpn-gateway/suricata_conf.py /run/suricata.yaml || exit 1
[[ -s $SDIR/active.rules ]] || { "${R[@]}" download && "${R[@]}" activate; } || true
[[ -f $SDIR/active.rules ]] || : > "$SDIR/active.rules"

# Background: daily rule refresh, and rebuild when monitor/block mode changes.
(
    every=$(( ${SURICATA_RULES_REFRESH_HOURS:-24} * 3600 ))
    last_dl=$(date +%s); last_mode=$(python3 -c "import json;print(json.load(open('$STATE_DIR/mode.json')).get('suricata',''))" 2>/dev/null)
    while sleep 60; do
        pid=$(cat /run/suricata.pid 2>/dev/null)
        cur=$(python3 -c "import json;print(json.load(open('$STATE_DIR/mode.json')).get('suricata',''))" 2>/dev/null)
        if (( $(date +%s) - last_dl >= every )); then
            last_dl=$(date +%s)
            "${R[@]}" download && "${R[@]}" activate "$pid"
        elif [[ -n $cur && $cur != "$last_mode" ]]; then
            "${R[@]}" activate "$pid"
        fi
        last_mode=$cur
    done
) &

log "starting inline on NFQUEUE ${SURICATA_QUEUE:-0} ($(grep -c . "$SDIR/active.rules") rules)"
exec suricata -c /run/suricata.yaml -q "${SURICATA_QUEUE:-0}" -S "$SDIR/active.rules" \
     --pidfile /run/suricata.pid -l "${LOG_DIR:-/logs}"
