#!/usr/bin/env bash
# Suricata container: inline inspection. On the gateway: traffic entering and
# leaving the tunnel, plus connections from the internet through this VM's
# port forwards. On a client VM: only those port-forwarded connections.
# The gateway queues traffic here with --queue-bypass, so if this container
# is down (starting, refreshing rules, updating) traffic still flows.
#
# Rules refresh daily and follow the guard's monitor/block mode. Loading
# rules takes about as much memory as Suricata itself, so a refresh stops
# the running Suricata first and starts it again on the new rules: only one
# copy is ever in memory (two copies overran the container's memory cap).
set -u
log() { echo "[suricata] $*"; }
notify() { python3 /usr/local/lib/wg-vpn-gateway/guardlib.py notify "$*" >/dev/null 2>&1 || true; }
STATE_DIR="${STATE_DIR:-/state}"; export STATE_DIR
SDIR="$STATE_DIR/suricata"; mkdir -p "$SDIR"
R=(python3 /usr/local/lib/wg-vpn-gateway/suricata_rules.py)
QUEUE="${SURICATA_QUEUE:-0}"

python3 /usr/local/lib/wg-vpn-gateway/suricata_conf.py /run/suricata.yaml || exit 1
[[ -s $SDIR/active.rules ]] || { "${R[@]}" download && "${R[@]}" activate; } || true
[[ -f $SDIR/active.rules ]] || : > "$SDIR/active.rules"

rules() { local n; n=$(grep -c . "$SDIR/active.rules" 2>/dev/null); echo "${n:-0}"; }
mode_now() { python3 -c "import json;print(json.load(open('$STATE_DIR/mode.json')).get('suricata',''))" 2>/dev/null; }

SPID=""
start() {
    local n; n=$(rules)
    log "starting inline on NFQUEUE $QUEUE ($n rules)"
    if (( n == 0 )); then
        log "WARNING: no rules loaded — Suricata is passing traffic without checking it; retrying the download every hour"
        notify "⚠️ Suricata is running with NO rules (the rule download failed) — traffic isn't being checked by Suricata. Retrying every hour; see docker logs wg-vpn-gateway-suricata."
    fi
    suricata -c /run/suricata.yaml -q "$QUEUE" -S "$SDIR/active.rules" \
        --pidfile /run/suricata.pid -l "${LOG_DIR:-/logs}" &
    SPID=$!
}
stop() {
    [[ -n $SPID ]] || return 0
    kill -TERM "$SPID" 2>/dev/null
    wait "$SPID" 2>/dev/null
    SPID=""
    rm -f /run/suricata.pid
}
trap 'stop; exit 0' TERM INT

every=$(( ${SURICATA_RULES_REFRESH_HOURS:-24} * 3600 ))
last_dl=$(date +%s); last_mode=$(mode_now)
start
while :; do
    sleep 60 & wait $!
    if [[ -n $SPID ]] && ! kill -0 "$SPID" 2>/dev/null; then
        wait "$SPID"; rc=$?
        log "suricata exited (code $rc) — the container restarts it"
        exit "$rc"
    fi
    due=$every; (( $(rules) == 0 )) && due=3600
    cur=$(mode_now); refresh=0
    if (( $(date +%s) - last_dl >= due )); then
        last_dl=$(date +%s)
        "${R[@]}" download && refresh=1      # streams; needs very little memory
    elif [[ -n $cur && $cur != "$last_mode" ]]; then
        refresh=1
    fi
    last_mode=$cur
    if (( refresh )); then
        log "loading new rules: Suricata pauses briefly (traffic passes meanwhile)"
        stop
        "${R[@]}" activate || true           # keeps the previous rules if the new ones fail their test
        start
    fi
done
