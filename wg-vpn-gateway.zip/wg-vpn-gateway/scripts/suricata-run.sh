#!/usr/bin/env bash
# Suricata container: inline inspection. On the gateway: traffic entering and
# leaving the tunnel, plus connections from the internet through this VM's
# port forwards. On a client VM: only those port-forwarded connections.
# The gateway queues traffic here with --queue-bypass, so if this container
# is down (starting, refreshing rules, updating) traffic still flows.
#
# Rules refresh daily and follow the guard's monitor/block mode. Loading
# rules takes about as much memory as Suricata itself, so a refresh stops
# the running Suricata first and starts it again on the new rules: only one
# copy is ever in memory (two copies overran the container's memory cap).
#
# Memory: the ruleset is sized to what fits (suricata_rules.py rule_budget):
# SURICATA_MEM_LIMIT and the RAM the VM really has free, keeping
# SURICATA_VM_RESERVE for everything else. After each start the real usage is
# measured; if it's more than planned, the rules are cut and reloaded. If the
# VM later runs short of memory (something else grew), Suricata reloads with
# fewer rules instead of pushing the VM into swap; the daily refresh grows
# the set again when there's room.
set -u
log() { echo "[suricata] $*"; }
notify() { python3 /usr/local/lib/wg-vpn-gateway/guardlib.py notify "$*" >/dev/null 2>&1 || true; }
STATE_DIR="${STATE_DIR:-/state}"; export STATE_DIR
SDIR="$STATE_DIR/suricata"; mkdir -p "$SDIR"
R=(python3 /usr/local/lib/wg-vpn-gateway/suricata_rules.py)
QUEUE="${SURICATA_QUEUE:-0}"

python3 /usr/local/lib/wg-vpn-gateway/suricata_conf.py /run/suricata.yaml || exit 1
[[ -s $SDIR/active.rules ]] || { "${R[@]}" download && "${R[@]}" activate; } || true
# never start on a ruleset bigger than what fits in the VM right now
[[ -s $SDIR/active.rules ]] && ! "${R[@]}" fits && { "${R[@]}" activate || true; }
[[ -f $SDIR/active.rules ]] || : > "$SDIR/active.rules"

rules() { local n; n=$(grep -c . "$SDIR/active.rules" 2>/dev/null); echo "${n:-0}"; }
mode_now() { python3 -c "import json;print(json.load(open('$STATE_DIR/mode.json')).get('suricata',''))" 2>/dev/null; }

SPID=""
start() {
    local n; n=$(rules)
    log "starting inline on NFQUEUE $QUEUE ($n rules)"
    if (( n == 0 )); then
        log "WARNING: no rules loaded — Suricata is passing traffic without checking it; retrying the download every hour"
        notify "⚠️ Suricata is running with NO rules (the rule download failed) — traffic isn't being checked by Suricata. Retrying every hour; see docker logs wg-vpn-gateway-suricata."
    fi
    suricata -c /run/suricata.yaml -q "$QUEUE" -S "$SDIR/active.rules" \
        --pidfile /run/suricata.pid -l "${LOG_DIR:-/logs}" &
    SPID=$!
}
stop() {
    [[ -n $SPID ]] || return 0
    kill -TERM "$SPID" 2>/dev/null
    wait "$SPID" 2>/dev/null
    SPID=""
    rm -f /run/suricata.pid
}
trap 'stop; exit 0' TERM INT

# Resident memory of the running Suricata once it has finished loading (two
# equal readings 5 s apart), in KB; empty if it isn't running.
settled_rss() {
    local a=0 b i
    for i in $(seq 1 36); do
        [[ -n $SPID ]] && kill -0 "$SPID" 2>/dev/null || return 1
        b=$(awk '/^VmRSS:/{print $2}' "/proc/$SPID/status" 2>/dev/null)
        [[ -n $b ]] || return 1
        if (( b > 40000 && b - a < 2048 && a - b < 2048 )); then echo "$b"; return 0; fi
        a=$b; sleep 5
    done
    echo "$b"
}
# Measure, remember the cost per rule, and reload once with fewer rules if
# it uses more than its budget.
check_usage() {
    local rss
    rss=$(settled_rss) || return 0
    if ! "${R[@]}" calibrate "$rss" "$(rules)"; then
        stop; "${R[@]}" activate || true; start
        rss=$(settled_rss) && "${R[@]}" calibrate "$rss" "$(rules)" >/dev/null
    fi
}
avail_mb() { awk '/^MemAvailable:/{print int($2/1024)}' /proc/meminfo; }
RESERVE_MB=$(python3 -c "import sys;sys.path.insert(0,'/usr/local/lib/wg-vpn-gateway');import suricata_rules as r;print(int(r.mb(r.env('SURICATA_VM_RESERVE'),'128m')))" 2>/dev/null || echo 128)

every=$(( ${SURICATA_RULES_REFRESH_HOURS:-24} * 3600 ))
last_dl=$(date +%s); last_mode=$(mode_now)
low_since=0; last_shrink=0
start
check_usage
while :; do
    sleep 60 & wait $!
    if [[ -n $SPID ]] && ! kill -0 "$SPID" 2>/dev/null; then
        wait "$SPID"; rc=$?
        log "suricata exited (code $rc) — the container restarts it"
        exit "$rc"
    fi
    due=$every; (( $(rules) == 0 )) && due=3600
    cur=$(mode_now); refresh=0
    if (( $(date +%s) - last_dl >= due )); then
        last_dl=$(date +%s)
        "${R[@]}" download && refresh=1      # streams; needs very little memory
    elif [[ -n $cur && $cur != "$last_mode" ]]; then
        refresh=1
    fi
    last_mode=$cur
    # The VM running short (under half the reserve free for 3 minutes): give
    # memory back instead of letting the VM swap itself to a standstill.
    if (( $(avail_mb) < RESERVE_MB / 2 )); then
        (( low_since )) || low_since=$(date +%s)
        if (( $(date +%s) - low_since >= 180 && $(date +%s) - last_shrink >= 1800 )); then
            log "the VM is low on memory ($(avail_mb) MB free) — reloading with fewer rules"
            last_shrink=$(date +%s); low_since=0; refresh=1
        fi
    else
        low_since=0
    fi
    if (( refresh )); then
        log "loading new rules: Suricata pauses briefly (traffic passes meanwhile)"
        stop
        "${R[@]}" activate || true           # keeps the previous rules if the new ones fail their test
        start
        check_usage
    fi
done
