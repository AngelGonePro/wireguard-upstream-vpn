#!/usr/bin/env python3
"""Read-only dashboard web server (COMPOSE_PROFILES contains "dashboard").

Serves a fixed set of files and nothing else: the page, its script/style, the
world map, and the collector's summary.json (mounted read-only). Only GET and
HEAD exist; there are no forms, uploads, logins or query parameters that do
anything, so the UI has no way to change data or the system. Runs as an
unprivileged user with no capabilities on a read-only filesystem.
"""
import html
import json
import os
import re
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

STATIC = os.environ.get("DASHBOARD_STATIC", "/usr/local/share/wg-vpn-gateway/dashboard")
DATA = os.environ.get("DASHBOARD_PUBLIC", "/srv/data")

FILES = {   # url -> (directory, file, content type, cacheable)
    "/app.js":         (STATIC, "app.js", "text/javascript; charset=utf-8", False),
    "/og.png":         (STATIC, "og.png", "image/png", True),
    "/favicon.ico":    (STATIC, "favicon.ico", "image/x-icon", True),
    "/favicon.svg":    (STATIC, "favicon.svg", "image/svg+xml", True),
    "/apple-touch-icon.png": (STATIC, "apple-touch-icon.png", "image/png", True),
    "/style.css":      (STATIC, "style.css", "text/css; charset=utf-8", False),
    "/world.svg":      (STATIC, "world.svg", "image/svg+xml", True),
    "/countries.json": (STATIC, "countries.json", "application/json", True),
    "/summary.json":   (DATA, "summary.json", "application/json", False),
}
HEADERS = {
    "Content-Security-Policy": "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; "
                               "connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Cross-Origin-Resource-Policy": "same-origin",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=(), interest-cohort=()",
}
MAX_BODY = 32 * 1024 * 1024

# Link previews (Discord, etc.) and search engines. Previews need absolute
# URLs, so the canonical/og:url/og:image tags and sitemap.xml only appear
# when DASHBOARD_PUBLIC_URL is set (e.g. https://threatmap.example.com).
_url = os.environ.get("DASHBOARD_PUBLIC_URL", "").strip().rstrip("/")
PUBLIC_URL = _url if re.fullmatch(r"https?://[A-Za-z0-9.-]+(:[0-9]{1,5})?", _url) else ""
SITE_NAME = os.environ.get("DASHBOARD_SITE_NAME", "").strip() or "Threat Map"
DESCRIPTION = os.environ.get("DASHBOARD_DESCRIPTION", "").strip() or \
    "Live world map of blocked connection attempts: which addresses and countries try to attack this network, updated every minute."


def _stats_line():
    """'1,234 blocked attempts from 56 countries in the last 7 days' from the
    collector's summary, or '' when there's no data yet."""
    try:
        with open(os.path.join(DATA, "summary.json"), "rb") as f:
            d = json.loads(f.read(MAX_BODY))
        v = d["views"]["all"]
        n, days = int(v["total"]), int(d.get("retention_days", 7))
        cc = sum(1 for c in v["countries"] if c.get("cc") != "??")
        if n <= 0:
            return ""
        return (f"{n:,} blocked attempt{'s' if n != 1 else ''} from {cc} "
                f"countr{'ies' if cc != 1 else 'y'} in the last {days} day{'s' if days != 1 else ''}.")
    except (OSError, ValueError, KeyError, TypeError):
        return ""


_page = {"t": 0.0, "body": b""}
_page_lock = threading.Lock()


def page():
    """index.html with its <head> tags filled in; rebuilt at most once a minute
    so the preview's numbers stay current without reading files per request."""
    with _page_lock:
        if time.time() - _page["t"] < 60 and _page["body"]:
            return _page["body"]
        stats = _stats_line()
        desc = f"{stats} {DESCRIPTION}" if stats else DESCRIPTION
        e = lambda x: html.escape(x, quote=True)
        tags = [
            f"<title>{e(SITE_NAME)}</title>",
            f'<meta name="description" content="{e(desc)}">',
            '<meta name="robots" content="index, follow">',
            '<meta name="theme-color" content="#fb923c">',
            '<link rel="icon" href="/favicon.ico" sizes="48x48">',
            '<link rel="icon" href="/favicon.svg" type="image/svg+xml">',
            '<link rel="apple-touch-icon" href="/apple-touch-icon.png">',
            '<meta property="og:type" content="website">',
            f'<meta property="og:site_name" content="{e(SITE_NAME)}">',
            f'<meta property="og:title" content="{e(SITE_NAME)}">',
            f'<meta property="og:description" content="{e(desc)}">',
            '<meta name="twitter:card" content="summary_large_image">',
            f'<meta name="twitter:title" content="{e(SITE_NAME)}">',
            f'<meta name="twitter:description" content="{e(desc)}">',
        ]
        if PUBLIC_URL:
            tags += [
                f'<link rel="canonical" href="{e(PUBLIC_URL)}/">',
                f'<meta property="og:url" content="{e(PUBLIC_URL)}/">',
                f'<meta property="og:image" content="{e(PUBLIC_URL)}/og.png">',
                '<meta property="og:image:width" content="1200">',
                '<meta property="og:image:height" content="630">',
                f'<meta property="og:image:alt" content="{e(SITE_NAME)}: world map of blocked attacks">',
                f'<meta name="twitter:image" content="{e(PUBLIC_URL)}/og.png">',
            ]
        try:
            with open(os.path.join(STATIC, "index.html"), "rb") as f:
                body = f.read(MAX_BODY).replace(b"<!--HEAD-->", "\n".join(tags).encode())
        except OSError:
            body = b""
        _page.update(t=time.time(), body=body)
        return body


def robots():
    lines = ["User-agent: *", "Allow: /"]
    if PUBLIC_URL:
        lines.append(f"Sitemap: {PUBLIC_URL}/sitemap.xml")
    return ("\n".join(lines) + "\n").encode()


def sitemap():
    return ('<?xml version="1.0" encoding="UTF-8"?>\n'
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
            f"<url><loc>{html.escape(PUBLIC_URL)}/</loc><changefreq>hourly</changefreq></url>"
            "</urlset>\n").encode()


class Handler(BaseHTTPRequestHandler):
    server_version = "dashboard"
    sys_version = ""
    protocol_version = "HTTP/1.1"
    timeout = 15                     # slow clients are dropped

    def log_message(self, *a):       # no access log: nothing is written anywhere
        pass

    def _send(self, code, body=b"", ctype="text/plain; charset=utf-8", extra=None, head=False):
        self.send_response(code)
        for k, v in HEADERS.items():
            self.send_header(k, v)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if not head:
            self.wfile.write(body)

    def _serve(self, head):
        path = self.path.split("?", 1)[0]
        if path in ("/", "/index.html"):
            body = page()
            if not body:
                return self._send(503, b"page missing", head=head)
            return self._send(200, body, "text/html; charset=utf-8", {"Cache-Control": "no-store"}, head)
        if path == "/robots.txt":
            return self._send(200, robots(), "text/plain; charset=utf-8", {"Cache-Control": "public, max-age=3600"}, head)
        if path == "/sitemap.xml" and PUBLIC_URL:
            return self._send(200, sitemap(), "application/xml; charset=utf-8", {"Cache-Control": "public, max-age=3600"}, head)
        entry = FILES.get(path)
        if not entry:
            return self._send(404, b"not found", head=head)
        d, name, ctype, cacheable = entry
        p = os.path.join(d, name)
        gz = "gzip" in (self.headers.get("Accept-Encoding") or "") and os.path.exists(p + ".gz")
        try:
            with open(p + ".gz" if gz else p, "rb") as f:
                body = f.read(MAX_BODY)
        except OSError:
            return self._send(503, b"no data yet - the collector writes it within a minute", head=head)
        extra = {"Cache-Control": "public, max-age=86400" if cacheable else "no-store"}
        if gz:
            extra["Content-Encoding"] = "gzip"
            extra["Vary"] = "Accept-Encoding"
        self._send(200, body, ctype, extra, head)

    def do_GET(self):
        self._serve(False)

    def do_HEAD(self):
        self._serve(True)

    def _deny(self):
        # any request body is never read: answer and close the connection
        self.close_connection = True
        self.send_response(405)
        for k, v in HEADERS.items():
            self.send_header(k, v)
        self.send_header("Allow", "GET, HEAD")
        self.send_header("Content-Length", "0")
        self.send_header("Connection", "close")
        self.end_headers()

    do_POST = do_PUT = do_DELETE = do_PATCH = do_OPTIONS = do_TRACE = do_CONNECT = _deny


class Server(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 32

    def handle_error(self, request, client_address):
        pass                         # broken/malformed clients: drop quietly, no log


def main():
    port = int(os.environ.get("DASHBOARD_LISTEN_PORT", "8080"))
    Server(("0.0.0.0", port), Handler).serve_forever()


if __name__ == "__main__":
    sys.exit(main())
