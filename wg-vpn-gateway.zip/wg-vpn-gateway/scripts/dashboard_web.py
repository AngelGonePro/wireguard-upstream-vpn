#!/usr/bin/env python3
"""Read-only dashboard web server (COMPOSE_PROFILES contains "dashboard").

Serves a fixed set of files and nothing else: the page, its script/style, the
world map, and the collector's summary.json (mounted read-only). Only GET and
HEAD exist; there are no forms, uploads, logins or query parameters that do
anything, so the UI has no way to change data or the system. Runs as an
unprivileged user with no capabilities on a read-only filesystem.
"""
import os
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

STATIC = os.environ.get("DASHBOARD_STATIC", "/usr/local/share/wg-vpn-gateway/dashboard")
DATA = os.environ.get("DASHBOARD_PUBLIC", "/srv/data")

FILES = {   # url -> (directory, file, content type, cacheable)
    "/":               (STATIC, "index.html", "text/html; charset=utf-8", False),
    "/app.js":         (STATIC, "app.js", "text/javascript; charset=utf-8", False),
    "/style.css":      (STATIC, "style.css", "text/css; charset=utf-8", False),
    "/world.svg":      (STATIC, "world.svg", "image/svg+xml", True),
    "/countries.json": (STATIC, "countries.json", "application/json", True),
    "/summary.json":   (DATA, "summary.json", "application/json", False),
}
HEADERS = {
    "Content-Security-Policy": "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; "
                               "connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Cross-Origin-Resource-Policy": "same-origin",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=(), interest-cohort=()",
}
MAX_BODY = 32 * 1024 * 1024


class Handler(BaseHTTPRequestHandler):
    server_version = "dashboard"
    sys_version = ""
    protocol_version = "HTTP/1.1"
    timeout = 15                     # slow clients are dropped

    def log_message(self, *a):       # no access log: nothing is written anywhere
        pass

    def _send(self, code, body=b"", ctype="text/plain; charset=utf-8", extra=None, head=False):
        self.send_response(code)
        for k, v in HEADERS.items():
            self.send_header(k, v)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if not head:
            self.wfile.write(body)

    def _serve(self, head):
        path = self.path.split("?", 1)[0]
        entry = FILES.get(path)
        if not entry:
            return self._send(404, b"not found", head=head)
        d, name, ctype, cacheable = entry
        p = os.path.join(d, name)
        gz = "gzip" in (self.headers.get("Accept-Encoding") or "") and os.path.exists(p + ".gz")
        try:
            with open(p + ".gz" if gz else p, "rb") as f:
                body = f.read(MAX_BODY)
        except OSError:
            return self._send(503, b"no data yet - the collector writes it within a minute", head=head)
        extra = {"Cache-Control": "public, max-age=86400" if cacheable else "no-store"}
        if gz:
            extra["Content-Encoding"] = "gzip"
            extra["Vary"] = "Accept-Encoding"
        self._send(200, body, ctype, extra, head)

    def do_GET(self):
        self._serve(False)

    def do_HEAD(self):
        self._serve(True)

    def _deny(self):
        # any request body is never read: answer and close the connection
        self.close_connection = True
        self.send_response(405)
        for k, v in HEADERS.items():
            self.send_header(k, v)
        self.send_header("Allow", "GET, HEAD")
        self.send_header("Content-Length", "0")
        self.send_header("Connection", "close")
        self.end_headers()

    do_POST = do_PUT = do_DELETE = do_PATCH = do_OPTIONS = do_TRACE = do_CONNECT = _deny


class Server(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 32

    def handle_error(self, request, client_address):
        pass                         # broken/malformed clients: drop quietly, no log


def main():
    port = int(os.environ.get("DASHBOARD_LISTEN_PORT", "8080"))
    Server(("0.0.0.0", port), Handler).serve_forever()


if __name__ == "__main__":
    sys.exit(main())
