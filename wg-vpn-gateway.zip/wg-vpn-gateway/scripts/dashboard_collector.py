#!/usr/bin/env python3
"""Dashboard collector (COMPOSE_PROFILES contains "dashboard").

Once a minute it reads
  * this gateway's own counters — written by the guard to state/dashboard/inbox
    (blocklist hits in both directions, Suricata alerts/blocks), and
  * optionally an upstream host's blocklist counters (DASHBOARD_UPSTREAM_URL,
    e.g. the Linode blocklist's read-only stats endpoint over WireGuard),
turns the cumulative counters into per-day attempt counts, looks up each
address's country in a local copy of DB-IP's free IP-to-Country database, and
writes one JSON snapshot that the read-only web UI serves. History older than
DASHBOARD_RETENTION_DAYS is deleted; nothing else is logged.

Runs as an unprivileged user with no capabilities; it only ever writes its own
data directory (state/dashboard: db/, geo/, public/).
"""
import csv
import datetime
import gzip
import io
import ipaddress
import json
import os
import signal
import sqlite3
import time
import urllib.request

DATA = os.environ.get("DASHBOARD_DATA", "/data")
INBOX = os.path.join(DATA, "inbox", "local.json")
DB_PATH = os.path.join(DATA, "db", "dashboard.sqlite")
GEO_PATH = os.path.join(DATA, "geo", "country.sqlite")
OUT = os.path.join(DATA, "public", "summary.json")
UA = "wg-vpn-gateway-dashboard/1.0"


def env(k, d=""):
    v = os.environ.get(k, "").strip()
    return v if v else d


def env_int(k, d):
    try:
        return int(env(k, str(d)))
    except ValueError:
        return d


def log(msg):
    print(f"[dashboard] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}", flush=True)


def now():
    return int(time.time())


def today(ts=None):
    return datetime.datetime.fromtimestamp(ts or time.time(), datetime.timezone.utc).strftime("%Y-%m-%d")


# ------------------------------------------------------------------ geoip ---
def ip_key(ip):
    a = ipaddress.ip_address(ip)
    return (4, int(a)) if a.version == 4 else (6, f"{int(a):032x}")


DBIP_URL = "https://download.db-ip.com/free/dbip-country-lite-{month}.csv.gz"
# The same DB-IP Lite data (CC BY 4.0), republished on GitHub by the
# ip-location-db project — used when download.db-ip.com refuses the request
# (it blocks many VPN exit addresses).
MIRROR_URLS = ("https://raw.githubusercontent.com/sapics/ip-location-db/main/dbip-country/dbip-country-ipv4.csv "
               "https://raw.githubusercontent.com/sapics/ip-location-db/main/dbip-country/dbip-country-ipv6.csv")


def _ingest(g, url):
    """Stream one CSV (start,end,country — plain or .gz) into the database
    without holding the whole file in memory."""
    if url.startswith("file://"):
        f = open(url[7:], "rb")
    else:
        f = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": UA}), timeout=120)
    n = 0
    with f:
        text = io.TextIOWrapper(gzip.GzipFile(fileobj=f) if url.endswith(".gz") else f,
                                encoding="utf-8", errors="replace")
        batch4, batch6 = [], []
        for row in csv.reader(text):
            if len(row) < 3:
                continue
            try:
                v, s = ip_key(row[0])
                _, e = ip_key(row[1])
            except ValueError:
                continue
            (batch4 if v == 4 else batch6).append((s, e, row[2].strip().upper()[:2]))
            n += 1
            if len(batch4) + len(batch6) >= 20000:
                g.executemany("INSERT OR REPLACE INTO v4 VALUES (?,?,?)", batch4)
                g.executemany("INSERT OR REPLACE INTO v6 VALUES (?,?,?)", batch6)
                batch4, batch6 = [], []
        g.executemany("INSERT OR REPLACE INTO v4 VALUES (?,?,?)", batch4)
        g.executemany("INSERT OR REPLACE INTO v6 VALUES (?,?,?)", batch6)
    return n


def geo_refresh():
    """Monthly: download DB-IP IP-to-Country Lite (CC BY 4.0) and build a small
    indexed SQLite file from it — lookups then cost one index seek and almost no
    memory, instead of loading ~600k ranges into RAM. Tries DB-IP itself, then
    the GitHub copy (GEOIP_FALLBACK_URLS)."""
    meta_p = GEO_PATH + ".meta"
    try:
        meta = json.load(open(meta_p))
    except (OSError, ValueError):
        meta = {}
    have = os.path.exists(GEO_PATH)
    if have and now() - meta.get("built", 0) < 25 * 86400:
        return
    # a failed try waits 6 h when a copy exists, 30 min when there is none yet
    if now() - meta.get("tried", 0) < (6 * 3600 if have else 1800):
        return
    meta["tried"] = now()
    json.dump(meta, open(meta_p, "w"))
    tmpl = env("GEOIP_URL", DBIP_URL)
    d = datetime.date.today().replace(day=1)
    sources = [(m, [tmpl.replace("{month}", m)]) for m in
               (d.strftime("%Y-%m"), (d - datetime.timedelta(days=1)).strftime("%Y-%m"))]
    fallback = env("GEOIP_FALLBACK_URLS", MIRROR_URLS).replace(",", " ").split()
    if fallback:
        sources.append(("github copy", fallback))
    errors = []
    for name, urls in sources:
        tmp = GEO_PATH + ".tmp"
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
            g = sqlite3.connect(tmp)
            g.execute("CREATE TABLE v4 (s INTEGER PRIMARY KEY, e INTEGER, cc TEXT)")
            g.execute("CREATE TABLE v6 (s TEXT PRIMARY KEY, e TEXT, cc TEXT)")
            n = sum(_ingest(g, u) for u in urls)
            g.commit()
            g.close()
            if n < 1000:
                raise ValueError(f"only {n} ranges — not a valid country database")
            os.replace(tmp, GEO_PATH)
            meta.update({"built": now(), "month": name, "ranges": n})
            json.dump(meta, open(meta_p, "w"))
            geo_reset()
            log(f"country database updated ({name}, {n} ranges)")
            return
        except Exception as e:
            errors.append(f"{name}: {e.__class__.__name__}: {e}")
            try:
                g.close()
            except Exception:
                pass
    log("country database download failed (" + "; ".join(errors) + ") — "
        + ("keeping the previous copy" if have else "retrying in 30 min"))


_geo = {"conn": None, "cache": {}}


def geo_reset():
    """Forget cached lookups and reopen the database (after it was rebuilt)."""
    if _geo["conn"] is not None:
        _geo["conn"].close()
    _geo["conn"] = None
    _geo["cache"].clear()


def fix_unknown(c):
    """Addresses recorded while no country database existed yet are looked up
    again once one does."""
    if not os.path.exists(GEO_PATH):
        return
    for (ip,) in c.execute("SELECT DISTINCT ip FROM hits WHERE cc = '??'").fetchall():
        cc = country(ip)
        if cc != "??":
            c.execute("UPDATE hits SET cc = ? WHERE ip = ? AND cc = '??'", (cc, ip))


def country(ip):
    c = _geo["cache"].get(ip)
    if c is not None:
        return c
    cc = "??"
    try:
        if _geo["conn"] is None and os.path.exists(GEO_PATH):
            _geo["conn"] = sqlite3.connect(f"file:{GEO_PATH}?mode=ro", uri=True)
        if _geo["conn"] is not None:
            v, k = ip_key(ip)
            row = _geo["conn"].execute(f"SELECT e, cc FROM v{v} WHERE s <= ? ORDER BY s DESC LIMIT 1", (k,)).fetchone()
            if row and row[0] >= k:
                cc = row[1] or "??"
    except (ValueError, sqlite3.Error):
        pass
    if _geo["conn"] is None:
        return cc                    # no database yet: don't remember "unknown"
    if len(_geo["cache"]) > 20000:
        _geo["cache"].clear()
    _geo["cache"][ip] = cc
    return cc


# ----------------------------------------------------------------- store ---
def db():
    c = sqlite3.connect(DB_PATH)
    c.execute("PRAGMA journal_mode=DELETE")
    c.execute("""CREATE TABLE IF NOT EXISTS hits (
        day TEXT, source TEXT, dir TEXT, ip TEXT, label TEXT, vm TEXT, action TEXT,
        cc TEXT, n INTEGER, last INTEGER,
        PRIMARY KEY (day, source, dir, ip, label, vm, action))""")
    c.execute("CREATE TABLE IF NOT EXISTS last (k TEXT PRIMARY KEY, v INTEGER, t INTEGER)")
    return c


def add(c, counters, source, direction, ip, label, vm, action, cum, ts):
    """Turn a cumulative counter into new attempts since the last reading."""
    k = "|".join([source, direction, ip, label, vm, action])
    prev = counters.get(k)
    delta = cum - prev if prev is not None and cum >= prev else cum   # reset (rules reloaded / entry expired)
    counters[k] = cum
    c.execute("INSERT OR REPLACE INTO last VALUES (?,?,?)", (k, cum, ts))
    if delta <= 0:
        return
    c.execute("""INSERT INTO hits VALUES (?,?,?,?,?,?,?,?,?,?)
                 ON CONFLICT(day, source, dir, ip, label, vm, action)
                 DO UPDATE SET n = n + excluded.n, last = excluded.last""",
              (today(ts), source, direction, ip, label, vm, action, country(ip), delta, ts))


def collect(c):
    counters = {k: v for k, v in c.execute("SELECT k, v FROM last")}
    ts = now()
    upstream_status = None
    try:
        local = json.load(open(INBOX))
        if ts - local.get("ts", 0) > 600:
            local = None
    except (OSError, ValueError):
        local = None
    if local:
        for r in local.get("nft", []):
            ip = r.get("ip", "")
            if not ip:
                continue
            action = "blocked" if (local.get("modes") or {}).get(r.get("blocked", "trusted"), "block") == "block" else "monitored"
            add(c, counters, "home", r.get("kind", "in"), ip, r.get("list") or "blocklist",
                r.get("vm", "") if r.get("kind") == "out" else "", action, int(r.get("packets", 0)), ts)
        for r in local.get("suricata", []):
            ip = r.get("ip", "")
            if ip:
                add(c, counters, "suricata", r.get("dir", "in"), ip, (r.get("sig") or "")[:160], r.get("vm", ""),
                    "blocked" if r.get("action") == "blocked" else "alert", int(r.get("count", 0)), ts)
    url = env("DASHBOARD_UPSTREAM_URL")
    if url:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA,
                                                       "Authorization": f"Bearer {env('DASHBOARD_UPSTREAM_TOKEN')}"})
            with urllib.request.urlopen(req, timeout=10) as r:
                up = json.loads(r.read(5 * 1024 * 1024))
            name = env("DASHBOARD_UPSTREAM_NAME", "upstream")
            for h in up.get("hits", [])[:50000]:
                ip = str(h.get("ip", ""))
                try:
                    ipaddress.ip_address(ip)
                except ValueError:
                    continue
                add(c, counters, name, "in", ip, str(h.get("list") or "blocklist")[:80], "", "blocked",
                    int(h.get("packets", 0)), ts)
            upstream_status = "ok"
        except Exception as e:
            upstream_status = f"unreachable ({e.__class__.__name__})"
    # retention: attempts history + counter memory
    keep = max(1, env_int("DASHBOARD_RETENTION_DAYS", 7))
    cutoff = today(ts - (keep - 1) * 86400)
    c.execute("DELETE FROM hits WHERE day < ?", (cutoff,))
    c.execute("DELETE FROM last WHERE t < ?", (ts - 2 * 86400,))
    c.commit()
    return local is not None, upstream_status


# -------------------------------------------------------------- snapshot ---
def snapshot(c, local_ok, upstream_status):
    keep = max(1, env_int("DASHBOARD_RETENTION_DAYS", 7))
    days = [today(now() - i * 86400) for i in range(keep - 1, -1, -1)]
    views = {
        "all": ("1=1", ()),
        "inbound": ("dir = 'in' AND source != 'suricata'", ()),
        "outbound": ("dir = 'out' AND source != 'suricata'", ()),
        "suricata": ("source = 'suricata'", ()),
    }
    sources = [r[0] for r in c.execute("SELECT DISTINCT source FROM hits WHERE source NOT IN ('home','suricata')")]
    for s in sources:
        views[f"src:{s}"] = ("source = ?", (s,))
    views["src:home"] = ("source = 'home'", ())
    out = {"generated": now(), "retention_days": keep, "days": days, "views": {},
           "sources": {"home": "ok" if local_ok else "no data yet", **({env("DASHBOARD_UPSTREAM_NAME", "upstream"): upstream_status} if upstream_status else {})},
           "name": env("ALERT_NAME") or os.uname().nodename}
    for v, (where, args) in views.items():
        q = f"FROM hits WHERE {where}"
        total = c.execute(f"SELECT COALESCE(SUM(n),0), COUNT(DISTINCT ip) {q}", args).fetchone()
        top_ips = [{"ip": r[0], "cc": r[1], "n": r[2], "last": r[3], "label": r[4], "vm": r[5] or "",
                    "src": r[6], "dir": r[7], "action": r[8]}
                   for r in c.execute(f"""SELECT ip, cc, SUM(n) AS t, MAX(last),
                         (SELECT label FROM hits h2 WHERE h2.ip = hits.ip AND {where.replace('source', 'h2.source').replace('dir', 'h2.dir')} GROUP BY label ORDER BY SUM(n) DESC LIMIT 1),
                         GROUP_CONCAT(DISTINCT vm), GROUP_CONCAT(DISTINCT source), GROUP_CONCAT(DISTINCT dir), GROUP_CONCAT(DISTINCT action)
                         {q} GROUP BY ip ORDER BY t DESC LIMIT 100""", args + args)]
        countries = [{"cc": r[0], "n": r[1], "ips": r[2]}
                     for r in c.execute(f"SELECT cc, SUM(n), COUNT(DISTINCT ip) {q} GROUP BY cc ORDER BY SUM(n) DESC", args)]
        daily = dict(c.execute(f"SELECT day, SUM(n) {q} GROUP BY day", args).fetchall())
        recent = [{"ip": r[0], "cc": r[1], "last": r[2], "src": r[3], "dir": r[4], "label": r[5], "vm": r[6] or "", "action": r[7]}
                  for r in c.execute(f"""SELECT ip, cc, MAX(last), source, dir, label, vm, action {q}
                                         GROUP BY ip, source, dir ORDER BY MAX(last) DESC LIMIT 50""", args)]
        out["views"][v] = {"total": total[0], "unique_ips": total[1], "top_ips": top_ips, "countries": countries,
                           "daily": [daily.get(d, 0) for d in days], "recent": recent}
    tmp = OUT + ".tmp"
    with open(tmp, "w") as f:
        json.dump(out, f, separators=(",", ":"))
    os.chmod(tmp, 0o644)
    os.replace(tmp, OUT)


def main():
    for d in ("db", "geo", "public"):
        os.makedirs(os.path.join(DATA, d), exist_ok=True)
    stop = {"now": False}
    signal.signal(signal.SIGTERM, lambda *_: stop.update(now=True))
    interval = max(15, env_int("DASHBOARD_INTERVAL", 60))
    log("collector started" + (f" — upstream: {env('DASHBOARD_UPSTREAM_URL')}" if env("DASHBOARD_UPSTREAM_URL") else " — local data only"))
    last_up = None
    while not stop["now"]:
        try:
            geo_refresh()
            c = db()
            local_ok, up = collect(c)
            fix_unknown(c)
            c.commit()
            snapshot(c, local_ok, up)
            c.close()
            if up != last_up and env("DASHBOARD_UPSTREAM_URL"):
                log(f"upstream: {up}")
                last_up = up
        except Exception as e:
            log(f"collect failed: {e.__class__.__name__}: {e}")
        for _ in range(interval):
            if stop["now"]:
                break
            time.sleep(1)


if __name__ == "__main__":
    main()
