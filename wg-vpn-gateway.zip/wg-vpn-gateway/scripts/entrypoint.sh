#!/usr/bin/env bash
# wg-vpn-gateway — routes the whole host (host network namespace) through a
# WireGuard tunnel built from a user-supplied wg-quick config, while keeping:
#   * replies to inbound connections (SSH, published Docker ports, VPN servers
#     running on this host) on the real WAN interface
#   * every directly-connected / locally-routed subnet (LAN, Docker bridges,
#     SoftEther/WireGuard server subnets, etc.) off the tunnel
#   * explicit bypass destinations and outbound ports (default: SSH) off the tunnel
#
# Two layers:
#   base   — the bypass rules above (always installed while the gateway is in use)
#   tunnel — the route sending everything else into WireGuard
# With KILLSWITCH=true an "unreachable" rule sits after both, so whenever the
# tunnel route is missing (stopped, crashed, upgrading, interface gone) that
# traffic is blocked instead of leaving via the real IP. The base layer and the
# kill switch stay in place when the container stops; `release` removes them.
# With KILLSWITCH=false everything is removed again when the container stops.
set -Eeuo pipefail

log()  { echo "[wg-vpn-gateway] $*"; }
warn() { echo "[wg-vpn-gateway] WARNING: $*" >&2; }
die()  { echo "[wg-vpn-gateway] ERROR: $*" >&2; exit 1; }

# ---------------------------------------------------------------- settings ---
WG_CONFIG="${WG_CONFIG:-/config/wg.conf}"
WG_INTERFACE="${WG_INTERFACE:-wgvpn}"
WAN_INTERFACE="${WAN_INTERFACE:-}"
ROUTE_TABLE="${ROUTE_TABLE:-51888}"
ROUTE_MARK="${ROUTE_MARK:-0x1000000}"
RULE_PRIORITY="${RULE_PRIORITY:-32000}"
IPV6_MODE="${IPV6_MODE:-auto}"              # auto | on | off
IPTABLES_BACKEND="${IPTABLES_BACKEND:-auto}" # auto | nft | legacy
BYPASS_DESTINATIONS="${BYPASS_DESTINATIONS:-}"
BYPASS_OUT_TCP_PORTS="${BYPASS_OUT_TCP_PORTS:-22}"
BYPASS_OUT_UDP_PORTS="${BYPASS_OUT_UDP_PORTS:-}"
case "${KILLSWITCH:-false}" in
    [Tt]rue|1|[Yy]es|[Oo]n)        KS=1 ;;
    [Ff]alse|0|[Nn]o|[Oo]ff|"")     KS=0 ;;
    *) echo "[wg-vpn-gateway] ERROR: KILLSWITCH must be true or false" >&2; exit 1 ;;
esac

RUN_DIR=/run/wg-vpn-gateway
RUN_CONF="$RUN_DIR/$WG_INTERFACE.conf"
READY_FILE="$RUN_DIR/ready"   # health check only passes once THIS run finished setup
CHAIN_PRE=WGVPN_PRE
CHAIN_OUT=WGVPN_OUT
CHAIN_POSTM=WGVPN_POSTM
CHAIN_FWD=WGVPN_FWDBYPASS
CHAIN_MSS=WGVPN_MSS
CHAIN_NAT=WGVPN_NAT
CHAIN_KS=WGVPN_KS
KS_TABLE=$((ROUTE_TABLE + 1))
MARK="$ROUTE_MARK/$ROUTE_MARK"
P_MARK=$RULE_PRIORITY            # fwmark -> main (tunnel socket, inbound replies, port bypass)
P_DEST=$((RULE_PRIORITY + 1))    # BYPASS_DESTINATIONS -> main
P_MAIN=$((RULE_PRIORITY + 2))    # main without its default route (local subnets)
P_VPN=$((RULE_PRIORITY + 3))     # everything else -> tunnel table
P_KS=$((RULE_PRIORITY + 4))      # kill switch: anything the tunnel does not take -> lo (rejected)
P_KS2=$((RULE_PRIORITY + 5))     # kill switch backstop: unreachable

list() { tr ',' ' ' <<<"$1" | xargs -n1 2>/dev/null || true; }
is_v6() { [[ $1 == *:* ]]; }
fam_matches() { { [[ $1 == 6 ]] && is_v6 "$2"; } || { [[ $1 == 4 ]] && ! is_v6 "$2"; }; }
ipt_for() { if [[ $1 == 4 ]]; then echo "$IPT4"; else echo "$IPT6"; fi; }

# Does this host have IPv6 at all? (rules for a family the kernel lacks fail)
HOST_V6=0
[[ -e /proc/net/if_inet6 ]] && ip -6 rule show >/dev/null 2>&1 && HOST_V6=1

# ------------------------------------------------------------ iptables pick ---
pick_iptables() {
    local b="$IPTABLES_BACKEND"
    if [[ $b == auto ]]; then
        # Use whichever backend already holds the host's rules (Docker's, etc.)
        local nl nn
        nl=$( (iptables-legacy-save 2>/dev/null; ip6tables-legacy-save 2>/dev/null) | grep -c '^-' || true)
        nn=$( (iptables-nft-save 2>/dev/null; ip6tables-nft-save 2>/dev/null) | grep -c '^-' || true)
        if (( nl > nn )); then b=legacy; else b=nft; fi
    fi
    IPT4="iptables-$b"; IPT6="ip6tables-$b"
    command -v "$IPT4" >/dev/null || die "$IPT4 not found"
    log "iptables backend: $b"
}

# ---------------------------------------------------------------- teardown ---
ipt_unhook() { # family-cmd table parent chain
    local ipt=$1 t=$2 parent=$3 chain=$4
    while $ipt -w -t "$t" -D "$parent" -j "$chain" 2>/dev/null; do :; done
    $ipt -w -t "$t" -F "$chain" 2>/dev/null || true
    $ipt -w -t "$t" -X "$chain" 2>/dev/null || true
}

del_rules() { # fam priority...
    local fam=$1 pr; shift
    for pr in "$@"; do while ip -"$fam" rule del priority "$pr" 2>/dev/null; do :; done; done
}

wg_down() {
    if ip link show dev "$WG_INTERFACE" >/dev/null 2>&1; then
        if [[ -f $RUN_CONF ]]; then
            wg-quick down "$RUN_CONF" >/dev/null 2>&1 || ip link del dev "$WG_INTERFACE" 2>/dev/null || true
        else
            ip link del dev "$WG_INTERFACE" 2>/dev/null || true
        fi
    fi
}

teardown_tunnel() { # fam
    local fam=$1 ipt; ipt=$(ipt_for "$fam")
    del_rules "$fam" $P_VPN
    ip -"$fam" route flush table "$ROUTE_TABLE" 2>/dev/null || true
    command -v "$ipt" >/dev/null && ipt_unhook "$ipt" nat POSTROUTING $CHAIN_NAT
    return 0
}

teardown_base() { # fam
    local fam=$1 ipt; ipt=$(ipt_for "$fam")
    del_rules "$fam" $P_MARK $P_DEST $P_MAIN
    command -v "$ipt" >/dev/null || return 0
    ipt_unhook "$ipt" mangle PREROUTING  $CHAIN_PRE
    ipt_unhook "$ipt" mangle OUTPUT      $CHAIN_OUT
    ipt_unhook "$ipt" mangle POSTROUTING $CHAIN_POSTM
    ipt_unhook "$ipt" mangle FORWARD     $CHAIN_MSS
    $ipt -w -t mangle -F $CHAIN_FWD 2>/dev/null || true
    $ipt -w -t mangle -X $CHAIN_FWD 2>/dev/null || true
}

families() { echo 4; (( HOST_V6 )) && echo 6; return 0; }

# Remove everything this gateway installs; keep the kill switch rule if asked.
teardown_all() { # keep_ks(0|1)
    local fam
    rm -f "$READY_FILE"
    for fam in $(families); do
        teardown_tunnel "$fam"
        teardown_base "$fam"
        [[ $1 == 1 ]] || ks_remove "$fam"
    done
    wg_down
}

wan_addr() { # fam -> primary global address of the WAN interface
    ip -"$1" -o addr show dev "$WAN_INTERFACE" scope global 2>/dev/null \
        | awk '{ split($4, a, "/"); print a[1]; exit }'
}

# Kill switch. Traffic the tunnel doesn't take is routed to the loopback
# interface (not "unreachable" outright): the host's own replies and bypass
# connections get their first route lookup before netfilter can mark them, so
# they need a route that succeeds and is then re-routed to the WAN by their
# mark. Anything unmarked heads to lo with a non-local destination and is
# rejected there. lo exists on every host — no kernel module needed.
# Idempotent; never removed first. The "unreachable" backstop is only added
# once the lo route exists, so a failure here can never block inbound SSH.
ks_install() { # fam
    local fam=$1 ipt src rj
    ipt=$(ipt_for "$fam")
    if [[ $fam == 4 ]]; then rj=icmp-net-unreachable; else rj=icmp6-no-route; fi
    $ipt -w -t filter -N $CHAIN_KS 2>/dev/null || true
    # "! --mark": in OUTPUT the filter still sees the interface of the FIRST
    # route lookup (lo) even after a mark re-routed the packet to the WAN, so
    # marked packets (SSH replies, bypasses) must be excluded explicitly.
    # Refilling this chain is safe: blocking comes from the lo route below,
    # these rules only turn "silently dropped" into an immediate error.
    local m=(-o lo -m mark ! --mark "$MARK" -m addrtype ! --dst-type LOCAL)
    $ipt -w -t filter -F $CHAIN_KS
    $ipt -w -t filter -A $CHAIN_KS "${m[@]}" -p tcp -j REJECT --reject-with tcp-reset || return 1
    $ipt -w -t filter -A $CHAIN_KS "${m[@]}" -j REJECT --reject-with $rj || return 1
    $ipt -w -t filter -C OUTPUT  -j $CHAIN_KS 2>/dev/null || $ipt -w -t filter -I OUTPUT 1  -j $CHAIN_KS || return 1
    $ipt -w -t filter -C FORWARD -j $CHAIN_KS 2>/dev/null || $ipt -w -t filter -I FORWARD 1 -j $CHAIN_KS || return 1
    src=$(wan_addr "$fam")
    if [[ -n $src ]]; then
        ip -"$fam" route replace default dev lo src "$src" table "$KS_TABLE" || return 1
    else
        ip -"$fam" route replace default dev lo table "$KS_TABLE" || return 1
    fi
    ip -"$fam" rule show priority $P_KS  | grep -q . || ip -"$fam" rule add priority $P_KS lookup "$KS_TABLE" || return 1
    ip -"$fam" rule show priority $P_KS2 | grep -q . || ip -"$fam" rule add priority $P_KS2 unreachable
}

ks_remove() { # fam
    local fam=$1 ipt; ipt=$(ipt_for "$fam")
    del_rules "$fam" $P_KS $P_KS2
    ip -"$fam" route flush table "$KS_TABLE" 2>/dev/null || true
    if command -v "$ipt" >/dev/null; then
        while $ipt -w -t filter -D OUTPUT  -j $CHAIN_KS 2>/dev/null; do :; done
        while $ipt -w -t filter -D FORWARD -j $CHAIN_KS 2>/dev/null; do :; done
        $ipt -w -t filter -F $CHAIN_KS 2>/dev/null || true
        $ipt -w -t filter -X $CHAIN_KS 2>/dev/null || true
    fi
    return 0
}

declare -A BASE_UP=()

on_exit() {
    local rc=$? fam
    trap - EXIT INT TERM
    if (( KS )); then
        log "stopping — kill switch ON: removing the tunnel, keeping the block in place"
        rm -f "$READY_FILE"
        for fam in $(families); do teardown_tunnel "$fam"; done
        wg_down
        # Inbound SSH / bypass ports must keep working while blocked.
        for fam in "${!BASE_WANTED[@]}"; do
            if [[ -z ${BASE_UP[$fam]:-} ]]; then
                teardown_base "$fam"
                setup_base "$fam" 2>/dev/null || warn "could not restore bypass rules (IPv$fam)"
            fi
            ks_install "$fam" 2>/dev/null || true
        done
        log "outbound traffic is BLOCKED until the gateway is running again"
        log "(inbound connections, local networks and your bypasses still work;"
        log " to lift the block: set KILLSWITCH=false and start it, or run"
        log " 'docker compose run --rm wg-vpn-gateway release')"
    else
        log "stopping — removing tunnel, rules and routes"
        teardown_all 0
        log "host routing restored"
    fi
    exit "$rc"
}

# ------------------------------------------------------------ config prep ---
prepare_config() {
    # Validate settings before anything is installed, so a typo can never
    # leave the kill switch up without the SSH/bypass rules.
    local port
    for port in $(list "$BYPASS_OUT_TCP_PORTS") $(list "$BYPASS_OUT_UDP_PORTS"); do
        [[ $port =~ ^[0-9]+(:[0-9]+)?$ ]] || die "bad port '$port' in BYPASS_OUT_TCP_PORTS / BYPASS_OUT_UDP_PORTS"
    done
    local d
    for d in $(list "$BYPASS_DESTINATIONS"); do
        [[ $d =~ ^[0-9a-fA-F.:]+(/[0-9]{1,3})?$ ]] || die "bad entry '$d' in BYPASS_DESTINATIONS (IPs/CIDRs only)"
    done
    [[ -r $WG_CONFIG ]] || die "WireGuard config not found at $WG_CONFIG (check WG_CONFIG_FILE in .env)"
    [[ $WG_INTERFACE =~ ^[a-zA-Z0-9_=+.-]{1,15}$ ]] || die "invalid WG_INTERFACE '$WG_INTERFACE'"
    mkdir -p "$RUN_DIR"; chmod 700 "$RUN_DIR"
    # Strip keys this container manages itself; inject Table=off + our FwMark.
    awk -v mark="$ROUTE_MARK" '
        { sub(/\r$/, ""); low = tolower($0) }
        low ~ /^[[:space:]]*\[/ {
            sect = low; gsub(/[^a-z]/, "", sect)
            print
            if (sect == "interface") { print "Table = off"; print "FwMark = " mark }
            next
        }
        sect == "interface" && low ~ /^[[:space:]]*(dns|table|fwmark|saveconfig)[[:space:]]*=/ { next }
        { print }
    ' "$WG_CONFIG" > "$RUN_CONF"
    chmod 600 "$RUN_CONF"
    grep -qi '^[[:space:]]*\[peer\]' "$RUN_CONF" || die "config has no [Peer] section"

    # Tunnel addresses (needed for NAT + IPv6 decision)
    mapfile -t WG_ADDRS < <(awk '
        { low = tolower($0) }
        low ~ /^[[:space:]]*\[/ { sect = low; gsub(/[^a-z]/, "", sect); next }
        sect == "interface" && low ~ /^[[:space:]]*address[[:space:]]*=/ { sub(/^[^=]*=/, ""); print }' "$RUN_CONF" \
        | tr ',' '\n' | sed 's/[[:space:]]//g; /^$/d')
    (( ${#WG_ADDRS[@]} )) || die "config [Interface] has no Address"
    HAVE_V4=0; HAVE_V6=0
    local a; for a in "${WG_ADDRS[@]}"; do if is_v6 "$a"; then HAVE_V6=1; else HAVE_V4=1; fi; done
    (( HAVE_V4 )) || die "config has no IPv4 Address — this container routes IPv4 through the tunnel"

    case "$IPV6_MODE" in
        on)   (( HAVE_V6 )) || die "IPV6_MODE=on but the config has no IPv6 Address"; ROUTE_V6=1 ;;
        off)  ROUTE_V6=0 ;;
        auto) ROUTE_V6=$HAVE_V6 ;;
        *)    die "IPV6_MODE must be auto, on or off" ;;
    esac

    # Does any Endpoint use a hostname? (needs DNS before the tunnel is up)
    ENDPOINT_HOSTNAME=0
    local ep host
    while IFS= read -r ep; do
        host=${ep%:*}; host=${host#[}; host=${host%]}
        if ! [[ $host =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ || $host == *:* ]]; then ENDPOINT_HOSTNAME=1; fi
    done < <(awk '{ low = tolower($0) } low ~ /^[[:space:]]*endpoint[[:space:]]*=/ { sub(/^[^=]*=/, ""); gsub(/[[:space:]]/, ""); print }' "$RUN_CONF")
}

# --------------------------------------------------------------- routing ---
# Base layer: everything that must keep using the real IP / local routes.
setup_base() { # 4|6
    local fam=$1 ipt addr port proto ports
    ipt=$(ipt_for "$fam")
    command -v "$ipt" >/dev/null || die "$ipt not found"

    # Policy rules (lower number = evaluated first). Rules other tools install
    # at lower priorities (Tailscale 52xx, etc.) keep working untouched.
    ip -"$fam" rule add priority $P_MARK fwmark "$MARK" lookup main
    for addr in $(list "$BYPASS_DESTINATIONS"); do
        fam_matches "$fam" "$addr" && ip -"$fam" rule add priority $P_DEST to "$addr" lookup main
    done
    # Always local, never tunnelled or kill-switched: link-local (e.g. cloud
    # metadata 169.254.169.254), multicast (mDNS/SSDP) and limited broadcast.
    # The kernel has no specific routes for these, so without this they would
    # follow the default route into the tunnel.
    if [[ $fam == 4 ]]; then
        for addr in 169.254.0.0/16 224.0.0.0/4 255.255.255.255/32; do
            ip -4 rule add priority $P_DEST to "$addr" lookup main
        done
    fi
    ip -"$fam" rule add priority $P_MAIN lookup main suppress_prefixlength 0

    # --- mangle: connection marks ---
    $ipt -w -t mangle -N $CHAIN_PRE
    $ipt -w -t mangle -N $CHAIN_OUT
    $ipt -w -t mangle -N $CHAIN_POSTM
    # restore the connection's mark onto every packet of a marked connection
    # (only when the connection carries it — an unconditional restore would
    # clear the mark the WireGuard socket sets on its own packets → loop)
    $ipt -w -t mangle -A $CHAIN_PRE -m connmark --mark "$MARK" -j CONNMARK --restore-mark --nfmask "$ROUTE_MARK" --ctmask "$ROUTE_MARK"
    $ipt -w -t mangle -A $CHAIN_OUT -m connmark --mark "$MARK" -j CONNMARK --restore-mark --nfmask "$ROUTE_MARK" --ctmask "$ROUTE_MARK"
    # any connection seen arriving on the WAN interface stays on the WAN —
    # new inbound connections, and connections that already existed when the
    # gateway started (e.g. the SSH session you started it from)
    $ipt -w -t mangle -A $CHAIN_PRE -i "$WAN_INTERFACE" -j CONNMARK --set-xmark "$MARK"
    $ipt -w -t mangle -A $CHAIN_PRE -i "$WAN_INTERFACE" -j MARK --set-xmark "$MARK"
    # outbound port bypass: local processes (OUTPUT) and forwarded traffic
    # from containers / local VPN clients (PREROUTING, not from WAN or tunnel)
    $ipt -w -t mangle -N $CHAIN_FWD
    $ipt -w -t mangle -A $CHAIN_FWD -i "$WAN_INTERFACE" -j RETURN
    $ipt -w -t mangle -A $CHAIN_FWD -i "$WG_INTERFACE" -j RETURN
    for proto in tcp udp; do
        if [[ $proto == tcp ]]; then ports=$BYPASS_OUT_TCP_PORTS; else ports=$BYPASS_OUT_UDP_PORTS; fi
        for port in $(list "$ports"); do
            $ipt -w -t mangle -A $CHAIN_OUT -p $proto --dport "$port" -m conntrack --ctstate NEW \
                -j MARK --set-xmark "$MARK"
            $ipt -w -t mangle -A $CHAIN_FWD -p $proto --dport "$port" -j MARK --set-xmark "$MARK"
        done
    done
    $ipt -w -t mangle -A $CHAIN_PRE -m conntrack --ctstate NEW -j $CHAIN_FWD
    # persist any mark set above (and the tunnel socket's own mark) on the connection
    $ipt -w -t mangle -A $CHAIN_OUT   -m mark --mark "$MARK" -j CONNMARK --save-mark --nfmask "$ROUTE_MARK" --ctmask "$ROUTE_MARK"
    $ipt -w -t mangle -A $CHAIN_PRE   -m mark --mark "$MARK" -j CONNMARK --save-mark --nfmask "$ROUTE_MARK" --ctmask "$ROUTE_MARK"
    $ipt -w -t mangle -A $CHAIN_POSTM -m mark --mark "$MARK" -j CONNMARK --save-mark --nfmask "$ROUTE_MARK" --ctmask "$ROUTE_MARK"
    $ipt -w -t mangle -I PREROUTING  1 -j $CHAIN_PRE
    $ipt -w -t mangle -I OUTPUT      1 -j $CHAIN_OUT
    $ipt -w -t mangle -I POSTROUTING 1 -j $CHAIN_POSTM

    # Forwarded TCP (Docker containers, SoftEther/OpenVPN/WireGuard clients of
    # servers on this host) usually comes from 1500-MTU interfaces; clamp its
    # MSS to the tunnel's MTU so large transfers don't stall on internet paths
    # that drop ICMP "fragmentation needed".
    $ipt -w -t mangle -N $CHAIN_MSS
    $ipt -w -t mangle -A $CHAIN_MSS -o "$WG_INTERFACE" -p tcp --tcp-flags SYN,RST SYN \
        -j TCPMSS --clamp-mss-to-pmtu
    $ipt -w -t mangle -I FORWARD 1 -j $CHAIN_MSS
    BASE_UP[$fam]=1
}

# Tunnel layer: everything else goes into WireGuard.
setup_tunnel() { # 4|6
    local fam=$1 ipt addr
    ipt=$(ipt_for "$fam")
    ip -"$fam" route replace default dev "$WG_INTERFACE" table "$ROUTE_TABLE"
    ip -"$fam" rule add priority $P_VPN lookup "$ROUTE_TABLE"

    $ipt -w -t nat -N $CHAIN_NAT
    # forwarded traffic (Docker containers, clients of VPN servers on this host)
    # leaving through the tunnel must carry the tunnel address
    for addr in "${WG_ADDRS[@]}"; do
        if fam_matches "$fam" "$addr"; then
            $ipt -w -t nat -A $CHAIN_NAT -o "$WG_INTERFACE" -s "${addr%/*}" -j RETURN
            # a socket that picked the tunnel address before being re-routed
            # to the WAN by a bypass mark needs the WAN address instead
            $ipt -w -t nat -A $CHAIN_NAT -o "$WAN_INTERFACE" -s "${addr%/*}" -j MASQUERADE
        fi
    done
    $ipt -w -t nat -A $CHAIN_NAT -o "$WG_INTERFACE" -j MASQUERADE
    $ipt -w -t nat -I POSTROUTING 1 -j $CHAIN_NAT
}

set_sysctl() { # key value
    local f="/proc/sys/${1//.//}"
    [[ -e $f ]] || return 0
    if ! echo "$2" > "$f" 2>/dev/null; then
        warn "could not set $1=$2 (is the container privileged?)"
        return 1
    fi
}

# --------------------------------------------------------------- release ---
# `docker compose run --rm wg-vpn-gateway release` — remove everything,
# including a kill switch left behind by a stopped gateway.
if [[ ${1:-} == release ]]; then
    pick_iptables
    teardown_all 0
    log "released — kill switch and all gateway rules removed, host routing restored"
    exit 0
fi

# ------------------------------------------------------------------ main ---
rm -f "$READY_FILE"
pick_iptables
prepare_config

if [[ -z $WAN_INTERFACE ]]; then
    WAN_INTERFACE=$(ip -4 route show table main default | awk '{for(i=1;i<NF;i++) if($i=="dev"){print $(i+1); exit}}')
    [[ -n $WAN_INTERFACE ]] || die "could not detect the WAN interface — set WAN_INTERFACE in .env"
fi
ip link show dev "$WAN_INTERFACE" >/dev/null 2>&1 || die "WAN interface '$WAN_INTERFACE' does not exist"
[[ $WAN_INTERFACE != "$WG_INTERFACE" ]] || die "WAN_INTERFACE and WG_INTERFACE must differ"
(( ROUTE_V6 == 0 || HOST_V6 == 1 )) || die "config has an IPv6 Address but this host has no IPv6 — set IPV6_MODE=off"

# Families that get the base layer: IPv4 always; IPv6 when it is tunnelled, or
# when the kill switch must also stop native IPv6 from leaving via the real IP.
declare -A BASE_WANTED=([4]=1)
(( ROUTE_V6 )) && BASE_WANTED[6]=1
(( KS && HOST_V6 )) && BASE_WANTED[6]=1

log "WAN interface: $WAN_INTERFACE | tunnel interface: $WG_INTERFACE | IPv6 through tunnel: $([[ $ROUTE_V6 == 1 ]] && echo yes || echo no) | kill switch: $( (( KS )) && echo ON || echo off)"

trap on_exit EXIT
trap 'exit 0' INT TERM

# Kill switch first, so nothing leaks while the rest is rebuilt below.
if (( KS )); then for fam in "${!BASE_WANTED[@]}"; do ks_install "$fam"; done; fi
teardown_all "$KS"   # clear leftovers from an earlier run (keeps the kill switch if on)

# Reverse-path filtering must honour fwmarks, or replies to marked (WAN)
# connections are dropped when rp_filter is strict.
set_sysctl net.ipv4.conf.all.src_valid_mark 1 || true
[[ -e /proc/sys/net/ipv4/ip_forward ]] && [[ $(cat /proc/sys/net/ipv4/ip_forward) == 1 ]] \
    || set_sysctl net.ipv4.ip_forward 1 || true

for fam in "${!BASE_WANTED[@]}"; do setup_base "$fam"; done

# With the kill switch on, a hostname Endpoint can't be resolved over the
# (not yet existing) tunnel — allow DNS out directly just while it comes up.
DNS_WINDOW=0
if (( KS && ENDPOINT_HOSTNAME )); then
    for fam in "${!BASE_WANTED[@]}"; do
        ip -"$fam" rule add priority $P_MARK ipproto udp dport 53 lookup main
        ip -"$fam" rule add priority $P_MARK ipproto tcp dport 53 lookup main
    done
    DNS_WINDOW=1
fi

log "bringing up tunnel from $(basename "$WG_CONFIG")"
wg-quick up "$RUN_CONF"

if (( DNS_WINDOW )); then
    for fam in "${!BASE_WANTED[@]}"; do
        ip -"$fam" rule del priority $P_MARK ipproto udp dport 53 lookup main 2>/dev/null || true
        ip -"$fam" rule del priority $P_MARK ipproto tcp dport 53 lookup main 2>/dev/null || true
    done
fi

setup_tunnel 4
(( ROUTE_V6 )) && setup_tunnel 6

: > "$READY_FILE"
log "host traffic now routed through $WG_INTERFACE"
log "bypass: inbound connections on $WAN_INTERFACE, local subnets, tcp ports [${BYPASS_OUT_TCP_PORTS:-none}], udp ports [${BYPASS_OUT_UDP_PORTS:-none}], destinations [${BYPASS_DESTINATIONS:-none}]"
(( KS )) && log "kill switch ON: if the tunnel goes away, all other outbound traffic is blocked"
wg show "$WG_INTERFACE" | sed 's/^/    /'

# Stay in the foreground until docker stops us; then the EXIT trap cleans up.
sleep infinity & wait $!
