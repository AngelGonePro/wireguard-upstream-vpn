#!/usr/bin/env bash
# wg-vpn-gateway — routes a whole host's outgoing traffic through a VPN while
# keeping inbound connections, local networks and chosen bypasses working.
#
# MODE=standalone  this VM has the WireGuard config and tunnels only itself
#                  (plus its Docker containers / VPN-server clients)
# MODE=gateway     same, and other VMs listed in GATEWAY_CLIENTS may send their
#                  internet traffic through it (one WireGuard config for all)
# MODE=client      no WireGuard here: internet traffic goes to GATEWAY_IP, a
#                  VM running MODE=gateway on the same local network
#
# Layers:
#   base   — bypass rules (inbound replies, local networks, bypass ports and
#            destinations); stays installed while the gateway is in use
#   tunnel — the route sending everything else into WireGuard (or to the
#            gateway VM in client mode)
#   split tunnel (optional, SPLIT_TUNNEL_DESTINATIONS) — a second WireGuard
#            config that carries only the listed destinations (e.g. your own
#            server), while everything else uses the main config
#   kill switch (KILLSWITCH=true) — when the tunnel route is missing (stopped,
#            crashed, upgrading, VPN or gateway VM down) that traffic is
#            blocked instead of leaving via the real IP. Stays in place when
#            the container stops; `release` removes it.
set -Eeuo pipefail

log()  { echo "[wg-vpn-gateway] $*"; }
warn() { echo "[wg-vpn-gateway] WARNING: $*" >&2; }
die()  { echo "[wg-vpn-gateway] ERROR: $*" >&2; exit 1; }

# ---------------------------------------------------------------- settings ---
MODE="${MODE:-standalone}"
WG_CONFIG="${WG_CONFIG:-/config/wg.conf}"
WG_INTERFACE="${WG_INTERFACE:-wgvpn}"
WAN_INTERFACE="${WAN_INTERFACE:-}"
ROUTE_TABLE="${ROUTE_TABLE:-51888}"
ROUTE_MARK="${ROUTE_MARK:-0x1000000}"
RULE_PRIORITY="${RULE_PRIORITY:-32000}"
IPV6_MODE="${IPV6_MODE:-auto}"              # auto | on | off
IPTABLES_BACKEND="${IPTABLES_BACKEND:-auto}" # auto | nft | legacy
BYPASS_DESTINATIONS="${BYPASS_DESTINATIONS:-}"
BYPASS_OUT_TCP_PORTS="${BYPASS_OUT_TCP_PORTS:-22}"
BYPASS_OUT_UDP_PORTS="${BYPASS_OUT_UDP_PORTS:-}"
GATEWAY_CLIENTS="${GATEWAY_CLIENTS:-}"      # gateway mode: ip[/cidr][=name],...
GATEWAY_IP="${GATEWAY_IP:-}"                # client mode: LAN IP of the gateway VM
SURICATA_QUEUE="${SURICATA_QUEUE:-0}"
# Connection mark Suricata sets on a connection it has finished inspecting
# (encrypted after the TLS handshake, or past the inspected first part);
# the rest of that connection then skips the queue.
SURICATA_BYPASS_MARK="${SURICATA_BYPASS_MARK:-0x4000000}"
SPLIT_DESTS="${SPLIT_TUNNEL_DESTINATIONS:-}"  # destinations for the second tunnel (empty = off)
SPLIT_IF="${SPLIT_TUNNEL_INTERFACE:-wgsplit}"
SPLIT_CONFIG="${SPLIT_CONFIG:-/config/wg-split.conf}"
is_true() { case "${1:-}" in [Tt]rue|1|[Yy]es|[Oo]n) return 0 ;; *) return 1 ;; esac; }
case "${KILLSWITCH:-false}" in
    [Tt]rue|1|[Yy]es|[Oo]n)        KS=1 ;;
    [Ff]alse|0|[Nn]o|[Oo]ff|"")     KS=0 ;;
    *) echo "[wg-vpn-gateway] ERROR: KILLSWITCH must be true or false" >&2; exit 1 ;;
esac
case "$MODE" in standalone|gateway|client) ;; *) die "MODE must be standalone, gateway or client" ;; esac
IPS=0
[[ $MODE != client ]] && [[ ,${COMPOSE_PROFILES:-}, == *,suricata,* ]] && IPS=1
SPLIT=0
[[ $MODE != client && -n ${SPLIT_DESTS//[ ,]/} ]] && SPLIT=1

RUN_DIR="${RUN_DIR:-/run/wg-vpn-gateway}"
RUN_CONF="$RUN_DIR/$WG_INTERFACE.conf"
SPLIT_RUN_CONF="$RUN_DIR/$SPLIT_IF.conf"
READY_FILE="$RUN_DIR/ready"   # health check only passes once THIS run finished setup
CHAIN_PRE=WGVPN_PRE
CHAIN_OUT=WGVPN_OUT
CHAIN_POSTM=WGVPN_POSTM
CHAIN_FWD=WGVPN_FWDBYPASS
CHAIN_WAN=WGVPN_WANMARK
CHAIN_MSS=WGVPN_MSS
CHAIN_NAT=WGVPN_NAT
CHAIN_KS=WGVPN_KS
CHAIN_GW=WGVPN_GW
CHAIN_IPS=WGVPN_IPS
KS_TABLE=$((ROUTE_TABLE + 1))
MARK="$ROUTE_MARK/$ROUTE_MARK"
# client mode: connections this VM sent toward the gateway VM; their replies
# arrive on the LAN interface but must not be treated as inbound
VIA_MARK="${CLIENT_VIA_MARK:-0x2000000}"
VIA="$VIA_MARK/$VIA_MARK"
P_MARK=$RULE_PRIORITY            # fwmark -> main (tunnel socket, inbound replies, port bypass)
P_DEST=$((RULE_PRIORITY + 1))    # BYPASS_DESTINATIONS -> main
P_MAIN=$((RULE_PRIORITY + 2))    # main without its default route (local subnets)
P_VPN=$((RULE_PRIORITY + 3))     # everything else -> tunnel table
P_KS=$((RULE_PRIORITY + 4))      # kill switch: anything the tunnel does not take -> lo (rejected)
P_KS2=$((RULE_PRIORITY + 5))     # kill switch backstop: unreachable

list() { tr ',' ' ' <<<"$1" | xargs -n1 2>/dev/null || true; }
is_v6() { [[ $1 == *:* ]]; }
fam_matches() { { [[ $1 == 6 ]] && is_v6 "$2"; } || { [[ $1 == 4 ]] && ! is_v6 "$2"; }; }
ipt_for() { if [[ $1 == 4 ]]; then echo "$IPT4"; else echo "$IPT6"; fi; }
# tunnel interfaces this run manages (main, plus the split tunnel if used)
tunnels() { echo "$WG_INTERFACE"; (( SPLIT )) && echo "$SPLIT_IF"; return 0; }
is_cidr() { [[ $1 =~ ^[0-9a-fA-F.:]+(/[0-9]{1,3})?$ ]]; }
client_addrs() { local e; for e in $(list "$GATEWAY_CLIENTS"); do echo "${e%%=*}"; done; }

# Does this host have IPv6 at all? (rules for a family the kernel lacks fail)
HOST_V6=0
[[ -e /proc/net/if_inet6 ]] && ip -6 rule show >/dev/null 2>&1 && HOST_V6=1

# ------------------------------------------------------------ iptables pick ---
pick_iptables() {
    local b="$IPTABLES_BACKEND"
    if [[ $b == auto ]]; then
        # Use whichever backend already holds the host's rules (Docker's, etc.)
        local nl nn
        nl=$( (iptables-legacy-save 2>/dev/null; ip6tables-legacy-save 2>/dev/null) | grep -c '^-' || true)
        nn=$( (iptables-nft-save 2>/dev/null; ip6tables-nft-save 2>/dev/null) | grep -c '^-' || true)
        if (( nl > nn )); then b=legacy; else b=nft; fi
    fi
    IPT4="iptables-$b"; IPT6="ip6tables-$b"
    command -v "$IPT4" >/dev/null || die "$IPT4 not found"
    log "iptables backend: $b"
}

# ---------------------------------------------------------------- teardown ---
ipt_unhook() { # family-cmd table parent chain
    local ipt=$1 t=$2 parent=$3 chain=$4
    while $ipt -w -t "$t" -D "$parent" -j "$chain" 2>/dev/null; do :; done
    $ipt -w -t "$t" -F "$chain" 2>/dev/null || true
    $ipt -w -t "$t" -X "$chain" 2>/dev/null || true
}

del_rules() { # fam priority...
    local fam=$1 pr; shift
    for pr in "$@"; do while ip -"$fam" rule del priority "$pr" 2>/dev/null; do :; done; done
}

wg_down() {
    [[ $MODE == client ]] && return 0
    local ifc conf
    for ifc in "$WG_INTERFACE" "$SPLIT_IF"; do
        ip link show dev "$ifc" >/dev/null 2>&1 || continue
        conf="$RUN_DIR/$ifc.conf"
        if [[ -f $conf ]]; then
            wg-quick down "$conf" >/dev/null 2>&1 || ip link del dev "$ifc" 2>/dev/null || true
        else
            ip link del dev "$ifc" 2>/dev/null || true
        fi
    done
}

teardown_tunnel() { # fam
    local fam=$1 ipt; ipt=$(ipt_for "$fam")
    del_rules "$fam" $P_VPN
    ip -"$fam" route flush table "$ROUTE_TABLE" 2>/dev/null || true
    command -v "$ipt" >/dev/null || return 0
    ipt_unhook "$ipt" nat POSTROUTING $CHAIN_NAT
    # (the current hooks, and the ones older releases installed)
    local h ifc; for ifc in "$WG_INTERFACE" "$SPLIT_IF"; do for h in "POSTROUTING -o" "FORWARD -i" "INPUT -i"; do
        while $ipt -w -t mangle -D ${h% *} ${h#* } "$ifc" -j $CHAIN_IPS 2>/dev/null; do :; done
    done; done
    while $ipt -w -t mangle -D PREROUTING  -j $CHAIN_IPS 2>/dev/null; do :; done
    ipt_unhook "$ipt" mangle POSTROUTING $CHAIN_IPS
    nft delete table inet wgvpn_ips 2>/dev/null || true; rm -f "$RUN_DIR/ips_nft"
    return 0
}

teardown_base() { # fam
    local fam=$1 ipt; ipt=$(ipt_for "$fam")
    del_rules "$fam" $P_MARK $P_DEST $P_MAIN
    command -v "$ipt" >/dev/null || return 0
    ipt_unhook "$ipt" mangle PREROUTING  $CHAIN_PRE
    ipt_unhook "$ipt" mangle OUTPUT      $CHAIN_OUT
    ipt_unhook "$ipt" mangle POSTROUTING $CHAIN_POSTM
    ipt_unhook "$ipt" mangle FORWARD     $CHAIN_MSS
    ipt_unhook "$ipt" filter FORWARD     $CHAIN_GW
    local c; for c in $CHAIN_FWD $CHAIN_WAN; do
        $ipt -w -t mangle -F $c 2>/dev/null || true
        $ipt -w -t mangle -X $c 2>/dev/null || true
    done
}

families() { echo 4; (( HOST_V6 )) && echo 6; return 0; }

# Remove everything this gateway installs; keep the kill switch rule if asked.
teardown_all() { # keep_ks(0|1)
    local fam
    rm -f "$READY_FILE"
    for fam in $(families); do
        teardown_tunnel "$fam"
        teardown_base "$fam"
        [[ $1 == 1 ]] || ks_remove "$fam"
    done
    nft delete table inet wgvpn_guard 2>/dev/null || true
    wg_down
}

wan_addr() { # fam -> primary global address of the WAN interface
    wan_addrs "$1" | head -n1
}
wan_addrs() { # fam -> every global address of the WAN interface
    ip -"$1" -o addr show dev "$WAN_INTERFACE" scope global 2>/dev/null \
        | awk '{ split($4, a, "/"); print a[1] }'
}

# Kill switch. Traffic the tunnel doesn't take is routed to the loopback
# interface (not "unreachable" outright): the host's own replies and bypass
# connections get their first route lookup before netfilter can mark them, so
# they need a route that succeeds and is then re-routed to the WAN by their
# mark. Anything unmarked heads to lo with a non-local destination and is
# rejected there. lo exists on every host — no kernel module needed.
# Idempotent; never removed first. The "unreachable" backstop is only added
# once the lo route exists, so a failure here can never block inbound SSH.
ks_install() { # fam
    local fam=$1 ipt src rj
    ipt=$(ipt_for "$fam")
    if [[ $fam == 4 ]]; then rj=icmp-net-unreachable; else rj=icmp6-no-route; fi
    $ipt -w -t filter -N $CHAIN_KS 2>/dev/null || true
    # "! --mark": in OUTPUT the filter still sees the interface of the FIRST
    # route lookup (lo) even after a mark re-routed the packet to the WAN, so
    # marked packets (SSH replies, bypasses) must be excluded explicitly.
    # Refilling this chain is safe: blocking comes from the lo route below,
    # these rules only turn "silently dropped" into an immediate error.
    # Only NEW connections get that error. Packets of connections that already
    # exist (e.g. the SSH session the gateway is being (re)started from, while
    # its bypass rules are rebuilt for a moment) are just dropped, so TCP
    # resends them instead of the session being reset.
    local m=(-o lo -m mark ! --mark "$MARK" -m addrtype ! --dst-type LOCAL)
    $ipt -w -t filter -F $CHAIN_KS
    $ipt -w -t filter -A $CHAIN_KS "${m[@]}" -p tcp -m conntrack --ctstate NEW -j REJECT --reject-with tcp-reset || return 1
    $ipt -w -t filter -A $CHAIN_KS "${m[@]}" -m conntrack --ctstate NEW -j REJECT --reject-with $rj || return 1
    $ipt -w -t filter -A $CHAIN_KS "${m[@]}" -j DROP || return 1
    $ipt -w -t filter -C OUTPUT  -j $CHAIN_KS 2>/dev/null || $ipt -w -t filter -I OUTPUT 1  -j $CHAIN_KS || return 1
    $ipt -w -t filter -C FORWARD -j $CHAIN_KS 2>/dev/null || $ipt -w -t filter -I FORWARD 1 -j $CHAIN_KS || return 1
    src=$(wan_addr "$fam")
    if [[ -n $src ]]; then
        ip -"$fam" route replace default dev lo src "$src" table "$KS_TABLE" || return 1
    else
        ip -"$fam" route replace default dev lo table "$KS_TABLE" || return 1
    fi
    ip -"$fam" rule show priority $P_KS  | grep -q . || ip -"$fam" rule add priority $P_KS lookup "$KS_TABLE" || return 1
    ip -"$fam" rule show priority $P_KS2 | grep -q . || ip -"$fam" rule add priority $P_KS2 unreachable
}

ks_remove() { # fam
    local fam=$1 ipt; ipt=$(ipt_for "$fam")
    del_rules "$fam" $P_KS $P_KS2
    ip -"$fam" route flush table "$KS_TABLE" 2>/dev/null || true
    if command -v "$ipt" >/dev/null; then
        while $ipt -w -t filter -D OUTPUT  -j $CHAIN_KS 2>/dev/null; do :; done
        while $ipt -w -t filter -D FORWARD -j $CHAIN_KS 2>/dev/null; do :; done
        $ipt -w -t filter -F $CHAIN_KS 2>/dev/null || true
        $ipt -w -t filter -X $CHAIN_KS 2>/dev/null || true
    fi
    return 0
}

declare -A BASE_UP=()
GUARD_PID=""

on_exit() {
    local rc=$? fam
    trap - EXIT INT TERM
    if [[ -n $GUARD_PID ]]; then kill "$GUARD_PID" 2>/dev/null || true; wait "$GUARD_PID" 2>/dev/null || true; fi
    nft delete table inet wgvpn_guard 2>/dev/null || true
    if (( KS )); then
        log "stopping — kill switch ON: removing the tunnel, keeping the block in place"
        rm -f "$READY_FILE"
        for fam in $(families); do teardown_tunnel "$fam"; done
        wg_down
        # Inbound SSH / bypass ports must keep working while blocked.
        for fam in "${!BASE_WANTED[@]}"; do
            if [[ -z ${BASE_UP[$fam]:-} ]]; then
                teardown_base "$fam"
                setup_base "$fam" 2>/dev/null || warn "could not restore bypass rules (IPv$fam)"
            fi
            ks_install "$fam" 2>/dev/null || true
        done
        log "outbound traffic is BLOCKED until the gateway is running again"
        log "(inbound connections, local networks and your bypasses still work;"
        log " to lift the block: set KILLSWITCH=false and start it, or run"
        log " 'docker compose run --rm wg-vpn-gateway release')"
    else
        log "stopping — removing tunnel, rules and routes"
        teardown_all 0
        log "host routing restored"
    fi
    exit "$rc"
}

# ------------------------------------------------------------ config prep ---
validate_settings() {
    # Validate settings before anything is installed, so a typo can never
    # leave the kill switch up without the SSH/bypass rules.
    local port d e
    for port in $(list "$BYPASS_OUT_TCP_PORTS") $(list "$BYPASS_OUT_UDP_PORTS"); do
        [[ $port =~ ^[0-9]+(:[0-9]+)?$ ]] || die "bad port '$port' in BYPASS_OUT_TCP_PORTS / BYPASS_OUT_UDP_PORTS"
    done
    for d in $(list "$BYPASS_DESTINATIONS"); do
        is_cidr "$d" || die "bad entry '$d' in BYPASS_DESTINATIONS (IPs/CIDRs only)"
    done
    if [[ $MODE == gateway ]]; then
        [[ -n $GATEWAY_CLIENTS ]] || die "MODE=gateway needs GATEWAY_CLIENTS (the LAN IPs allowed to use this gateway)"
        for e in $(list "$GATEWAY_CLIENTS"); do
            is_cidr "${e%%=*}" || die "bad entry '$e' in GATEWAY_CLIENTS (use ip, ip/cidr or ip=name)"
        done
    fi
    if [[ $MODE == client ]]; then
        [[ $GATEWAY_IP =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || die "MODE=client needs GATEWAY_IP (the gateway VM's LAN IPv4 address)"
        [[ -z ${SPLIT_DESTS//[ ,]/} ]] || warn "SPLIT_TUNNEL_DESTINATIONS is ignored in client mode (the gateway VM's split tunnel already applies to this VM)"
    fi
    if (( SPLIT )); then
        for d in $(list "$SPLIT_DESTS"); do
            [[ $d =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+(/[0-9]{1,2})?$ ]] \
                || die "bad entry '$d' in SPLIT_TUNNEL_DESTINATIONS (IPv4 addresses/CIDRs only)"
        done
        [[ $SPLIT_IF =~ ^[a-zA-Z0-9_=+.-]{1,15}$ ]] || die "invalid SPLIT_TUNNEL_INTERFACE '$SPLIT_IF'"
        [[ $SPLIT_IF != "$WG_INTERFACE" ]] || die "SPLIT_TUNNEL_INTERFACE must differ from WG_INTERFACE"
    fi
}

# Copy a wg-quick config without the keys this container manages itself
# (DNS, Table, FwMark, SaveConfig) and with Table=off + our FwMark, so the
# tunnel's own packets always leave via the real network.
strip_config() { # src dst
    awk -v mark="$ROUTE_MARK" '
        { sub(/\r$/, ""); low = tolower($0) }
        low ~ /^[[:space:]]*\[/ {
            sect = low; gsub(/[^a-z]/, "", sect)
            print
            if (sect == "interface") { print "Table = off"; print "FwMark = " mark }
            next
        }
        sect == "interface" && low ~ /^[[:space:]]*(dns|table|fwmark|saveconfig)[[:space:]]*=/ { next }
        { print }
    ' "$1" > "$2"
    chmod 600 "$2"
    grep -qi '^[[:space:]]*\[peer\]' "$2" || die "$(basename "$1") has no [Peer] section"
}

conf_addrs() { # conf -> one Address per line
    awk '
        { low = tolower($0) }
        low ~ /^[[:space:]]*\[/ { sect = low; gsub(/[^a-z]/, "", sect); next }
        sect == "interface" && low ~ /^[[:space:]]*address[[:space:]]*=/ { sub(/^[^=]*=/, ""); print }' "$1" \
        | tr ',' '\n' | sed 's/[[:space:]]//g; /^$/d'
}

conf_endpoint_ips() { # conf -> endpoint IPs (hostnames are skipped)
    local ep host
    while IFS= read -r ep; do
        host=${ep%:*}; host=${host#[}; host=${host%]}
        [[ $host =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ || $host == *:* ]] && echo "$host"
    done < <(awk '{ low = tolower($0) } low ~ /^[[:space:]]*endpoint[[:space:]]*=/ { sub(/^[^=]*=/, ""); gsub(/[[:space:]]/, ""); print }' "$1")
    return 0
}

conf_has_hostname_endpoint() { # conf
    awk '{ low = tolower($0) } low ~ /^[[:space:]]*endpoint[[:space:]]*=/ { sub(/^[^=]*=/, ""); gsub(/[[:space:]]/, ""); sub(/:[0-9]+$/, ""); gsub(/[][]/, ""); if ($0 !~ /^[0-9.]+$/ && $0 !~ /:/) f = 1 } END { exit !f }' "$1"
}

prepare_config() {
    [[ -r $WG_CONFIG ]] || die "WireGuard config not found at $WG_CONFIG (check WG_CONFIG_FILE in .env)"
    [[ $WG_INTERFACE =~ ^[a-zA-Z0-9_=+.-]{1,15}$ ]] || die "invalid WG_INTERFACE '$WG_INTERFACE'"
    mkdir -p "$RUN_DIR"; chmod 700 "$RUN_DIR"
    strip_config "$WG_CONFIG" "$RUN_CONF"

    # Tunnel addresses (needed for NAT + IPv6 decision)
    mapfile -t WG_ADDRS < <(conf_addrs "$RUN_CONF")
    (( ${#WG_ADDRS[@]} )) || die "config [Interface] has no Address"
    HAVE_V4=0; HAVE_V6=0
    local a; for a in "${WG_ADDRS[@]}"; do if is_v6 "$a"; then HAVE_V6=1; else HAVE_V4=1; fi; done
    (( HAVE_V4 )) || die "config has no IPv4 Address — this container routes IPv4 through the tunnel"

    case "$IPV6_MODE" in
        on)   (( HAVE_V6 )) || die "IPV6_MODE=on but the config has no IPv6 Address"; ROUTE_V6=1 ;;
        off)  ROUTE_V6=0 ;;
        auto) ROUTE_V6=$HAVE_V6 ;;
        *)    die "IPV6_MODE must be auto, on or off" ;;
    esac

    # Endpoints: hostnames need DNS before the tunnel is up; IPs are shared
    # with the guard so a blocklist can never cut off the VPN itself.
    ENDPOINT_HOSTNAME=0
    conf_has_hostname_endpoint "$RUN_CONF" && ENDPOINT_HOSTNAME=1
    conf_endpoint_ips "$RUN_CONF" > "$RUN_DIR/endpoints"

    # Split tunnel: a second config that only carries SPLIT_TUNNEL_DESTINATIONS.
    SPLIT_ADDRS=()
    if (( SPLIT )); then
        [[ -f $SPLIT_CONFIG && -s $SPLIT_CONFIG ]] \
            || die "SPLIT_TUNNEL_DESTINATIONS is set, but there is no WireGuard config at SPLIT_TUNNEL_CONFIG_FILE (put it at config/wg-split.conf, or empty SPLIT_TUNNEL_DESTINATIONS)"
        strip_config "$SPLIT_CONFIG" "$SPLIT_RUN_CONF"
        mapfile -t SPLIT_ADDRS < <(conf_addrs "$SPLIT_RUN_CONF" | grep -v ':')
        (( ${#SPLIT_ADDRS[@]} )) || die "split tunnel config [Interface] has no IPv4 Address"
        conf_has_hostname_endpoint "$SPLIT_RUN_CONF" && ENDPOINT_HOSTNAME=1
        conf_endpoint_ips "$SPLIT_RUN_CONF" >> "$RUN_DIR/endpoints"
    fi
}

# Without an MTU line, wg-quick sizes the tunnel from the route to the
# endpoint — but it looks that route up without the tunnel's mark, so with
# the kill switch in place it finds the blocking loopback route and picks a
# ~65000-byte MTU. Work it out the way the tunnel's packets really leave
# (with the mark, after the bypass rules exist): that interface's MTU - 80,
# the same overhead wg-quick allows.
ensure_mtu() { # conf
    local conf=$1
    if awk '{ low = tolower($0) }
            low ~ /^[[:space:]]*\[/ { sect = low; gsub(/[^a-z]/, "", sect); next }
            sect == "interface" && low ~ /^[[:space:]]*mtu[[:space:]]*=/ { found = 1 }
            END { exit !found }' "$conf"; then
        return 0
    fi
    local ep dev m best="" fam
    while IFS= read -r ep; do
        [[ -n $ep ]] || continue
        if is_v6 "$ep"; then fam=6; else fam=4; fi
        dev=$(ip -"$fam" route get "$ep" mark "$ROUTE_MARK" 2>/dev/null \
            | awk '{ for (i = 1; i < NF; i++) if ($i == "dev") { print $(i+1); exit } }')
        [[ -n $dev && $dev != lo ]] || continue
        m=$(cat "/sys/class/net/$dev/mtu" 2>/dev/null) || continue
        if [[ -z $best ]] || (( m < best )); then best=$m; fi
    done < <(conf_endpoint_ips "$conf")
    [[ -n $best ]] || best=$(cat "/sys/class/net/$WAN_INTERFACE/mtu" 2>/dev/null || echo 1500)
    local mtu=$(( best - 80 ))
    (( mtu >= 1280 )) || mtu=1280
    awk -v mtu="$mtu" '{ print } tolower($0) ~ /^[[:space:]]*fwmark[[:space:]]*=/ && !done { print "MTU = " mtu; done = 1 }' \
        "$conf" > "$conf.tmp" && mv "$conf.tmp" "$conf"
    chmod 600 "$conf"
    log "$(basename "$conf" .conf) MTU: $mtu (no MTU in its config; worked out from the route to its VPN server)"
}

# --------------------------------------------------------------- routing ---
# Base layer: everything that must keep using the real IP / local routes.
setup_base() { # 4|6
    local fam=$1 ipt addr port proto ports c
    ipt=$(ipt_for "$fam")
    command -v "$ipt" >/dev/null || die "$ipt not found"

    # Policy rules (lower number = evaluated first). Rules other tools install
    # at lower priorities (Tailscale 52xx, etc.) keep working untouched.
    ip -"$fam" rule add priority $P_MARK fwmark "$MARK" lookup main
    for addr in $(list "$BYPASS_DESTINATIONS"); do
        fam_matches "$fam" "$addr" && ip -"$fam" rule add priority $P_DEST to "$addr" lookup main
    done
    # Always local, never tunnelled or kill-switched: link-local (e.g. cloud
    # metadata 169.254.169.254), multicast (mDNS/SSDP) and limited broadcast.
    # The kernel has no specific routes for these, so without this they would
    # follow the default route into the tunnel.
    if [[ $fam == 4 ]]; then
        for addr in 169.254.0.0/16 224.0.0.0/4 255.255.255.255/32; do
            ip -4 rule add priority $P_DEST to "$addr" lookup main
        done
    fi
    ip -"$fam" rule add priority $P_MAIN lookup main suppress_prefixlength 0

    # --- mangle: connection marks ---
    $ipt -w -t mangle -N $CHAIN_PRE
    $ipt -w -t mangle -N $CHAIN_OUT
    $ipt -w -t mangle -N $CHAIN_POSTM
    $ipt -w -t mangle -N $CHAIN_WAN
    # restore the connection's mark onto every packet of a marked connection
    # (only when the connection carries it — an unconditional restore would
    # clear the mark the WireGuard socket sets on its own packets → loop)
    $ipt -w -t mangle -A $CHAIN_PRE -m connmark --mark "$MARK" -j CONNMARK --restore-mark --nfmask "$ROUTE_MARK" --ctmask "$ROUTE_MARK"
    $ipt -w -t mangle -A $CHAIN_OUT -m connmark --mark "$MARK" -j CONNMARK --restore-mark --nfmask "$ROUTE_MARK" --ctmask "$ROUTE_MARK"
    # any connection seen arriving on the WAN interface stays on the WAN —
    # new inbound connections, and connections that already existed when the
    # gateway started (e.g. the SSH session you started it from) — EXCEPT
    # traffic from gateway clients, which arrives on the same (LAN) interface
    # but is outgoing traffic that must go into the tunnel.
    if [[ $MODE == gateway ]]; then
        for addr in $(client_addrs); do
            fam_matches "$fam" "$addr" && $ipt -w -t mangle -A $CHAIN_WAN -s "$addr" -j RETURN
        done
    fi
    # client mode: tunnelled replies come back from the gateway VM on the same
    # LAN interface — skip connections this VM started toward the gateway.
    [[ $MODE == client ]] && $ipt -w -t mangle -A $CHAIN_WAN -m connmark --mark "$VIA" -j RETURN
    $ipt -w -t mangle -A $CHAIN_WAN -j CONNMARK --set-xmark "$MARK"
    $ipt -w -t mangle -A $CHAIN_WAN -j MARK --set-xmark "$MARK"
    $ipt -w -t mangle -A $CHAIN_PRE -i "$WAN_INTERFACE" -j $CHAIN_WAN
    # Connections that were already open when these rules were (re)built — like
    # the SSH session the install command runs in — are only tagged above once
    # their next packet ARRIVES. While the far end mostly receives (build output
    # scrolling by) it sends next to nothing, so this host's own packets would
    # sit behind the kill switch until the session dies. Any packet answering a
    # connection that was opened TO this host's WAN address belongs to such an
    # inbound connection: tag it right away. (Connections opened to the tunnel
    # address — port forwards from the VPN provider — don't match and keep
    # answering through the tunnel.)
    for addr in $(wan_addrs "$fam"); do
        $ipt -w -t mangle -A $CHAIN_OUT -m connmark ! --mark "$MARK" \
            -m conntrack --ctdir REPLY --ctorigdst "$addr" -j $CHAIN_WAN
        $ipt -w -t mangle -A $CHAIN_PRE -m connmark ! --mark "$MARK" \
            -m conntrack --ctdir REPLY --ctorigdst "$addr" -j $CHAIN_WAN
    done
    # outbound port bypass: local processes (OUTPUT) and forwarded traffic
    # from containers / local VPN clients (PREROUTING, not from WAN or tunnel)
    $ipt -w -t mangle -N $CHAIN_FWD
    $ipt -w -t mangle -A $CHAIN_FWD -i "$WAN_INTERFACE" -j RETURN
    for c in $(tunnels); do $ipt -w -t mangle -A $CHAIN_FWD -i "$c" -j RETURN; done
    for proto in tcp udp; do
        if [[ $proto == tcp ]]; then ports=$BYPASS_OUT_TCP_PORTS; else ports=$BYPASS_OUT_UDP_PORTS; fi
        for port in $(list "$ports"); do
            $ipt -w -t mangle -A $CHAIN_OUT -p $proto --dport "$port" -m conntrack --ctstate NEW \
                -j MARK --set-xmark "$MARK"
            $ipt -w -t mangle -A $CHAIN_FWD -p $proto --dport "$port" -j MARK --set-xmark "$MARK"
        done
    done
    $ipt -w -t mangle -A $CHAIN_PRE -m conntrack --ctstate NEW -j $CHAIN_FWD
    # persist any mark set above (and the tunnel socket's own mark) on the connection
    $ipt -w -t mangle -A $CHAIN_OUT   -m mark --mark "$MARK" -j CONNMARK --save-mark --nfmask "$ROUTE_MARK" --ctmask "$ROUTE_MARK"
    $ipt -w -t mangle -A $CHAIN_PRE   -m mark --mark "$MARK" -j CONNMARK --save-mark --nfmask "$ROUTE_MARK" --ctmask "$ROUTE_MARK"
    $ipt -w -t mangle -A $CHAIN_POSTM -m mark --mark "$MARK" -j CONNMARK --save-mark --nfmask "$ROUTE_MARK" --ctmask "$ROUTE_MARK"
    # client mode: remember new outgoing connections that are NOT bypassed
    # (these are the ones routed to the gateway VM, or to the local network)
    if [[ $MODE == client ]]; then
        $ipt -w -t mangle -A $CHAIN_POSTM -o "$WAN_INTERFACE" -m conntrack --ctstate NEW \
            -m mark ! --mark "$MARK" -j CONNMARK --set-xmark "$VIA"
    fi
    $ipt -w -t mangle -I PREROUTING  1 -j $CHAIN_PRE
    $ipt -w -t mangle -I OUTPUT      1 -j $CHAIN_OUT
    $ipt -w -t mangle -I POSTROUTING 1 -j $CHAIN_POSTM

    # Forwarded TCP (Docker containers, SoftEther/OpenVPN/WireGuard clients of
    # servers on this host, gateway clients) usually comes from 1500-MTU
    # interfaces; clamp its MSS to the tunnel's MTU so large transfers don't
    # stall on internet paths that drop ICMP "fragmentation needed".
    $ipt -w -t mangle -N $CHAIN_MSS
    for c in $(tunnels); do
        $ipt -w -t mangle -A $CHAIN_MSS -o "$c" -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu
    done
    $ipt -w -t mangle -I FORWARD 1 -j $CHAIN_MSS

    # Gateway: only listed clients may send traffic through this VM. Docker
    # hosts default FORWARD to DROP, so clients are explicitly accepted; any
    # other LAN device that points its route at this VM is refused.
    if [[ $MODE == gateway ]]; then
        $ipt -w -t filter -N $CHAIN_GW
        for addr in $(client_addrs); do
            fam_matches "$fam" "$addr" || continue
            for c in $(tunnels); do
                $ipt -w -t filter -A $CHAIN_GW -i "$WAN_INTERFACE" -s "$addr" -o "$c" -j ACCEPT
                $ipt -w -t filter -A $CHAIN_GW -i "$c" -d "$addr" -o "$WAN_INTERFACE" \
                    -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
            done
            $ipt -w -t filter -A $CHAIN_GW -i "$WAN_INTERFACE" -s "$addr" -o "$WAN_INTERFACE" -j ACCEPT
        done
        local rj; if [[ $fam == 4 ]]; then rj=icmp-admin-prohibited; else rj=icmp6-adm-prohibited; fi
        for c in $(tunnels); do $ipt -w -t filter -A $CHAIN_GW -i "$WAN_INTERFACE" -o "$c" -j REJECT --reject-with $rj; done
        c=$rj
        $ipt -w -t filter -A $CHAIN_GW -i "$WAN_INTERFACE" -o "$WAN_INTERFACE" -j REJECT --reject-with $c
        $ipt -w -t filter -I FORWARD 1 -j $CHAIN_GW
    fi
    BASE_UP[$fam]=1
}

# Tunnel layer: everything else goes into WireGuard (or to the gateway VM).
setup_tunnel() { # 4|6
    local fam=$1 ipt addr
    ipt=$(ipt_for "$fam")
    if [[ $MODE == client ]]; then
        ip -4 route replace default via "$GATEWAY_IP" dev "$WAN_INTERFACE" table "$ROUTE_TABLE"
        ip -4 rule add priority $P_VPN lookup "$ROUTE_TABLE"
        return 0
    fi
    ip -"$fam" route replace default dev "$WG_INTERFACE" table "$ROUTE_TABLE"
    # Split tunnel: its destinations take the second tunnel instead (more
    # specific routes in the same table). Bypasses still come first.
    if (( SPLIT )) && [[ $fam == 4 ]]; then
        for addr in $(list "$SPLIT_DESTS"); do
            ip -4 route replace "$addr" dev "$SPLIT_IF" table "$ROUTE_TABLE"
        done
    fi
    ip -"$fam" rule add priority $P_VPN lookup "$ROUTE_TABLE"

    $ipt -w -t nat -N $CHAIN_NAT
    # forwarded traffic (Docker containers, clients of VPN servers on this
    # host, gateway clients) leaving through the tunnel must carry the tunnel address
    for addr in "${WG_ADDRS[@]}"; do
        if fam_matches "$fam" "$addr"; then
            $ipt -w -t nat -A $CHAIN_NAT -o "$WG_INTERFACE" -s "${addr%/*}" -j RETURN
            # a socket that picked the tunnel address before being re-routed
            # to the WAN by a bypass mark needs the WAN address instead
            $ipt -w -t nat -A $CHAIN_NAT -o "$WAN_INTERFACE" -s "${addr%/*}" -j MASQUERADE
        fi
    done
    $ipt -w -t nat -A $CHAIN_NAT -o "$WG_INTERFACE" -j MASQUERADE
    if (( SPLIT )) && [[ $fam == 4 ]]; then
        for addr in "${SPLIT_ADDRS[@]}"; do
            $ipt -w -t nat -A $CHAIN_NAT -o "$SPLIT_IF" -s "${addr%/*}" -j RETURN
            $ipt -w -t nat -A $CHAIN_NAT -o "$WAN_INTERFACE" -s "${addr%/*}" -j MASQUERADE
        done
        $ipt -w -t nat -A $CHAIN_NAT -o "$SPLIT_IF" -j MASQUERADE
    fi
    $ipt -w -t nat -I POSTROUTING 1 -j $CHAIN_NAT

    # Suricata (profile "suricata"): everything entering or leaving the tunnel
    # is inspected before encryption. --queue-bypass: if Suricata isn't running
    # (starting, updating, crashed) traffic passes instead of being blocked.
    # Queued where every packet shows its real addresses (so Suricata can pair
    # both directions of a connection) and exactly once:
    #   leaving   — POSTROUTING -o tunnel (before NAT and encryption)
    #   returning — FORWARD -i tunnel (gateway clients / containers, already
    #               translated back to their own address) and INPUT -i tunnel
    #               (this host's own connections)
    # The encrypted outer WireGuard packets never pass these hooks.
    if (( IPS )); then
        $ipt -w -t mangle -N $CHAIN_IPS
        # Connections Suricata has finished with go straight on (see below).
        if is_true "${SURICATA_BYPASS:-true}"; then
            $ipt -w -t mangle -A $CHAIN_IPS -m connmark --mark "$SURICATA_BYPASS_MARK/$SURICATA_BYPASS_MARK" -j RETURN
        fi
        $ipt -w -t mangle -A $CHAIN_IPS -j NFQUEUE --queue-num "$SURICATA_QUEUE" --queue-bypass
        for addr in $(tunnels); do
            $ipt -w -t mangle -A POSTROUTING -o "$addr" -j $CHAIN_IPS
            $ipt -w -t mangle -A FORWARD     -i "$addr" -j $CHAIN_IPS
            $ipt -w -t mangle -A INPUT       -i "$addr" -j $CHAIN_IPS
        done
        # When Suricata is done with a connection it marks that packet; copy
        # the mark onto the connection (in a hook that runs after the queue's
        # verdict) so its remaining packets skip Suricata entirely. Only the
        # bypass bit is touched.
        if is_true "${SURICATA_BYPASS:-true}" && [[ ! -e $RUN_DIR/ips_nft ]]; then
            local b=$SURICATA_BYPASS_MARK
            nft -f - <<EOF || warn "could not set up Suricata flow bypass (inspection still works, just slower)"
table inet wgvpn_ips {}
delete table inet wgvpn_ips
table inet wgvpn_ips {
  chain save_in  { type filter hook input       priority 100; meta mark & $b == $b ct mark set ct mark | $b; }
  chain save_fwd { type filter hook forward     priority 100; meta mark & $b == $b ct mark set ct mark | $b; }
  chain save_out { type filter hook postrouting priority 100; meta mark & $b == $b ct mark set ct mark | $b; }
}
EOF
            : > "$RUN_DIR/ips_nft"
        fi
    fi
}

set_sysctl() { # key value
    local f="/proc/sys/${1//.//}"
    [[ -e $f ]] || return 0
    if ! echo "$2" > "$f" 2>/dev/null; then
        warn "could not set $1=$2 (is the container privileged?)"
        return 1
    fi
}

# --------------------------------------------------------------- release ---
# `docker compose run --rm wg-vpn-gateway release` — remove everything,
# including a kill switch left behind by a stopped gateway.
if [[ ${1:-} == release ]]; then
    pick_iptables
    teardown_all 0
    log "released — kill switch and all gateway rules removed, host routing restored"
    exit 0
fi

# ------------------------------------------------------------------ main ---
mkdir -p "$RUN_DIR"; chmod 700 "$RUN_DIR"
rm -f "$READY_FILE"
pick_iptables
validate_settings
WG_ADDRS=(); ROUTE_V6=0; ENDPOINT_HOSTNAME=0; : > "$RUN_DIR/endpoints"
[[ $MODE == client ]] || prepare_config

if [[ -z $WAN_INTERFACE ]]; then
    WAN_INTERFACE=$(ip -4 route show table main default | awk '{for(i=1;i<NF;i++) if($i=="dev"){print $(i+1); exit}}')
    [[ -n $WAN_INTERFACE ]] || die "could not detect the WAN interface — set WAN_INTERFACE in .env"
fi
ip link show dev "$WAN_INTERFACE" >/dev/null 2>&1 || die "WAN interface '$WAN_INTERFACE' does not exist"
[[ $WAN_INTERFACE != "$WG_INTERFACE" ]] || die "WAN_INTERFACE and WG_INTERFACE must differ"
(( ROUTE_V6 == 0 || HOST_V6 == 1 )) || die "config has an IPv6 Address but this host has no IPv6 — set IPV6_MODE=off"
if [[ $MODE == client ]]; then
    # The gateway VM must be directly reachable on the LAN (no router hop).
    ip -4 route get "$GATEWAY_IP" 2>/dev/null | grep -q " via " \
        && die "GATEWAY_IP $GATEWAY_IP is not on this VM's local network (it is reached through a router)"
    [[ -n $(wan_addr 4) && $(wan_addr 4) != "$GATEWAY_IP" ]] || die "GATEWAY_IP must be another VM, not this one"
fi
echo "$WAN_INTERFACE" > "$RUN_DIR/wan_interface"

# Families that get the base layer: IPv4 always; IPv6 when it is tunnelled, or
# when the kill switch must also stop native IPv6 from leaving via the real IP.
declare -A BASE_WANTED=([4]=1)
(( ROUTE_V6 )) && BASE_WANTED[6]=1
(( KS && HOST_V6 )) && BASE_WANTED[6]=1

case "$MODE" in
    client)  log "mode: client — internet traffic goes through gateway VM $GATEWAY_IP" ;;
    gateway) log "mode: gateway — also carrying traffic for: $(list "$GATEWAY_CLIENTS" | tr '\n' ' ')" ;;
    *)       log "mode: standalone" ;;
esac
log "WAN interface: $WAN_INTERFACE | IPv6 through tunnel: $([[ $ROUTE_V6 == 1 ]] && echo yes || echo no) | kill switch: $( (( KS )) && echo ON || echo off) | Suricata: $( (( IPS )) && echo on || echo off)"

trap on_exit EXIT
trap 'exit 0' INT TERM

# Kill switch first, so nothing leaks while the rest is rebuilt below.
if (( KS )); then for fam in "${!BASE_WANTED[@]}"; do ks_install "$fam"; done; fi
teardown_all "$KS"   # clear leftovers from an earlier run (keeps the kill switch if on)

# Reverse-path filtering must honour fwmarks, or replies to marked (WAN)
# connections are dropped when rp_filter is strict.
set_sysctl net.ipv4.conf.all.src_valid_mark 1 || true
if [[ $MODE == client ]]; then
    # A router telling this VM "use the real router directly" would bypass
    # the gateway, so ICMP redirects are ignored.
    for k in all default "$WAN_INTERFACE"; do
        set_sysctl net.ipv4.conf.$k.accept_redirects 0 || true
        set_sysctl net.ipv4.conf.$k.secure_redirects 0 || true
        if (( HOST_V6 )); then set_sysctl net.ipv6.conf.$k.accept_redirects 0 || true; fi
    done
else
    [[ $(cat /proc/sys/net/ipv4/ip_forward 2>/dev/null) == 1 ]] || set_sysctl net.ipv4.ip_forward 1 || true
    if [[ $MODE == gateway ]]; then
        # Never tell clients to use the real router directly.
        for k in all default "$WAN_INTERFACE"; do set_sysctl net.ipv4.conf.$k.send_redirects 0 || true; done
    fi
fi

for fam in "${!BASE_WANTED[@]}"; do setup_base "$fam"; done

if [[ $MODE != client ]]; then
    # With the kill switch on, a hostname Endpoint can't be resolved over the
    # (not yet existing) tunnel — allow DNS out directly just while it comes up.
    DNS_WINDOW=0
    if (( KS && ENDPOINT_HOSTNAME )); then
        for fam in "${!BASE_WANTED[@]}"; do
            ip -"$fam" rule add priority $P_MARK ipproto udp dport 53 lookup main
            ip -"$fam" rule add priority $P_MARK ipproto tcp dport 53 lookup main
        done
        DNS_WINDOW=1
    fi

    ensure_mtu "$RUN_CONF"
    log "bringing up tunnel from $(basename "$WG_CONFIG")"
    wg-quick up "$RUN_CONF"
    if (( SPLIT )); then
        ensure_mtu "$SPLIT_RUN_CONF"
        log "bringing up split tunnel $SPLIT_IF from $(basename "$SPLIT_CONFIG") for: $(list "$SPLIT_DESTS" | tr '\n' ' ')"
        wg-quick up "$SPLIT_RUN_CONF"
    fi

    if (( DNS_WINDOW )); then
        for fam in "${!BASE_WANTED[@]}"; do
            ip -"$fam" rule del priority $P_MARK ipproto udp dport 53 lookup main 2>/dev/null || true
            ip -"$fam" rule del priority $P_MARK ipproto tcp dport 53 lookup main 2>/dev/null || true
        done
    fi
    # resolved endpoint addresses too (for the guard's never-block list)
    for c in $(tunnels); do wg show "$c" endpoints 2>/dev/null; done | awk '{ sub(/:[0-9]+$/, "", $2); gsub(/[][]/, "", $2); if ($2 != "(none)") print $2 }' >> "$RUN_DIR/endpoints"
fi

setup_tunnel 4
(( ROUTE_V6 )) && setup_tunnel 6

: > "$READY_FILE"
if [[ $MODE == client ]]; then
    log "internet traffic now goes through gateway VM $GATEWAY_IP"
else
    log "host traffic now routed through $WG_INTERFACE"
fi
log "bypass: inbound connections on $WAN_INTERFACE, local subnets, tcp ports [${BYPASS_OUT_TCP_PORTS:-none}], udp ports [${BYPASS_OUT_UDP_PORTS:-none}], destinations [${BYPASS_DESTINATIONS:-none}]"
(( KS )) && log "kill switch ON: if the tunnel goes away, all other outbound traffic is blocked"
if [[ $MODE != client ]]; then for c in $(tunnels); do wg show "$c" | sed 's/^/    /'; done; fi
(( SPLIT )) && log "split tunnel: $(list "$SPLIT_DESTS" | tr '\n' ' ')→ $SPLIT_IF (unless bypassed); everything else → $WG_INTERFACE"

# Guard: blocklists (gateway/standalone), health alerts, log size limits.
export MODE WAN_INTERFACE RUN_DIR
/usr/local/bin/wg-vpn-guard & GUARD_PID=$!

# Stay in the foreground until docker stops us; then the EXIT trap cleans up.
sleep infinity & wait $!
