#!/usr/bin/env bash
# Auto-updater (profile "autoupdate"). On the schedule in .env it:
#   1. tags the current image as :previous
#   2. rebuilds with the newest Alpine packages (and, with ALPINE_AUTO_UPGRADE,
#      the newest stable Alpine release — older branches stop getting
#      community-package security fixes, which includes Suricata)
#   3. recreates the gateway (and Suricata) and waits for them to be healthy
#   4. on any failure, puts :previous back, recreates, and alerts you
# Blocklists (daily) and Suricata rules (daily) update themselves separately.
set -uo pipefail
log() { echo "[updater] $(date '+%F %T') $*"; }
notify() { python3 /usr/local/lib/wg-vpn-gateway/guardlib.py notify "$*" >/dev/null 2>&1 || true; }
cd "${PROJECT_DIR:?PROJECT_DIR not set}" || exit 1
STATE=${STATE_DIR:-/state}/updater.json
SERVICE=wg-vpn-gateway
TIMEOUT=${UPDATE_HEALTH_TIMEOUT:-240}

env_get() { grep -E "^$1=" .env 2>/dev/null | tail -n1 | cut -d= -f2- | sed -e 's/^["'\'']//' -e 's/["'\'']$//'; }
image() { docker compose config --images 2>/dev/null | grep -m1 'wg-vpn-gateway' || echo wg-vpn-gateway:local; }
img_id() { docker image inspect -f '{{.Id}}' "$1" 2>/dev/null; }
active_services() { docker compose config --services 2>/dev/null | grep -vx updater; }

healthy() { # wait until the gateway reports healthy and Suricata (if enabled) stays up
    local deadline=$(( $(date +%s) + TIMEOUT )) cid st
    while (( $(date +%s) < deadline )); do
        cid=$(docker compose ps -q "$SERVICE" 2>/dev/null)
        st=$(docker inspect -f '{{.State.Health.Status}}' "$cid" 2>/dev/null)
        if [[ $st == healthy ]]; then
            if active_services | grep -qx suricata; then
                sleep 30
                cid=$(docker compose ps -q suricata 2>/dev/null)
                [[ $(docker inspect -f '{{.State.Running}}' "$cid" 2>/dev/null) == true ]] || return 1
            fi
            return 0
        fi
        sleep 5
    done
    return 1
}

latest_alpine() { # newest stable branch, e.g. 3.24
    curl -fsSL --max-time 20 "https://dl-cdn.alpinelinux.org/alpine/latest-stable/releases/$(uname -m)/latest-releases.yaml" 2>/dev/null \
        | awk '/branch:/ { sub(/.*branch: *v?/, ""); print; exit }'
}

run_update() {
    local img prev before after cur_alp new_alp build_alp msg ver
    img=$(image); prev="${img%:*}:previous"
    before=$(img_id "$img")
    cur_alp=$(env_get ALPINE_VERSION); cur_alp=${cur_alp:-3.24}
    build_alp=$cur_alp
    if [[ ${ALPINE_AUTO_UPGRADE:-true} == true ]]; then
        new_alp=$(latest_alpine)
        if [[ -n $new_alp && $new_alp != "$cur_alp" ]] && \
           [[ $(printf '%s\n%s\n' "$cur_alp" "$new_alp" | sort -V | tail -n1) == "$new_alp" ]]; then
            build_alp=$new_alp
            log "newer Alpine release available: $cur_alp -> $new_alp (will try it)"
        fi
    fi
    [[ -n $before ]] && docker image tag "$img" "$prev"
    log "building with the latest packages (Alpine $build_alp)"
    if ! docker compose build --pull --no-cache --build-arg ALPINE_VERSION="$build_alp" "$SERVICE" >/tmp/build.log 2>&1; then
        log "build failed — nothing changed"; tail -n 20 /tmp/build.log
        notify "⚠️ Auto-update: build failed, nothing changed. Still running the previous version."$'\n'"$(tail -n 8 /tmp/build.log | cut -c1-150)"
        [[ -n $before ]] && docker image tag "$prev" "$img"
        return 1
    fi
    after=$(img_id "$img")
    if [[ $after == "$before" ]]; then log "already up to date"; return 0; fi

    # shellcheck disable=SC2046
    docker compose up -d --no-deps --no-build $(active_services) >/dev/null 2>&1
    if healthy; then
        ver=$(docker compose exec -T "$SERVICE" sh -c 'cat /etc/alpine-release; suricata -V 2>/dev/null | grep -o "version [0-9.]*"' 2>/dev/null | tr '\n' ' ')
        if [[ $build_alp != "$cur_alp" ]]; then
            sed -i "s/^ALPINE_VERSION=.*/ALPINE_VERSION=$build_alp/" .env
            msg="✅ Auto-update installed and verified (moved to Alpine $build_alp; ALPINE_VERSION in .env updated). Now: $ver"
        else
            msg="✅ Auto-update installed and verified. Now: $ver"
        fi
        log "${msg#* }"; notify "$msg"
        docker image prune -f >/dev/null 2>&1
        return 0
    fi
    log "update FAILED its health check — rolling back"
    docker compose logs --tail 30 "$SERVICE" 2>&1 | tail -n 30
    docker image tag "$prev" "$img"
    # shellcheck disable=SC2046
    docker compose up -d --no-deps --no-build --force-recreate $(active_services) >/dev/null 2>&1
    if healthy; then
        notify "↩️ Auto-update failed its health check and was **rolled back**; the previous version is running and healthy."
    else
        notify "🔴 Auto-update failed AND the rollback is not healthy — please check the gateway VM (\`docker compose logs\`)."
    fi
    return 1
}

due() { # once per scheduled day/hour
    local day hour today last
    day=${UPDATE_DAY:-Sun}; hour=${UPDATE_HOUR:-4}
    today=$(date +%F)
    last=$(python3 -c "import json;print(json.load(open('$STATE')).get('last',''))" 2>/dev/null)
    [[ $last == "$today" ]] && return 1
    [[ $(date +%-H) == "$hour" ]] || return 1
    [[ ${day,,} == daily || $(date +%a) == "$day" ]] || return 1
    return 0
}

if [[ ${1:-} == now ]]; then run_update; exit $?; fi
log "scheduled for ${UPDATE_DAY:-Sun} at ${UPDATE_HOUR:-4}:00 (container time zone ${TZ:-UTC})"
while sleep 300; do
    if due; then
        echo "{\"last\": \"$(date +%F)\"}" > "$STATE"
        run_update
        # pick up a new updater image last (this recreates and ends this process)
        docker compose up -d --no-deps --no-build updater >/dev/null 2>&1
    fi
done
