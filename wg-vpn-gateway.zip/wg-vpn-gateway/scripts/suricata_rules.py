#!/usr/bin/env python3
"""Build Suricata's active ruleset from the Emerging Threats Open rules.

  * only the categories in SURICATA_CATEGORIES are loaded (keeps memory low)
  * in block mode, a rule DROPS only when ET marks it both
      confidence High          ("minimal likelihood of false positives")
      signature_severity Major/Critical (active / likely compromise)
    everything else only alerts; in monitor mode nothing drops
  * SURICATA_ALERT_ONLY_SIDS never drop, SURICATA_DISABLE_SIDS are removed
  * a candidate ruleset is tested with `suricata -T` before it replaces the
    running one; if it fails, the previous ruleset stays (and you're alerted)

usage: suricata_rules.py download|build|activate
"""
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time

STATE = os.environ.get("STATE_DIR", "/state")
SDIR = os.path.join(STATE, "suricata")
SU_DATA = os.path.join(SDIR, "su")
MERGED = os.path.join(SU_DATA, "rules", "suricata.rules")
ACTIVE = os.path.join(SDIR, "active.rules")
CANDIDATE = os.path.join(SDIR, "candidate.rules")
CONF = os.environ.get("SURICATA_CONF", "/run/suricata.yaml")
GUARD = ["python3", "/usr/local/lib/wg-vpn-gateway/guardlib.py"]

MSG = re.compile(r'msg:"ET ([A-Z_]+)')
SID = re.compile(r"\bsid:\s*(\d+)")
META = re.compile(r"\bmetadata:([^;]*);")


def env(k, d=""):
    v = os.environ.get(k)
    return d if not v else v


def ids(key):
    return {x.strip() for x in env(key).replace(" ", ",").split(",") if x.strip()}


def log(m):
    print(f"[suricata-rules] {m}", flush=True)
    os.makedirs(env("LOG_DIR", "/logs"), exist_ok=True)
    with open(os.path.join(env("LOG_DIR", "/logs"), "guard.log"), "a") as f:
        f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + f"suricata rules: {m}\n")


def notify(m):
    subprocess.run(GUARD + ["notify", m], capture_output=True)


def mode():
    """High-confidence rules block right away (like the trusted blocklists),
    unless BLOCK_MODE=monitor."""
    try:
        with open(os.path.join(STATE, "mode.json")) as f:
            m = json.load(f).get("suricata")
            if m:
                return m
    except (OSError, ValueError):
        pass
    return "monitor" if env("BLOCK_MODE", "auto").lower() == "monitor" else "block"


ET_URL = "https://rules.emergingthreats.net/open/suricata-{version}/emerging.rules.tar.gz"
MIN_ET_RULES = 1000        # fewer than this = a broken download; keep the old copy


def suricata_version():
    try:
        out = subprocess.run(["suricata", "-V"], capture_output=True, text=True, timeout=30).stdout
        m = re.search(r"version (\d+)\.(\d+)\.(\d+)", out)
        if m:
            return m.groups()
    except (OSError, subprocess.SubprocessError):
        pass
    return None


def rule_urls():
    """SURICATA_RULES_URL if set; otherwise ET Open for this Suricata version,
    then for its .0 release, then 7.0.3 (known good) as a last resort."""
    if env("SURICATA_RULES_URL"):
        return [env("SURICATA_RULES_URL")]
    v = suricata_version()
    versions = []
    if v:
        versions += [".".join(v), f"{v[0]}.{v[1]}.0", f"{v[0]}.0.0"]
    versions.append("7.0.3")
    out = []
    for ver in versions:
        if ver not in out:
            out.append(ver)
    return [ET_URL.format(version=ver) for ver in out]


def fetch_into(url, rules_tmp, cls_tmp):
    """Stream the rules archive straight from the network, one line at a time,
    into rules_tmp — the whole ruleset is never held in memory (suricata-update
    loaded all of it and was killed by the container's memory cap)."""
    import tarfile
    import urllib.request
    if url.startswith("file://"):
        src = open(url[7:], "rb")
    else:
        src = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "wg-vpn-gateway"}), timeout=120)
    n = 0
    with src, tarfile.open(fileobj=src, mode="r|gz") as tar, open(rules_tmp, "w") as out:
        for member in tar:
            if not member.isfile():
                continue
            name = member.name.rsplit("/", 1)[-1]
            if not (name.endswith(".rules") or name == "classification.config"):
                continue
            f = tar.extractfile(member)
            if f is None:
                continue
            if name == "classification.config":
                with open(cls_tmp, "wb") as c:
                    shutil.copyfileobj(f, c)
                continue
            for raw in f:
                line = raw.decode("utf-8", "replace")
                if MSG.search(line) and not line.lstrip().startswith("#"):
                    out.write(line if line.endswith("\n") else line + "\n")
                    n += 1
    return n


def download():
    """Fetch ET Open. The merged file keeps every category (build() picks
    yours), so changing SURICATA_CATEGORIES never needs a new download. The
    previous copy stays if the download fails or looks broken."""
    rules_dir = os.path.join(SU_DATA, "rules")
    os.makedirs(rules_dir, exist_ok=True)
    rules_tmp, cls_tmp = MERGED + ".tmp", os.path.join(rules_dir, "classification.config.tmp")
    errors = []
    for url in rule_urls():
        try:
            n = fetch_into(url, rules_tmp, cls_tmp)
            if n < MIN_ET_RULES:
                raise ValueError(f"only {n} ET rules in the download")
            os.replace(rules_tmp, MERGED)
            if os.path.exists(cls_tmp):
                os.replace(cls_tmp, os.path.join(rules_dir, "classification.config"))
            log(f"downloaded {n} ET Open rules from {url}")
            return True
        except Exception as e:
            errors.append(f"{url.split('/open/')[-1]}: {e.__class__.__name__}: {e}")
    for t in (rules_tmp, cls_tmp):
        if os.path.exists(t):
            os.remove(t)
    log("download failed — keeping the previous rules: " + "; ".join(errors)[:600])
    return False


def build(skip=frozenset()):
    if not os.path.exists(MERGED):
        log("no downloaded rules yet")
        return None
    cats = {c.strip().upper() for c in env("SURICATA_CATEGORIES",
            "MALWARE,MOBILE_MALWARE,PHISHING,EXPLOIT_KIT,COINMINER").split(",") if c.strip()}
    disable, alert_only = ids("SURICATA_DISABLE_SIDS"), ids("SURICATA_ALERT_ONLY_SIDS")
    block = mode() == "block"
    kept = drops = 0
    with open(MERGED, errors="replace") as src, open(CANDIDATE, "w") as dst:
        for line in src:
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            m = MSG.search(s)
            if not m or m.group(1) not in cats:
                continue
            sid = SID.search(s)
            sid = sid.group(1) if sid else ""
            if sid in disable or sid in skip:
                continue
            action = s.split(None, 1)[0]
            meta = META.search(s)
            meta = meta.group(1) if meta else ""
            high = re.search(r"\bconfidence\s+High\b", meta) is not None
            severe = re.search(r"\bsignature_severity\s+(Major|Critical)\b", meta) is not None
            if action in ("alert", "drop"):
                if block and high and severe and sid not in alert_only:
                    s = "drop" + s[len(action):]
                    drops += 1
                else:
                    s = "alert" + s[len(action):]
            kept += 1
            dst.write(s + "\n")
    return kept, drops


def test(path):
    r = subprocess.run(["suricata", "-T", "-c", CONF, "-S", path, "-l", "/tmp"],
                       capture_output=True, text=True, timeout=900)
    return r.returncode == 0, (r.stderr or "") + (r.stdout or "")


def broken_sids(output):
    """sids of rules this Suricata version could not parse"""
    out = set()
    for line in output.splitlines():
        if "error parsing signature" in line:
            m = SID.search(line)
            if m:
                out.add(m.group(1))
    return out


def activate(reload_pid=None):
    res = build()
    if res is None:
        return False
    kept, drops = res
    if kept == 0:
        cats = env("SURICATA_CATEGORIES", "MALWARE,MOBILE_MALWARE,PHISHING,EXPLOIT_KIT,COINMINER")
        log(f"no rules matched SURICATA_CATEGORIES ({cats}) — keeping the previous ruleset")
        notify(f"⚠️ Suricata: the downloaded rules contain nothing for SURICATA_CATEGORIES ({cats}); "
               "still running the previous rules. Check the category names.")
        return False
    ok, err = test(CANDIDATE)
    skipped = set()
    if not ok:
        # Usually one upstream rule this Suricata version can't parse: leave just
        # those out (reported) instead of freezing all future rule updates.
        skipped = broken_sids(err)
        if skipped:
            kept, drops = build(frozenset(skipped))
            ok, err = test(CANDIDATE)
    if not ok:
        tail = err.strip()[-300:]
        log(f"new ruleset FAILED its test — keeping the previous one: {tail}")
        notify(f"❌ Suricata rule update failed its test; still running the previous rules.\n```{tail}```")
        return False
    if skipped:
        log(f"left out {len(skipped)} rule(s) this Suricata version can't parse: sid {', '.join(sorted(skipped))}")
        notify(f"⚠️ Suricata: left out {len(skipped)} upstream rule(s) this version can't parse "
               f"(sid {', '.join(sorted(skipped)[:10])}); all other rules updated.")
    if os.path.exists(ACTIVE):
        shutil.copy2(ACTIVE, ACTIVE + ".previous")
    os.replace(CANDIDATE, ACTIVE)
    log(f"active: {kept} rules ({drops} high-confidence DROP, {kept - drops} alert-only), mode {mode()}")
    if reload_pid:
        try:
            os.kill(int(reload_pid), signal.SIGUSR2)   # live rule reload
        except (ProcessLookupError, ValueError):
            pass
    return True


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "download":
        sys.exit(0 if download() else 1)
    elif cmd == "activate":
        sys.exit(0 if activate(sys.argv[2] if len(sys.argv) > 2 else None) else 1)
    elif cmd == "build":
        print(build())
    else:
        sys.exit(__doc__)
