#!/usr/bin/env python3
"""Build Suricata's active ruleset from the Emerging Threats Open rules.

  * only the categories in SURICATA_CATEGORIES are loaded (keeps memory low)
  * in block mode, a rule DROPS only when ET marks it both
      confidence High          ("minimal likelihood of false positives")
      signature_severity Major/Critical (active / likely compromise)
    everything else only alerts; in monitor mode nothing drops
  * SURICATA_ALERT_ONLY_SIDS never drop, SURICATA_DISABLE_SIDS are removed
  * a candidate ruleset is tested with `suricata -T` before it replaces the
    running one; if it fails, the previous ruleset stays (and you're alerted)

usage: suricata_rules.py download|build|activate
"""
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time

STATE = os.environ.get("STATE_DIR", "/state")
SDIR = os.path.join(STATE, "suricata")
SU_DATA = os.path.join(SDIR, "su")
MERGED = os.path.join(SU_DATA, "rules", "suricata.rules")
ACTIVE = os.path.join(SDIR, "active.rules")
CANDIDATE = os.path.join(SDIR, "candidate.rules")
CONF = os.environ.get("SURICATA_CONF", "/run/suricata.yaml")
GUARD = ["python3", "/usr/local/lib/wg-vpn-gateway/guardlib.py"]

MSG = re.compile(r'msg:"ET ([A-Z_]+)')
SID = re.compile(r"\bsid:\s*(\d+)")
META = re.compile(r"\bmetadata:([^;]*);")


def env(k, d=""):
    v = os.environ.get(k)
    return d if not v else v


def ids(key):
    return {x.strip() for x in env(key).replace(" ", ",").split(",") if x.strip()}


def log(m):
    print(f"[suricata-rules] {m}", flush=True)
    os.makedirs(env("LOG_DIR", "/logs"), exist_ok=True)
    with open(os.path.join(env("LOG_DIR", "/logs"), "guard.log"), "a") as f:
        f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + f"suricata rules: {m}\n")


def notify(m):
    subprocess.run(GUARD + ["notify", m], capture_output=True)


def mode():
    """High-confidence rules block right away (like the trusted blocklists),
    unless BLOCK_MODE=monitor."""
    try:
        with open(os.path.join(STATE, "mode.json")) as f:
            m = json.load(f).get("suricata")
            if m:
                return m
    except (OSError, ValueError):
        pass
    return "monitor" if env("BLOCK_MODE", "auto").lower() == "monitor" else "block"


def download():
    """Fetch ET Open via suricata-update (handles version-specific URLs and
    caching). Output is a merged rules file; the previous one is kept on failure."""
    os.makedirs(SU_DATA, exist_ok=True)
    cmd = ["suricata-update", "--data-dir", SU_DATA, "--output", os.path.join(SU_DATA, "rules"),
           "--no-test", "--no-reload", "--quiet", "-c", os.path.join(SU_DATA, "update.yaml")]
    if env("SURICATA_RULES_URL"):
        cmd += ["--url", env("SURICATA_RULES_URL")]
    if not os.path.exists(os.path.join(SU_DATA, "update.yaml")):
        with open(os.path.join(SU_DATA, "update.yaml"), "w") as f:
            f.write("disable-conf: /dev/null\nenable-conf: /dev/null\ndrop-conf: /dev/null\nmodify-conf: /dev/null\n")
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    if r.returncode != 0 or not os.path.exists(MERGED):
        log(f"download failed (rc {r.returncode}): {(r.stderr or r.stdout).strip()[-300:]}")
        return False
    return True


def build(skip=frozenset()):
    if not os.path.exists(MERGED):
        log("no downloaded rules yet")
        return None
    cats = {c.strip().upper() for c in env("SURICATA_CATEGORIES",
            "MALWARE,MOBILE_MALWARE,PHISHING,EXPLOIT_KIT,COINMINER").split(",") if c.strip()}
    disable, alert_only = ids("SURICATA_DISABLE_SIDS"), ids("SURICATA_ALERT_ONLY_SIDS")
    block = mode() == "block"
    kept = drops = 0
    with open(MERGED, errors="replace") as src, open(CANDIDATE, "w") as dst:
        for line in src:
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            m = MSG.search(s)
            if not m or m.group(1) not in cats:
                continue
            sid = SID.search(s)
            sid = sid.group(1) if sid else ""
            if sid in disable or sid in skip:
                continue
            action = s.split(None, 1)[0]
            meta = META.search(s)
            meta = meta.group(1) if meta else ""
            high = re.search(r"\bconfidence\s+High\b", meta) is not None
            severe = re.search(r"\bsignature_severity\s+(Major|Critical)\b", meta) is not None
            if action in ("alert", "drop"):
                if block and high and severe and sid not in alert_only:
                    s = "drop" + s[len(action):]
                    drops += 1
                else:
                    s = "alert" + s[len(action):]
            kept += 1
            dst.write(s + "\n")
    return kept, drops


def test(path):
    r = subprocess.run(["suricata", "-T", "-c", CONF, "-S", path, "-l", "/tmp"],
                       capture_output=True, text=True, timeout=900)
    return r.returncode == 0, (r.stderr or "") + (r.stdout or "")


def broken_sids(output):
    """sids of rules this Suricata version could not parse"""
    out = set()
    for line in output.splitlines():
        if "error parsing signature" in line:
            m = SID.search(line)
            if m:
                out.add(m.group(1))
    return out


def activate(reload_pid=None):
    res = build()
    if res is None:
        return False
    kept, drops = res
    ok, err = test(CANDIDATE)
    skipped = set()
    if not ok:
        # Usually one upstream rule this Suricata version can't parse: leave just
        # those out (reported) instead of freezing all future rule updates.
        skipped = broken_sids(err)
        if skipped:
            kept, drops = build(frozenset(skipped))
            ok, err = test(CANDIDATE)
    if not ok:
        tail = err.strip()[-300:]
        log(f"new ruleset FAILED its test — keeping the previous one: {tail}")
        notify(f"❌ Suricata rule update failed its test; still running the previous rules.\n```{tail}```")
        return False
    if skipped:
        log(f"left out {len(skipped)} rule(s) this Suricata version can't parse: sid {', '.join(sorted(skipped))}")
        notify(f"⚠️ Suricata: left out {len(skipped)} upstream rule(s) this version can't parse "
               f"(sid {', '.join(sorted(skipped)[:10])}); all other rules updated.")
    if os.path.exists(ACTIVE):
        shutil.copy2(ACTIVE, ACTIVE + ".previous")
    os.replace(CANDIDATE, ACTIVE)
    log(f"active: {kept} rules ({drops} high-confidence DROP, {kept - drops} alert-only), mode {mode()}")
    if reload_pid:
        try:
            os.kill(int(reload_pid), signal.SIGUSR2)   # live rule reload
        except (ProcessLookupError, ValueError):
            pass
    return True


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "download":
        sys.exit(0 if download() else 1)
    elif cmd == "activate":
        sys.exit(0 if activate(sys.argv[2] if len(sys.argv) > 2 else None) else 1)
    elif cmd == "build":
        print(build())
    else:
        sys.exit(__doc__)
