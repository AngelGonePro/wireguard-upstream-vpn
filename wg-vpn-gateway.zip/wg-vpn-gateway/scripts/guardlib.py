#!/usr/bin/env python3
"""wg-vpn-gateway guard: destination/source blocklists, monitor-then-block,
alerts (Discord + Uptime Kuma) and size-capped logs.

Runs as one short process per minute (`tick`) so nothing stays resident.

Safety rules for blocklists (to avoid blocking valid traffic):
  * only lists built for low false positives are on by default
  * private / reserved / local ranges, your allowlist, bypass destinations,
    the VPN endpoint, the gateway VM and your DNS servers are never blocked
  * implausible list updates (empty, shrank by more than half, absurdly wide
    prefixes) are rejected and the previous good copy is kept
  * new outgoing connections are checked; every hit is logged and alerted
"""
import ipaddress
import json
import os
import socket
import subprocess
import sys
import time
import urllib.parse
import urllib.request

STATE = os.environ.get("STATE_DIR", "/state")
LOGS = os.environ.get("LOG_DIR", "/logs")
RUN = os.environ.get("RUN_DIR", "/run/wg-vpn-gateway")
LISTS = os.path.join(STATE, "lists")
OUTBOX = os.path.join(STATE, "outbox")
NFT_TABLE = "wgvpn_guard"
UA = "wg-vpn-gateway/1.0 (+self-hosted VPN gateway)"
NAME = os.environ.get("ALERT_NAME") or socket.gethostname()
MODE = os.environ.get("MODE", "standalone")


def env(key, default=""):
    v = os.environ.get(key)
    return default if v is None or v == "" else v


def env_bool(key, default):
    v = env(key, "true" if default else "false").lower()
    return v in ("1", "true", "yes", "on")


def env_int(key, default):
    try:
        return int(env(key, str(default)))
    except ValueError:
        return default


def csv_list(value):
    return [x.strip() for x in value.replace("\n", ",").split(",") if x.strip()]


def now():
    return int(time.time())


def ts(t=None):
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(t or now()))


def load_json(path, default):
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def save_json(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f)
    os.replace(tmp, path)


def log(line):
    os.makedirs(LOGS, exist_ok=True)
    msg = f"{ts()} {line}"
    print(f"[guard] {line}", flush=True)
    with open(os.path.join(LOGS, "guard.log"), "a") as f:
        f.write(msg + "\n")


# ------------------------------------------------------------------ alerts ---
def notify(text):
    """Queue a Discord message; delivered by flush() (survives outages)."""
    if not env("DISCORD_WEBHOOK_URL"):
        return
    os.makedirs(OUTBOX, exist_ok=True)
    name = f"{time.time():.6f}.txt"
    with open(os.path.join(OUTBOX, name), "w") as f:
        f.write(f"[{ts()}] {text}")
    files = sorted(os.listdir(OUTBOX))
    for old in files[:-200]:            # never let the queue grow unbounded
        try:
            os.remove(os.path.join(OUTBOX, old))
        except OSError:
            pass


def http(url, data=None, headers=None, timeout=20, method=None):
    h = {"User-Agent": UA}
    h.update(headers or {})
    req = urllib.request.Request(url, data=data, headers=h, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, r.read()


def flush():
    url = env("DISCORD_WEBHOOK_URL")
    if not url or not os.path.isdir(OUTBOX):
        return
    for name in sorted(os.listdir(OUTBOX))[:5]:   # Discord rate limits: a few per minute
        path = os.path.join(OUTBOX, name)
        try:
            with open(path) as f:
                text = f.read()
        except OSError:
            continue
        body = json.dumps({"username": f"wg-vpn-gateway · {NAME}",
                           "content": text[:1900]}).encode()
        try:
            http(url, body, {"Content-Type": "application/json"})
        except urllib.error.HTTPError as e:
            if e.code == 429:
                return                       # rate limited: try again next minute
            if 400 <= e.code < 500:
                log(f"discord rejected a message (HTTP {e.code}) — check DISCORD_WEBHOOK_URL")
                os.remove(path)
                continue
            return
        except Exception:
            return                           # offline / kill switch: keep queued
        os.remove(path)


def kuma(up, msg):
    url = env("KUMA_PUSH_URL")
    if not url:
        return
    parts = urllib.parse.urlsplit(url)
    q = dict(urllib.parse.parse_qsl(parts.query))
    q.update({"status": "up" if up else "down", "msg": msg[:200], "ping": ""})
    full = urllib.parse.urlunsplit(parts._replace(query=urllib.parse.urlencode(q)))
    try:
        http(full, timeout=10)
    except Exception:
        pass   # unreachable while blocked: Uptime Kuma then alerts on the missing heartbeat


# ------------------------------------------------------------- local nets ---
PROTECTED_V4 = [ipaddress.ip_network(n) for n in (
    "0.0.0.0/8", "10.0.0.0/8", "100.64.0.0/10", "127.0.0.0/8", "169.254.0.0/16",
    "172.16.0.0/12", "192.0.0.0/24", "192.168.0.0/16", "198.18.0.0/15",
    "224.0.0.0/4", "240.0.0.0/4")]
PROTECTED_V6 = [ipaddress.ip_network(n) for n in (
    "::/128", "::1/128", "fc00::/7", "fe80::/10", "ff00::/8", "::ffff:0:0/96", "64:ff9b::/96")]


def parse_net(text):
    try:
        return ipaddress.ip_network(text.strip(), strict=False)
    except ValueError:
        return None


def client_map():
    out = {}
    for e in csv_list(env("GATEWAY_CLIENTS")):
        addr, _, name = e.partition("=")
        out[addr.split("/")[0]] = name or addr
    return out


def who(ip):
    return client_map().get(ip, "this VM" if ip in local_addrs() else ip)


def local_addrs():
    try:
        out = subprocess.run(["ip", "-o", "addr", "show"], capture_output=True, text=True).stdout
    except OSError:
        return set()
    return {line.split()[3].split("/")[0] for line in out.splitlines() if len(line.split()) > 3}


def never_block():
    """Addresses that must never be blocked, whatever a list says."""
    nets = list(PROTECTED_V4) + list(PROTECTED_V6)
    items = csv_list(env("ALLOWLIST")) + csv_list(env("BYPASS_DESTINATIONS"))
    items += [e.partition("=")[0] for e in csv_list(env("GATEWAY_CLIENTS"))]
    if env("GATEWAY_IP"):
        items.append(env("GATEWAY_IP"))
    try:
        with open(os.path.join(RUN, "endpoints")) as f:
            items += [l.strip() for l in f if l.strip()]
    except OSError:
        pass
    try:
        with open("/etc/resolv.conf") as f:
            items += [l.split()[1] for l in f if l.startswith("nameserver") and len(l.split()) > 1]
    except OSError:
        pass
    for i in items:
        n = parse_net(i)
        if n:
            nets.append(n)
    return nets


# --------------------------------------------------------------- fetching ---
def fetch_spamhaus():
    v4, v6 = [], []
    for url, bucket in ((env("SPAMHAUS_DROP_V4_URL", "https://www.spamhaus.org/drop/drop_v4.json"), v4),
                        (env("SPAMHAUS_DROP_V6_URL", "https://www.spamhaus.org/drop/drop_v6.json"), v6)):
        _, raw = http(url, timeout=30)
        for line in raw.decode("utf-8", "replace").splitlines():
            try:
                obj = json.loads(line)
            except ValueError:
                continue
            if "cidr" in obj:
                bucket.append(obj["cidr"])
    return v4 + v6


def fetch_text(url):
    _, raw = http(url, timeout=30)
    out = []
    for line in raw.decode("utf-8", "replace").splitlines():
        line = line.split("#")[0].split(";")[0].strip()
        if line:
            out.append(line.split()[0])
    return out


def fetch_threatfox():
    key = env("THREATFOX_AUTH_KEY")
    body = json.dumps({"query": "get_iocs", "days": 7}).encode()
    _, raw = http(env("THREATFOX_API_URL", "https://threatfox-api.abuse.ch/api/v1/"), body,
                  {"Auth-Key": key, "Content-Type": "application/json"}, timeout=60)
    data = json.loads(raw)
    if data.get("query_status") not in ("ok", "no_result"):
        raise RuntimeError(f"ThreatFox: {data.get('query_status')}")
    min_conf = env_int("THREATFOX_MIN_CONFIDENCE", 90)
    out = []
    for ioc in data.get("data") or []:
        if ioc.get("ioc_type") != "ip:port":
            continue
        if int(ioc.get("confidence_level") or 0) < min_conf:
            continue
        ip, _, port = str(ioc.get("ioc", "")).rpartition(":")
        if port.isdigit():
            out.append([ip, int(port), ioc.get("malware_printable") or ioc.get("threat_type") or "malware"])
    return out


def sanitize(entries, protect):
    """Validate CIDRs; refuse absurdly wide prefixes and anything touching
    local/reserved or never-block ranges. Returns (v4, v6, rejected)."""
    v4, v6, rejected = [], [], []
    for e in entries:
        n = parse_net(e)
        if n is None:
            continue
        if (n.version == 4 and n.prefixlen < 8) or (n.version == 6 and n.prefixlen < 16):
            rejected.append(f"{n} (too wide)")
            continue
        if any(n.version == p.version and n.overlaps(p) for p in protect):
            rejected.append(f"{n} (covers a local/allowlisted address)")
            continue
        (v4 if n.version == 4 else v6).append(n)
    return ([str(x) for x in ipaddress.collapse_addresses(v4)],
            [str(x) for x in ipaddress.collapse_addresses(v6)], rejected)


def plausible(name, new_count, meta):
    prev = meta.get(name, {}).get("count", 0)
    shrink = env_int("BLOCKLIST_MAX_SHRINK_PERCENT", 50)
    if new_count == 0 and prev > 0:
        return f"came back empty (previously {prev} entries)"
    if prev >= 20 and new_count < prev * (100 - shrink) / 100:
        return f"shrank from {prev} to {new_count} entries"
    if new_count > env_int("BLOCKLIST_MAX_ENTRIES", 200000):
        return f"has {new_count} entries (over BLOCKLIST_MAX_ENTRIES)"
    return None


def refresh(force=False):
    os.makedirs(LISTS, exist_ok=True)
    meta = load_json(os.path.join(LISTS, "meta.json"), {})
    every = max(1, env_int("BLOCKLIST_REFRESH_HOURS", 24)) * 3600
    last = meta.get("_last_attempt", 0)
    if not force and now() - last < (every if meta.get("_last_ok") else 1800):
        return False
    meta["_last_attempt"] = now()
    protect = never_block()
    sources = []
    if env_bool("BLOCKLIST_SPAMHAUS", True):
        sources.append(("spamhaus-drop", fetch_spamhaus))
    for i, url in enumerate(csv_list(env("EXTRA_BLOCKLIST_URLS"))):
        sources.append((f"extra-{i + 1}", lambda u=url: fetch_text(u)))
    changed, ok_all = False, True
    for name, fn in sources:
        try:
            v4, v6, rejected = sanitize(fn(), protect)
        except Exception as e:
            ok_all = False
            log(f"blocklist {name}: download failed ({e.__class__.__name__}: {e}) — keeping previous copy")
            continue
        problem = plausible(name, len(v4) + len(v6), meta)
        if problem:
            ok_all = False
            log(f"blocklist {name}: update REJECTED, {problem} — keeping previous copy")
            notify(f"⚠️ Blocklist **{name}** update rejected: {problem}. Kept the previous copy.")
            continue
        with open(os.path.join(LISTS, f"{name}.txt"), "w") as f:
            f.write("\n".join(v4 + v6) + "\n")
        if rejected:
            log(f"blocklist {name}: ignored {len(rejected)} unsafe entries, e.g. {', '.join(rejected[:3])}")
        meta[name] = {"count": len(v4) + len(v6), "updated": now()}
        changed = True
    if env("THREATFOX_AUTH_KEY"):
        try:
            tf = fetch_threatfox()
            safe = [t for t in tf if parse_net(t[0]) and not any(
                parse_net(t[0]).version == p.version and parse_net(t[0]).overlaps(p) for p in protect)]
            problem = plausible("threatfox", len(safe), meta)
            if problem and len(safe) == 0:
                log(f"blocklist threatfox: {problem} — keeping previous copy")
            else:
                save_json(os.path.join(LISTS, "threatfox.json"), safe)
                meta["threatfox"] = {"count": len(safe), "updated": now()}
                changed = True
        except Exception as e:
            ok_all = False
            log(f"blocklist threatfox: download failed ({e.__class__.__name__}: {e}) — keeping previous copy")
    if ok_all:
        meta["_last_ok"] = now()
    save_json(os.path.join(LISTS, "meta.json"), meta)
    counts = ", ".join(f"{k} {v['count']}" for k, v in meta.items() if not k.startswith("_"))
    if changed:
        log(f"blocklists refreshed: {counts or 'none enabled'}")
    return changed


def load_lists():
    nets, tf = {}, []
    if os.path.isdir(LISTS):
        for fn in sorted(os.listdir(LISTS)):
            if fn.endswith(".txt"):
                with open(os.path.join(LISTS, fn)) as f:
                    nets[fn[:-4]] = [l.strip() for l in f if l.strip()]
    if env("THREATFOX_AUTH_KEY"):
        tf = load_json(os.path.join(LISTS, "threatfox.json"), [])
    return nets, tf


# ---------------------------------------------------------- mode handling ---
def is_extra(list_name):
    return list_name.startswith("extra-")


def effective_mode():
    """Which sources block, and when.

    trusted — Spamhaus DROP, ThreatFox at THREATFOX_MIN_CONFIDENCE+ and
              Suricata rules rated confidence High + severity Major/Critical:
              built to have no false positives, so they BLOCK right away.
    extra   — your own EXTRA_BLOCKLIST_URLS lists (unknown quality): with
              BLOCK_MODE=auto they are monitored for MONITOR_DAYS, then block.
    BLOCK_MODE=monitor makes everything alert-only; =block blocks extra lists
    right away too. Lower-confidence matches never block in any mode.
    """
    st = load_json(os.path.join(STATE, "mode.json"), {})
    if "monitor_started" not in st:
        st["monitor_started"] = now()
    want = env("BLOCK_MODE", "auto").lower()
    trusted = "monitor" if want == "monitor" else "block"
    if want in ("monitor", "block"):
        extra = want
    else:
        days = env_int("MONITOR_DAYS", 7)
        extra = "block" if now() - st["monitor_started"] >= days * 86400 else "monitor"
    prev = (st.get("trusted"), st.get("effective"))
    st.update({"trusted": trusted, "effective": extra, "suricata": trusted})
    save_json(os.path.join(STATE, "mode.json"), st)
    have_extra = bool(csv_list(env("EXTRA_BLOCKLIST_URLS")))
    if prev[1] and prev[1] != extra and have_extra:
        seen = load_json(os.path.join(STATE, "seen.json"), {})
        hits = [v for v in seen.values() if v.get("cls") == "extra"]
        lines = "\n".join(f"• {v.get('desc')}" for v in hits[:10]) or "• (no hits)"
        if extra == "block":
            msg = (f"🛡️ Monitoring of your extra blocklists is over — they now **BLOCK**.\n"
                   f"{len(hits)} distinct hits were seen while monitoring:\n{lines}\n"
                   f"If any of these are legitimate, add them to ALLOWLIST.")
        else:
            msg = "👀 Your extra blocklists are back in **monitor** mode (logged and alerted, not blocked)."
        log(msg.splitlines()[0])
        notify(msg)
    if prev[0] and prev[0] != trusted:
        msg = ("🛡️ Trusted blocklists and high-confidence Suricata rules now **BLOCK**." if trusted == "block"
               else "👀 BLOCK_MODE=monitor — nothing is blocked; all matches are only logged and alerted.")
        log(msg)
        notify(msg)
    return {"trusted": trusted, "extra": extra}, prev != (trusted, extra)


def monitor_days_left():
    st = load_json(os.path.join(STATE, "mode.json"), {})
    left = env_int("MONITOR_DAYS", 7) * 86400 - (now() - st.get("monitor_started", now()))
    return max(0, int(left // 86400) + (1 if left % 86400 else 0))


# -------------------------------------------------------------- nftables ---
def nft_elems(items):
    return ", ".join(items)


def collapse(nets, version):
    return [str(x) for x in ipaddress.collapse_addresses(
        ipaddress.ip_network(n) for n in nets if ipaddress.ip_network(n).version == version)]


def render(modes):
    wan = open(os.path.join(RUN, "wan_interface")).read().strip()
    nets, tf = load_lists()
    trusted = [n for name, v in nets.items() if not is_extra(name) for n in v]
    extra = [n for name, v in nets.items() if is_extra(name) for n in v]
    bl4, bl6, ex4, ex6 = collapse(trusted, 4), collapse(trusted, 6), collapse(extra, 4), collapse(extra, 6)
    al = never_block()
    al4 = [str(x) for x in ipaddress.collapse_addresses(n for n in al if n.version == 4)]
    al6 = [str(x) for x in ipaddress.collapse_addresses(n for n in al if n.version == 6)]
    tf4 = sorted({f"{ip} . {port}" for ip, port, _ in tf if ":" not in ip})

    # Single-address sets are declared with "typeof", not "type": sets of a
    # plain "type ipv4_addr" written by this container's (newer) nft make the
    # older nft of many hosts (Debian 12: 1.0.6) crash on "nft list ruleset".
    # Both mean the same to the kernel.
    def iset(name, typ, elems):
        e = f" elements = {{ {nft_elems(elems)} }}" if elems else ""
        return f"  set {name} {{ {typ}; flags interval; auto-merge;{e} }}\n"

    def hset(name, typ):
        return f"  set {name} {{ {typ}; size 65535; flags dynamic,timeout; timeout 30d; }}\n"

    def vout(name, block):
        return (f"  chain {name} {{\n" + ("    meta l4proto tcp reject with tcp reset\n"
                "    reject with icmpx type admin-prohibited\n" if block else "") + "  }\n")

    def vin(name, block):
        return f"  chain {name} {{\n" + ("    drop\n" if block and env_bool("BLOCK_INBOUND", True) else "") + "  }\n"

    tb, xb = modes["trusted"] == "block", modes["extra"] == "block"
    out = [f"table inet {NFT_TABLE} {{}}\n", f"delete table inet {NFT_TABLE}\n", f"table inet {NFT_TABLE} {{\n"]
    out += [iset("allow4", "typeof ip daddr", al4), iset("allow6", "typeof ip6 daddr", al6),
            iset("bl4", "typeof ip daddr", bl4), iset("bl6", "typeof ip6 daddr", bl6),
            iset("ex4", "typeof ip daddr", ex4), iset("ex6", "typeof ip6 daddr", ex6)]
    e = f" elements = {{ {nft_elems(tf4)} }}" if tf4 else ""
    out.append(f"  set tf4 {{ type ipv4_addr . inet_service;{e} }}\n")
    out += [hset("hit4", "type ipv4_addr . ipv4_addr"), hset("hit6", "type ipv6_addr . ipv6_addr"),
            hset("hittf4", "type ipv4_addr . ipv4_addr . inet_service"),
            hset("hitin4", "typeof ip saddr"), hset("hitin6", "typeof ip6 saddr")]
    out += [vout("verdict_out_t", tb), vout("verdict_out_x", xb), vin("verdict_in_t", tb), vin("verdict_in_x", xb)]
    out.append("""  chain check_out {
    ip daddr @allow4 return
    ip6 daddr @allow6 return
    ip daddr @bl4 update @hit4 { ip saddr . ip daddr } goto verdict_out_t
    ip6 daddr @bl6 update @hit6 { ip6 saddr . ip6 daddr } goto verdict_out_t
    meta l4proto { tcp, udp } ip daddr . th dport @tf4 update @hittf4 { ip saddr . ip daddr . th dport } goto verdict_out_t
    ip daddr @ex4 update @hit4 { ip saddr . ip daddr } goto verdict_out_x
    ip6 daddr @ex6 update @hit6 { ip6 saddr . ip6 daddr } goto verdict_out_x
  }
  chain check_in {
    ip saddr @allow4 return
    ip6 saddr @allow6 return
    ip saddr @bl4 update @hitin4 { ip saddr } goto verdict_in_t
    ip6 saddr @bl6 update @hitin6 { ip6 saddr } goto verdict_in_t
    ip saddr @ex4 update @hitin4 { ip saddr } goto verdict_in_x
    ip6 saddr @ex6 update @hitin6 { ip6 saddr } goto verdict_in_x
  }
""")
    out.append("  chain output { type filter hook output priority -5; policy accept; ct state new jump check_out; }\n")
    out.append(f'  chain forward {{ type filter hook forward priority -5; policy accept; ct state new iifname "{wan}" jump check_in; ct state new jump check_out; }}\n')
    out.append(f'  chain input {{ type filter hook input priority -5; policy accept; ct state new iifname "{wan}" jump check_in; }}\n')
    out.append("}\n")
    return "".join(out), len(bl4) + len(bl6), len(tf4), len(ex4) + len(ex6)


def apply(modes):
    if MODE == "client":
        return
    rules, n, ntf, nx = render(modes)
    path = os.path.join(RUN, "guard.nft")
    with open(path, "w") as f:
        f.write(rules)
    report()   # read hits before the table (and its hit sets) is replaced
    r = subprocess.run(["nft", "-f", path], capture_output=True, text=True)
    if r.returncode != 0:
        log(f"could not load blocklist rules: {r.stderr.strip()[:300]}")
        notify(f"❌ Could not load blocklist rules: {r.stderr.strip()[:300]}")
        return
    msg = f"blocklist rules active — trusted lists {modes['trusted'].upper()} ({n} networks"
    msg += f", {ntf} ThreatFox ip:port)" if ntf else ")"
    if csv_list(env("EXTRA_BLOCKLIST_URLS")):
        msg += f"; your extra lists {modes['extra'].upper()} ({nx} networks"
        msg += f", {monitor_days_left()} day(s) of monitoring left)" if modes["extra"] == "monitor" and env("BLOCK_MODE", "auto") == "auto" else ")"
    log(msg)


# --------------------------------------------------------------- reporting ---
def nft_set_elems(name):
    r = subprocess.run(["nft", "-j", "list", "set", "inet", NFT_TABLE, name], capture_output=True, text=True)
    if r.returncode != 0:
        return []
    out = []

    def walk(o):
        if isinstance(o, dict):
            if "concat" in o:
                out.append(tuple(str(x) for x in o["concat"]))
                return
            if "val" in o and not isinstance(o["val"], (dict, list)):
                out.append((str(o["val"]),))
                return
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)

    for item in json.loads(r.stdout).get("nftables", []):
        s = item.get("set")
        if s:
            for el in s.get("elem", []):
                if isinstance(el, str):
                    out.append((el,))
                else:
                    walk(el)
    return out


def which_list(ip):
    a = ipaddress.ip_address(ip)
    nets, _ = load_lists()
    for name, v in nets.items():
        for n in v:
            if a in ipaddress.ip_network(n):
                return f"{name} ({n})"
    return "blocklist"


def report():
    if MODE == "client":
        return
    st = load_json(os.path.join(STATE, "mode.json"), {})
    mode_of = {"trusted": st.get("trusted", "block"), "extra": st.get("effective", "monitor")}
    seen = load_json(os.path.join(STATE, "seen.json"), {})
    _, tf = load_lists()
    tfnames = {(ip, str(port)): mal for ip, port, mal in tf}
    blocked, watched = [], []
    for name, kind in (("hit4", "out"), ("hit6", "out"), ("hittf4", "tf"), ("hitin4", "in"), ("hitin6", "in")):
        for el in nft_set_elems(name):
            key = name + ":" + "|".join(el)
            if key in seen:
                continue
            if kind == "tf":
                cls = "trusted"
                desc = f"{who(el[0])} → {el[1]}:{el[2]} [ThreatFox: {tfnames.get((el[1], el[2]), 'malware')}]"
            else:
                ip = el[1] if kind == "out" else el[0]
                lst = which_list(ip)
                cls = "extra" if is_extra(lst) else "trusted"
                desc = f"{who(el[0])} → {el[1]} [{lst}]" if kind == "out" else f"inbound from {el[0]} [{lst}]"
            seen[key] = {"t": now(), "desc": desc, "n": 1, "cls": cls}
            (blocked if mode_of[cls] == "block" else watched).append(desc)
    for d in blocked:
        log(f"BLOCKED: {d}")
    for d in watched:
        log(f"would block (monitoring): {d}")
    for head, items in (("🚫 **Blocked**", blocked), ("👀 **Would block** (monitoring — not blocked yet)", watched)):
        if items:
            body = "\n".join(f"• {d}" for d in items[:15])
            more = f"\n…and {len(items) - 15} more (see logs/guard.log)" if len(items) > 15 else ""
            notify(f"{head} — {len(items)} new blocklist match(es):\n{body}{more}")
    cutoff = now() - 30 * 86400
    seen = {k: v for k, v in seen.items() if v.get("t", 0) >= cutoff}
    save_json(os.path.join(STATE, "seen.json"), seen)


def eve():
    """Suricata alerts from logs/eve.json → log + Discord (deduplicated)."""
    path = os.path.join(LOGS, "eve.json")
    if not os.path.exists(path):
        return
    stp = os.path.join(STATE, "eve_state.json")
    st = load_json(stp, {"ino": 0, "off": 0, "seen": {}})
    s = os.stat(path)
    if s.st_ino != st["ino"] or s.st_size < st["off"]:
        st["ino"], st["off"] = s.st_ino, 0
    new, cut = [], now() - 6 * 3600
    st["seen"] = {k: v for k, v in st["seen"].items() if v > cut}
    with open(path, "rb") as f:
        f.seek(st["off"])
        data = f.read(4 * 1024 * 1024)
        st["off"] += len(data.rsplit(b"\n", 1)[0]) + 1 if b"\n" in data else 0
    for line in data.split(b"\n")[:-1]:
        try:
            ev = json.loads(line)
        except ValueError:
            continue
        if ev.get("event_type") != "alert":
            continue
        a = ev.get("alert", {})
        src, dst = ev.get("src_ip", "?"), ev.get("dest_ip", "?")
        key = f"{a.get('signature_id')}|{src}|{dst}"
        if key in st["seen"]:
            continue
        st["seen"][key] = now()
        act = "BLOCKED" if a.get("action") == "blocked" else "alert"
        new.append(f"{act}: {who(src)} → {dst}:{ev.get('dest_port', '')} — {a.get('signature', '?')} (sid {a.get('signature_id')})")
    save_json(stp, st)
    if new:
        for d in new:
            log(f"suricata {d}")
        body = "\n".join(f"• {d}" for d in new[:10])
        more = f"\n…and {len(new) - 10} more (see logs/guard.log)" if len(new) > 10 else ""
        notify(f"🔎 **Suricata** — {len(new)} new alert(s):\n{body}{more}")


# ------------------------------------------------------------------ logs ---
def rotate():
    """copy-truncate so writers holding the file open (Suricata) keep working."""
    limit = env_int("LOG_MAX_KB", 512) * 1024
    keep = max(1, env_int("LOG_KEEP", 2))
    if not os.path.isdir(LOGS):
        return
    for fn in os.listdir(LOGS):
        if not (fn.endswith(".log") or fn.endswith(".json")):
            continue
        p = os.path.join(LOGS, fn)
        try:
            if os.path.getsize(p) <= limit:
                continue
            for i in range(keep - 1, 0, -1):
                if os.path.exists(f"{p}.{i}"):
                    os.replace(f"{p}.{i}", f"{p}.{i + 1}")
            with open(p, "rb") as src, open(f"{p}.1", "wb") as dst:
                src.seek(max(0, os.path.getsize(p) - limit))   # newest part only: bounded size
                dst.write(src.read())
            with open(p, "r+b") as f:
                f.truncate(0)
            if os.path.exists(f"{p}.{keep + 1}"):
                os.remove(f"{p}.{keep + 1}")
        except OSError:
            pass


# ------------------------------------------------------------------ main ---
def tick(health_ok, health_msg):
    stp = os.path.join(STATE, "health.json")
    h = load_json(stp, {})
    if h.get("ok") is not None and h["ok"] != health_ok:
        if health_ok:
            notify(f"✅ Back up — {health_msg}")
            log(f"health: back up — {health_msg}")
        else:
            ks = "kill switch is blocking outgoing traffic" if env_bool("KILLSWITCH", False) else "traffic is NOT protected"
            notify(f"🔴 DOWN — {health_msg} ({ks})")
            log(f"health: DOWN — {health_msg}")
    save_json(stp, {"ok": health_ok, "t": now()})
    if MODE != "client":
        modes, changed = effective_mode()
        if refresh() or changed:
            apply(modes)
        report()
        eve()
    kuma(health_ok, health_msg)
    flush()
    rotate()


def main():
    os.makedirs(STATE, exist_ok=True)
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "tick":
        tick(sys.argv[2] == "0", sys.argv[3] if len(sys.argv) > 3 else "")
    elif cmd == "start":
        if MODE != "client":
            modes, _ = effective_mode()
            apply(modes)
            if refresh(force=True):
                apply(modes)
    elif cmd == "refresh":
        if refresh(force=True):
            apply(effective_mode()[0])
    elif cmd == "notify":
        notify(" ".join(sys.argv[2:]))
        flush()
    elif cmd == "mode":
        print(json.dumps(effective_mode()[0]))
    elif cmd == "status":
        meta = load_json(os.path.join(LISTS, "meta.json"), {})
        print(json.dumps({"mode": load_json(os.path.join(STATE, "mode.json"), {}),
                          "lists": {k: v for k, v in meta.items() if not k.startswith("_")}}, indent=2))
    else:
        print("usage: guardlib.py tick|start|refresh|notify|mode|status", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
