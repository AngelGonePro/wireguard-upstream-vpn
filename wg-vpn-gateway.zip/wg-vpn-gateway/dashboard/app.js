// Read-only dashboard. Everything is rendered with textContent / DOM nodes —
// never innerHTML with data — so nothing in the data (addresses, rule names)
// can inject markup or script.
"use strict";
(() => {
  const $ = (id) => document.getElementById(id);
  const el = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined && text !== null) e.textContent = String(text);
    return e;
  };
  const fmt = (n) => Number(n || 0).toLocaleString();
  const flag = (cc) => (/^[A-Z]{2}$/.test(cc || "") ? String.fromCodePoint(...[...cc].map((c) => 0x1f1a5 + c.charCodeAt(0))) : "🏳");
  let names = {}, data = null, view = "all";
  const cname = (cc) => (cc === "??" ? "Unknown" : names[cc] || cc);
  const ago = (t) => {
    const s = Math.max(0, Math.floor(Date.now() / 1000 - t));
    if (s < 90) return "just now";
    if (s < 5400) return Math.round(s / 60) + " min ago";
    if (s < 129600) return Math.round(s / 3600) + " h ago";
    return Math.round(s / 86400) + " d ago";
  };
  const where = (r) => {
    const src = String(r.src || "").split(",").filter(Boolean);
    const dir = String(r.dir || "").split(",").filter(Boolean);
    const parts = [];
    for (const s of src) parts.push(s === "home" ? "this gateway" : s === "suricata" ? "Suricata" : s);
    const d = dir.includes("in") && dir.includes("out") ? "in+out" : dir.includes("out") ? "outbound" : "inbound";
    return parts.join(", ") + " · " + d;
  };
  const VIEW_LABELS = { all: "Everything", inbound: "Inbound (attackers)", outbound: "Outbound (your VMs)", suricata: "Suricata" };

  function buildViews() {
    const nav = $("views");
    nav.replaceChildren();
    const keys = Object.keys(data.views).filter((k) => k !== "src:home" || Object.keys(data.views).some((x) => x.startsWith("src:") && x !== "src:home"));
    for (const k of keys) {
      const label = VIEW_LABELS[k] || (k === "src:home" ? "This gateway only" : "Only " + k.slice(4));
      const b = el("button", null, label);
      b.type = "button";
      b.setAttribute("aria-pressed", String(k === view));
      b.addEventListener("click", () => { view = k; render(); });
      nav.append(b);
    }
  }

  function bucket(n, max) {
    if (!n) return 0;
    if (max <= 1) return 6;
    return Math.max(1, Math.min(6, Math.ceil((Math.log(n + 1) / Math.log(max + 1)) * 6)));
  }

  function renderMap(v) {
    const svg = $("map").querySelector("svg");
    if (!svg) return;
    const counts = Object.fromEntries(v.countries.map((c) => [c.cc, c]));
    const max = v.countries.reduce((m, c) => Math.max(m, c.n), 0);
    for (const p of svg.querySelectorAll("path.c")) {
      p.classList.remove("h1", "h2", "h3", "h4", "h5", "h6");
      const cc = (p.id || "").slice(2);
      const b = bucket(counts[cc] ? counts[cc].n : 0, max);
      if (b) p.classList.add("h" + b);
    }
    const lg = $("legend");
    lg.replaceChildren(el("span", null, "fewer"));
    for (let i = 0; i <= 6; i++) lg.append(el("i", "h" + i));
    lg.append(el("span", null, "more"));
    svg.onmousemove = (e) => {
      const p = e.target.closest("path.c");
      const tip = $("tip");
      if (!p || !p.id) { tip.hidden = true; return; }
      const cc = p.id.slice(2), c = counts[cc];
      tip.textContent = `${flag(cc)} ${cname(cc)} — ${c ? fmt(c.n) + " attempts from " + fmt(c.ips) + " address" + (c.ips === 1 ? "" : "es") : "none"}`;
      const box = $("map").parentElement.getBoundingClientRect();
      tip.style.left = Math.min(e.clientX - box.left + 12, box.width - tip.offsetWidth - 8) + "px";
      tip.style.top = (e.clientY - box.top + 12) + "px";
      tip.hidden = false;
    };
    svg.onmouseleave = () => { $("tip").hidden = true; };
  }

  function renderDaily(v) {
    const box = $("daily");
    box.replaceChildren();
    const max = Math.max(1, ...v.daily);
    data.days.forEach((d, i) => {
      const bar = el("div", "bar");
      bar.title = `${d}: ${fmt(v.daily[i])}`;
      bar.append(el("span", "n", fmt(v.daily[i])));
      const f = el("div", "fill");
      f.style.height = Math.round((v.daily[i] / max) * 80) + "%";
      bar.append(f, el("span", "d", new Date(d + "T00:00:00Z").toLocaleDateString(undefined, { weekday: "short", timeZone: "UTC" })));
      box.append(bar);
    });
  }

  function fillTable(id, rows, make, emptyText) {
    const tb = $(id).tBodies[0];
    tb.replaceChildren();
    if (!rows.length) {
      const tr = el("tr"), td = el("td", "empty", emptyText);
      td.colSpan = $(id).tHead.rows[0].cells.length;
      tr.append(td); tb.append(tr); return;
    }
    rows.forEach((r, i) => tb.append(make(r, i)));
  }

  function row(cells) {
    const tr = el("tr");
    for (const c of cells) tr.append(c);
    return tr;
  }

  function render() {
    if (!data) return;
    for (const b of $("views").children) b.setAttribute("aria-pressed", String(b.textContent === (VIEW_LABELS[view] || (view === "src:home" ? "This gateway only" : "Only " + view.slice(4)))));
    const v = data.views[view] || data.views.all;
    $("t-total").textContent = fmt(v.total);
    $("t-ips").textContent = fmt(v.unique_ips);
    $("t-cc").textContent = fmt(v.countries.filter((c) => c.cc !== "??").length);
    $("t-today").textContent = fmt(v.daily[v.daily.length - 1]);
    renderMap(v);
    renderDaily(v);
    fillTable("ips", v.top_ips, (r, i) => {
      const matched = el("td", "small");
      matched.append(el("span", null, r.label || "—"));
      const vms = String(r.vm || "").split(",").filter(Boolean);
      if (vms.length) matched.append(el("div", "muted", "from " + vms.join(", ")));
      matched.append(el("div", "muted", where(r) + (String(r.action || "").includes("blocked") ? "" : " · " + r.action)));
      return row([el("td", "muted", i + 1), el("td", "mono", r.ip), el("td", null, `${flag(r.cc)} ${cname(r.cc)}`),
        el("td", "num", fmt(r.n)), matched, el("td", "muted small", ago(r.last))]);
    }, "Nothing blocked in this view yet.");
    fillTable("countries", v.countries, (r, i) => row([el("td", "muted", i + 1),
      el("td", null, `${flag(r.cc)} ${cname(r.cc)}`), el("td", "num", fmt(r.n)), el("td", "num", fmt(r.ips))]), "No countries yet.");
    fillTable("recent", v.recent, (r) => row([el("td", "muted small", ago(r.last)), el("td", "mono", r.ip),
      el("td", null, `${flag(r.cc)} ${cname(r.cc)}`), el("td", "small", where(r) + (r.vm ? " · " + r.vm : "")),
      el("td", "small", r.label || "—")]), "Nothing yet.");
  }

  function renderStatus() {
    const s = $("status");
    s.replaceChildren();
    for (const [name, st] of Object.entries(data.sources || {})) {
      const ok = st === "ok";
      const p = el("span", "pill " + (ok ? "ok" : "bad"), (name === "home" ? data.name || "this gateway" : name) + (ok ? "" : ": " + st));
      s.append(p);
    }
    s.append(el("span", "pill", "updated " + ago(data.generated)));
    $("retention").textContent = data.retention_days;
  }

  async function load() {
    try {
      const r = await fetch("/summary.json", { cache: "no-store" });
      if (!r.ok) throw new Error(r.status);
      data = await r.json();
      if (!data.views[view]) view = "all";
      buildViews();
      renderStatus();
      render();
    } catch (e) {
      $("status").replaceChildren(el("span", "pill bad", "waiting for the first data (the collector runs once a minute)"));
    }
  }

  async function init() {
    try {
      const [svgText, n] = await Promise.all([
        fetch("/world.svg").then((r) => r.text()),
        fetch("/countries.json").then((r) => r.json()),
      ]);
      names = n;
      const doc = new DOMParser().parseFromString(svgText, "image/svg+xml");
      const svg = doc.documentElement;
      if (svg && svg.nodeName.toLowerCase() === "svg") $("map").append(document.importNode(svg, true));
    } catch (e) { /* map optional */ }
    await load();
    setInterval(load, 60000);
  }
  init();
})();
